"""พีเจกันพลา - ร้านขาย Gunpla ด้วย Flask
ดีไซน์ร้านค้าแบบ Catalog + Sidebar Filter + Search
แรงบันดาลใจจากเว็บร้าน Gunpla ที่ผู้ใช้ให้เป็นตัวอย่าง แต่เขียนโครงสร้าง/สไตล์ใหม่

ติดตั้ง:
    pip install -r requirements.txt

รัน:
    python app.py

เปิด:
    โปรแกรมจะเปิดเบราว์เซอร์ให้อัตโนมัติที่ http://127.0.0.1:5000
    (ถ้าพอร์ต 5000 ไม่ว่าง จะใช้พอร์ตถัดไปให้เอง ดูที่อยู่จริงในหน้าต่าง terminal)

หมายเหตุ:
    ไม่ต้องแก้ไฟล์ hosts แล้ว

แอดมินเพิ่มรูปสินค้าได้จากหลังบ้าน หรือวางรูปเดิมไว้ใน static/images/ ตามเลข id
ก่อนเปิดใช้งานครั้งแรก ให้คัดลอก .env.example เป็น .env และกำหนดรหัสผ่านแอดมินของตนเอง
ตั้งค่าข้อมูลติดต่อและ PromptPay ใน .env ก่อนเริ่มใช้งานระบบชำระเงิน
"""

import os
import re
import socket
import sqlite3
import threading
import webbrowser
import base64
import io
import uuid
import secrets
from datetime import datetime
from functools import wraps
from xml.sax.saxutils import escape

from flask import (
    Flask, render_template, session, redirect, url_for,
    request, abort, flash, g, send_from_directory, send_file
)
from jinja2 import DictLoader
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

# โหลดค่าลับจาก .env ในเครื่อง โดยไฟล์ .env จะไม่ถูกเผยแพร่ขึ้น GitHub
load_dotenv()

app = Flask(__name__)
# ใช้คีย์สุ่มชั่วคราวหากยังไม่ได้กำหนดค่าใน .env; ควรกำหนด PJ_SECRET_KEY เองเสมอ
app.secret_key = os.environ.get("PJ_SECRET_KEY") or secrets.token_hex(32)
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024  # จำกัดไฟล์อัปโหลด 8 MB

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "shop.db")
IMG_DIR = os.path.join(BASE_DIR, "static", "images")
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
SLIP_DIR = os.path.join(BASE_DIR, "slips")  # สลิปโอนเงิน: เก็บนอก static เพื่อไม่ให้เปิดดูได้ตรง ๆ
ALLOWED_IMAGE_EXTS = {"jpg", "jpeg", "png", "webp"}
DEFAULT_ADMIN_USERNAME = os.environ.get("PJ_ADMIN_USERNAME", "admin").strip() or "admin"
# ไม่มีรหัสผ่านเริ่มต้นในซอร์สโค้ด: ต้องกำหนด PJ_ADMIN_PASSWORD ใน .env
DEFAULT_ADMIN_PASSWORD = os.environ.get("PJ_ADMIN_PASSWORD", "")


# ------------------------------------------------------------------
# ข้อมูลสินค้า
# price = ราคาปัจจุบัน
# old_price = ราคาเดิม (ใส่ None เมื่อไม่มีส่วนลด)
# category = หมวดหลัก
# ------------------------------------------------------------------
PRODUCTS = [
    {
        "id": 1,
        "name": "RX-78-2 GUNDAM",
        "grade": "HG",
        "scale": "1/144",
        "price": 450,
        "old_price": 590,
        "stock": 12,
        "category": "GUNDAM GUNPLA",
        "badge": "SALE",
        "desc": "โมเดลเริ่มต้นยอดนิยม ต่อสนุก เหมาะกับทั้งมือใหม่และนักสะสม",
    },
    {
        "id": 2,
        "name": "GUNDAM BARBATOS",
        "grade": "HG",
        "scale": "1/144",
        "price": 590,
        "old_price": 690,
        "stock": 5,
        "category": "GUNDAM GUNPLA",
        "badge": "SALE",
        "desc": "ดีไซน์จาก Iron-Blooded Orphans พร้อมอาวุธหลักและชิ้นส่วนครบ",
    },
    {
        "id": 3,
        "name": "FREEDOM GUNDAM",
        "grade": "RG",
        "scale": "1/144",
        "price": 1290,
        "old_price": 1490,
        "stock": 4,
        "category": "GUNDAM GUNPLA",
        "badge": "SALE",
        "desc": "Real Grade รายละเอียดสูง พร้อมปีกขนาดใหญ่สำหรับจัดท่า",
    },
    {
        "id": 4,
        "name": "UNICORN GUNDAM",
        "grade": "RG",
        "scale": "1/144",
        "price": 1450,
        "old_price": None,
        "stock": 0,
        "category": "GUNDAM GUNPLA",
        "badge": "SOLD OUT",
        "desc": "เปลี่ยนโหมดได้ พร้อม Psycho-Frame และรายละเอียดระดับ Real Grade",
    },
    {
        "id": 5,
        "name": "STRIKE FREEDOM GUNDAM",
        "grade": "MG",
        "scale": "1/100",
        "price": 2890,
        "old_price": 3290,
        "stock": 3,
        "category": "GUNDAM GUNPLA",
        "badge": "SALE",
        "desc": "Master Grade พร้อมปีกขนาดใหญ่และรายละเอียดโครงในเต็มรูปแบบ",
    },
    {
        "id": 6,
        "name": "SAZABI VER.KA",
        "grade": "MG",
        "scale": "1/100",
        "price": 3990,
        "old_price": 4490,
        "stock": 2,
        "category": "GUNDAM GUNPLA",
        "badge": "SALE",
        "desc": "โมบิลสูทขนาดใหญ่ของ Char ดีเทลแน่น เหมาะกับนักสะสม",
    },
    {
        "id": 7,
        "name": "NU GUNDAM",
        "grade": "PG",
        "scale": "1/60",
        "price": 9900,
        "old_price": None,
        "stock": 1,
        "category": "GUNDAM GUNPLA",
        "badge": "NEW",
        "desc": "Perfect Grade สำหรับสายสะสมและผู้ที่ต้องการรายละเอียดระดับสูง",
    },
    {
        "id": 8,
        "name": "SD GUNDAM CROSS SILHOUETTE",
        "grade": "SD",
        "scale": "SD",
        "price": 350,
        "old_price": 420,
        "stock": 20,
        "category": "GUNDAM GUNPLA",
        "badge": "SALE",
        "desc": "ขนาดกะทัดรัด ต่อไม่ยาก เหมาะกับผู้เริ่มต้นและสะสมหลายตัว",
    },
    {
        "id": 9,
        "name": "ENTRY GRADE RX-78-2",
        "grade": "EG",
        "scale": "1/144",
        "price": 410,
        "old_price": 500,
        "stock": 9,
        "category": "GUNDAM GUNPLA",
        "badge": "SALE",
        "desc": "Entry Grade ใช้ชิ้นส่วนไม่ซับซ้อน เหมาะสำหรับเริ่มต้นต่อ Gunpla",
    },
    {
        "id": 10,
        "name": "GUNDAM AERIAL",
        "grade": "HG",
        "scale": "1/144",
        "price": 650,
        "old_price": 750,
        "stock": 7,
        "category": "GUNDAM GUNPLA",
        "badge": "NEW",
        "desc": "ชุดคิทยอดนิยม พร้อมอาวุธและอุปกรณ์เสริมสำหรับจัดท่า",
    },
    {
        "id": 11,
        "name": "MG GUNDAM RX-78-2 VER.3.0",
        "grade": "MG",
        "scale": "1/100",
        "price": 1790,
        "old_price": 2090,
        "stock": 6,
        "category": "GUNDAM GUNPLA",
        "badge": "SALE",
        "desc": "Master Grade ดีเทลแน่น พร้อมจุดขยับสำหรับจัดท่าที่หลากหลาย",
    },
    {
        "id": 12,
        "name": "HG ZAKU II",
        "grade": "HG",
        "scale": "1/144",
        "price": 520,
        "old_price": None,
        "stock": 10,
        "category": "GUNDAM GUNPLA",
        "badge": "HOT",
        "desc": "โมเดลคลาสสิกของ Zeon สำหรับเพิ่มความหลากหลายให้ตู้สะสม",
    },
]

GRADES = ["SD", "EG", "HG", "RG", "MG", "PG"]


# ------------------------------------------------------------------
# Templates
# ------------------------------------------------------------------
BASE = r"""<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" href="{{ logo_url }}">
<title>{% block title %}พีเจกันพลา{% endblock %}</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
:root{
  --navy:#111827;
  --navy-2:#1f2937;
  --blue:#2563eb;
  --blue-2:#1d4ed8;
  --cyan:#00a9e8;
  --red:#e53935;
  --yellow:#f7c948;
  --green:#16a34a;
  --bg:#f4f6f8;
  --card:#ffffff;
  --line:#e4e8ee;
  --text:#222b36;
  --muted:#718096;
  --max:1220px;
}

*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{
  margin:0;
  background:var(--bg);
  color:var(--text);
  font-family:"Kanit",system-ui,sans-serif;
  line-height:1.6;
}
a{color:inherit}
button,input,select,textarea{font:inherit}

.main-head .wrap,
.breadcrumb .wrap,
.page .wrap,
.footer .wrap{
  max-width:var(--max);
  margin:auto;
  padding-left:20px;
  padding-right:20px;
}

.main-head{
  background:#fff;
  border-bottom:1px solid var(--line);
}
.main-head .wrap{
  min-height:74px;
  display:flex;
  align-items:center;
  gap:18px;
}
.logo{
  text-decoration:none;
  font-size:1.65rem;
  font-weight:800;
  white-space:nowrap;
  letter-spacing:.01em;
}
.logo{display:flex;align-items:center;gap:10px}
.logo-img{width:48px;height:48px;object-fit:contain;flex:none}
.logo-img.round{border-radius:50%}
.logo span{color:var(--blue)}
.logo small{
  display:block;
  color:var(--muted);
  font-size:.67rem;
  font-weight:500;
  margin-top:-6px;
}
.search{
  flex:1;
  display:flex;
  max-width:670px;
  margin:auto;
}
.search input{
  width:100%;
  height:42px;
  border:1px solid #cfd7e3;
  border-right:0;
  border-radius:7px 0 0 7px;
  padding:0 14px;
  outline:none;
  background:#fff;
}
.search input:focus{border-color:var(--blue)}
.search button{
  width:52px;
  border:0;
  background:var(--blue);
  color:#fff;
  border-radius:0 7px 7px 0;
  cursor:pointer;
}
.head-actions{
  display:flex;
  gap:8px;
  align-items:center;
  white-space:nowrap;
}
.head-actions a{
  text-decoration:none;
  padding:7px 10px;
  border-radius:6px;
}
.head-actions a:hover{background:#f0f4f8}

.category-nav{
  background:var(--navy);
  color:#fff;
}
.category-nav .wrap{
  max-width:var(--max);
  margin:auto;
  padding:0 20px;
  min-height:44px;
  display:flex;
  align-items:center;
  gap:4px;
  overflow-x:auto;
}
.category-nav a{
  padding:10px 14px;
  text-decoration:none;
  font-size:.93rem;
  white-space:nowrap;
}
.category-nav a:hover,
.category-nav a.active{background:#273449}

.hero{
  max-width:var(--max);
  margin:20px auto 0;
  padding:0 20px;
}
.hero-box{
  min-height:225px;
  border-radius:12px;
  overflow:hidden;
  position:relative;
  display:flex;
  align-items:center;
  padding:32px;
  color:#fff;
  background:
    radial-gradient(circle at 83% 20%,rgba(0,169,232,.36),transparent 30%),
    radial-gradient(circle at 90% 90%,rgba(37,99,235,.28),transparent 32%),
    linear-gradient(135deg,#0a0f18,#1e293b 58%,#0f4c81);
  box-shadow:0 12px 28px rgba(15,23,42,.12);
}
.hero-box:after{
  content:"";
  position:absolute;
  width:300px;
  height:300px;
  right:-70px;
  top:-60px;
  border:30px solid rgba(255,255,255,.07);
  transform:rotate(20deg);
  border-radius:28px;
}
.hero-content{position:relative;z-index:1;max-width:650px}
.hero-logo{
  position:absolute;right:56px;top:50%;transform:translateY(-50%);
  width:185px;height:185px;object-fit:contain;z-index:1;
  filter:drop-shadow(0 8px 22px rgba(0,0,0,.45));
}
.hero-logo.round{border-radius:50%;box-shadow:0 0 0 4px rgba(255,255,255,.10),0 12px 38px rgba(37,99,235,.45)}
@media (max-width:960px){
  .hero-box{flex-direction:column;align-items:flex-start}
  .hero-logo{position:static;transform:none;width:112px;height:112px;margin-top:16px}
}
.hero-kicker{
  color:#8edcff;
  font-weight:700;
  letter-spacing:.08em;
  text-transform:uppercase;
  font-size:.86rem;
}
.hero h1{
  font-size:2.25rem;
  margin:4px 0;
  line-height:1.15;
}
.hero p{margin:10px 0 18px;color:#dce9f5}
.hero-buttons{display:flex;gap:9px;flex-wrap:wrap}
.btn{
  display:inline-flex;
  justify-content:center;
  align-items:center;
  min-height:40px;
  padding:8px 16px;
  border:0;
  border-radius:6px;
  text-decoration:none;
  cursor:pointer;
  font-weight:600;
}
.btn-primary{background:var(--blue);color:#fff}
.btn-primary:hover{background:var(--blue-2)}
.btn-dark{background:#243142;color:#fff}
.btn-danger{background:var(--red);color:#fff}
.btn-muted{background:#a4adba;color:#fff;cursor:not-allowed}

.page{padding-top:20px;padding-bottom:70px}
.layout{
  display:grid;
  grid-template-columns:245px minmax(0,1fr);
  gap:22px;
}
.sidebar{
  background:#fff;
  border:1px solid var(--line);
  border-radius:10px;
  height:max-content;
  overflow:hidden;
}
.side-title{
  padding:13px 15px;
  font-weight:800;
  background:#f7f9fb;
  border-bottom:1px solid var(--line);
}
.side-section{padding:12px 14px;border-bottom:1px solid var(--line)}
.side-section:last-child{border-bottom:0}
.side-section h3{
  margin:0 0 8px;
  font-size:1rem;
}
.side-link{
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:6px 8px;
  border-radius:6px;
  text-decoration:none;
  font-size:.92rem;
}
.side-link:hover,.side-link.active{background:#edf5ff;color:var(--blue)}
.count{color:#98a2b3;font-size:.82rem}

.content-head{
  display:flex;
  justify-content:space-between;
  align-items:flex-end;
  gap:12px;
  flex-wrap:wrap;
  margin-bottom:10px;
}
.content-head h2{
  margin:0;
  font-size:1.65rem;
}
.muted{color:var(--muted);font-size:.9rem}
.toolbar{
  display:flex;
  gap:8px;
  align-items:center;
  flex-wrap:wrap;
  margin:10px 0 18px;
}
.toolbar form{display:flex;gap:8px}
.toolbar select,
.toolbar input{
  height:38px;
  border:1px solid #cfd7e3;
  background:#fff;
  padding:0 11px;
  border-radius:6px;
}
.toolbar select{min-width:170px}

.pills{
  display:flex;
  gap:7px;
  flex-wrap:wrap;
  margin:8px 0 18px;
}
.pill{
  padding:5px 11px;
  border:1px solid #cfd7e3;
  background:#fff;
  border-radius:999px;
  text-decoration:none;
  font-size:.85rem;
}
.pill.active{background:var(--blue);border-color:var(--blue);color:#fff}

.grid{
  display:grid;
  grid-template-columns:repeat(4,minmax(0,1fr));
  gap:16px;
}
.card{
  background:var(--card);
  border:1px solid var(--line);
  border-radius:9px;
  overflow:hidden;
  display:flex;
  flex-direction:column;
  min-width:0;
  transition:transform .16s, box-shadow .16s;
}
.card:hover{
  transform:translateY(-3px);
  box-shadow:0 12px 22px rgba(15,23,42,.10);
}
.card-img{
  position:relative;
  aspect-ratio:1/1;
  background:
    linear-gradient(45deg,#edf1f5 25%,transparent 25%),
    linear-gradient(-45deg,#edf1f5 25%,transparent 25%),
    linear-gradient(45deg,transparent 75%,#edf1f5 75%),
    linear-gradient(-45deg,transparent 75%,#edf1f5 75%);
  background-size:22px 22px;
  background-position:0 0,0 11px,11px -11px,-11px 0;
  display:grid;
  place-items:center;
  overflow:hidden;
}
.card-img img{
  width:100%;
  height:100%;
  object-fit:contain;
  background:#fff;
}
.placeholder{
  width:73%;
  height:73%;
  display:grid;
  place-items:center;
  text-align:center;
  border:2px solid #bfc9d6;
  background:linear-gradient(180deg,#fff,#e8edf3);
  color:#284565;
  font-weight:800;
  padding:12px;
  clip-path:polygon(50% 0,61% 9%,84% 10%,77% 28%,100% 41%,83% 54%,92% 83%,65% 75%,50% 100%,35% 75%,8% 83%,17% 54%,0 41%,23% 28%,16% 10%,39% 9%);
}
.badge{
  position:absolute;
  left:9px;
  top:9px;
  padding:3px 8px;
  border-radius:4px;
  background:var(--red);
  color:#fff;
  font-size:.72rem;
  font-weight:800;
  z-index:2;
}
.badge.green{background:var(--green)}
.badge.dark{background:var(--navy)}

.card-body{padding:12px 12px 13px;display:flex;flex-direction:column;gap:5px;flex:1}
.product-name{
  text-decoration:none;
  font-weight:700;
  font-size:.96rem;
  min-height:47px;
}
.product-name:hover{color:var(--blue)}
.meta{
  display:flex;
  gap:6px;
  flex-wrap:wrap;
}
.tag{
  display:inline-block;
  font-size:.72rem;
  background:#edf2f7;
  color:#4a5568;
  padding:2px 7px;
  border-radius:4px;
}
.price-row{
  display:flex;
  align-items:baseline;
  gap:8px;
  margin-top:auto;
}
.price{
  font-size:1.2rem;
  font-weight:800;
  color:var(--blue-2);
}
.old-price{
  color:#9aa4b2;
  text-decoration:line-through;
  font-size:.82rem;
}
.card-footer{padding-top:7px}
.card-footer form{margin:0}
.buy-btn{width:100%}

.breadcrumb{
  margin-top:12px;
}
.breadcrumb .wrap{
  font-size:.87rem;
  color:var(--muted);
}
.breadcrumb a{text-decoration:none}
.breadcrumb a:hover{color:var(--blue)}

.detail{
  background:#fff;
  border:1px solid var(--line);
  border-radius:10px;
  padding:20px;
}
.detail-grid{
  display:grid;
  grid-template-columns:minmax(280px,1fr) minmax(300px,1fr);
  gap:28px;
}
.detail-image{
  aspect-ratio:1/1;
  background:#f7f9fb;
  border-radius:8px;
  overflow:hidden;
}
.detail-image img{width:100%;height:100%;object-fit:contain}
.detail-info h1{margin:0 0 7px;font-size:2rem;line-height:1.2}
.detail-info p{color:#596575}
.detail-price{font-size:1.7rem;font-weight:800;color:var(--blue-2)}
.detail-old{text-decoration:line-through;color:#9aa4b2;margin-left:7px}
.stock-ok{color:var(--green);font-weight:600}
.stock-out{color:var(--red);font-weight:600}
.qty{
  width:90px;
  height:40px;
  border:1px solid #cfd7e3;
  border-radius:6px;
  padding:0 10px;
}
.form-row{display:flex;gap:8px;align-items:center;margin-top:12px}

.flash{
  max-width:var(--max);
  margin:14px auto 0;
  padding:10px 20px;
}
.flash div{
  background:#fff4cf;
  border:1px solid #f0d675;
  color:#6b5600;
  padding:9px 12px;
  border-radius:7px;
}

.table-wrap{
  overflow:auto;
  background:#fff;
  border:1px solid var(--line);
  border-radius:9px;
}
table{width:100%;border-collapse:collapse;min-width:650px}
th,td{padding:11px 12px;border-bottom:1px solid var(--line);text-align:left}
th{background:#f7f9fb;font-weight:700}
.total{
  text-align:right;
  font-size:1.4rem;
  font-weight:800;
  margin:18px 0;
}

.form-card{
  max-width:600px;
  background:#fff;
  border:1px solid var(--line);
  border-radius:9px;
  padding:22px;
}
label{display:block;font-weight:600;margin:12px 0 5px}
.form-card input{
  width:100%;
  height:42px;
  border:1px solid #cfd7e3;
  border-radius:6px;
  padding:0 11px;
}
.form-card input:focus{outline:2px solid rgba(37,99,235,.16);border-color:var(--blue)}

.footer{
  background:#111827;
  color:#d7dfeb;
  margin-top:20px;
}
.footer .wrap{padding-top:30px;padding-bottom:30px}
.footer h3{margin-top:0;color:#fff}
.footer-grid{
  display:grid;
  grid-template-columns:1.3fr 1fr 1fr 1.4fr;
  gap:20px;
}
.footer p strong{color:#fff}
.footer h3 a{color:#fff}
.footer h3 a:hover{color:#8edcff}
.st{display:inline-block;padding:4px 12px;border-radius:999px;font-weight:700;font-size:13px;line-height:1.35}
.st-pending{background:#fff4db;color:#9a6700}
.st-reported{background:#e0efff;color:#1d4ed8}
.st-paid{background:#ffedd5;color:#b45309}
.st-preparing{background:#ede9fe;color:#6d28d9}
.st-shipping{background:#cffafe;color:#0e7490}
.st-delivered{background:#dcfce7;color:#15803d}
.st-cancelled{background:#fee2e2;color:#b91c1c}
@media (max-width:1000px){.footer-grid{grid-template-columns:1fr 1fr}}
.footer p{color:#aeb8c6;margin:6px 0}
.footer a{text-decoration:none;color:#d7dfeb}
.footer a:hover{color:#fff}

.empty{
  padding:45px 15px;
  background:#fff;
  border:1px dashed #cbd5e1;
  border-radius:9px;
  text-align:center;
  color:var(--muted);
}

@media (max-width:1100px){
  .grid{grid-template-columns:repeat(3,minmax(0,1fr))}
}
@media (max-width:860px){
  .layout{grid-template-columns:1fr}
  .sidebar{display:none}
  .main-head .wrap{flex-wrap:wrap;padding-top:10px;padding-bottom:10px}
  .search{order:3;flex-basis:100%;max-width:none}
  .hero-box{min-height:195px;padding:24px}
  .detail-grid{grid-template-columns:1fr}
}
@media (max-width:650px){
  .grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
  .hero h1{font-size:1.65rem}
  .hero-box{padding:20px}
  .logo{font-size:1.4rem}
  .head-actions a{padding:5px 7px}
  .product-name{font-size:.88rem}
  .price{font-size:1.05rem}
  .footer-grid{grid-template-columns:1fr}
}
@media (max-width:460px){
  .grid{grid-template-columns:1fr 1fr}
  .card-body{padding:9px}
  .meta .tag{font-size:.68rem}
}
</style>
</head>

<body>
<header class="main-head">
  <div class="wrap">
    <a class="logo" href="{{ url_for('home') }}"><img class="logo-img{{ ' round' if logo_default else '' }}" src="{{ logo_url }}" alt="PJGUNPLA"><div class="logo-text">PJ<span>GUNPLA</span><small>GUNDAM PLASTIC MODEL</small></div></a>

    <form class="search" method="get" action="{{ url_for('home') }}">
      <input
        type="search"
        name="q"
        value="{{ q or '' }}"
        placeholder="ค้นหาสินค้า เช่น Gundam, Barbatos, MG..."
        aria-label="ค้นหาสินค้า"
      >
      {% if grade %}
      <input type="hidden" name="grade" value="{{ grade }}">
      {% endif %}
      <button type="submit">🔍</button>
    </form>

    <div class="head-actions">
      {% if user_role != 'admin' %}<a href="{{ url_for('cart') }}">🛒 ตะกร้า ({{ cart_count }})</a>{% endif %}
      {% if user %}{% if user_role != 'admin' %}<a href="{{ url_for('my_orders') }}">📦 คำสั่งซื้อ</a>{% endif %}<a href="{{ url_for('profile') }}">👤 ข้อมูลส่วนตัว</a>{% endif %}
      {% if user_role == 'admin' %}
        <a href="{{ url_for('admin_dashboard') }}">⚙️ แอดมิน</a>
      {% endif %}
      {% if user %}
        <a href="{{ url_for('logout') }}">ออกจากระบบ</a>
      {% else %}
        <a href="{{ url_for('login') }}">เข้าสู่ระบบ</a>
      {% endif %}
    </div>
  </div>
</header>

<nav class="category-nav">
  <div class="wrap">
    <a class="{{ 'active' if not grade else '' }}" href="{{ url_for('home') }}">GUNDAM GUNPLA</a>
    {% for g in grades %}
      <a class="{{ 'active' if grade == g else '' }}" href="{{ url_for('home', grade=g, q=q) }}">{{ g }}</a>
    {% endfor %}
    <a href="{{ url_for('home', sale='1', q=q) }}">🔥 SALE</a>
    <a href="{{ url_for('home', new='1', q=q) }}">✨ NEW ARRIVAL</a>
  </div>
</nav>

{% for m in get_flashed_messages() %}
<div class="flash"><div>{{ m }}</div></div>
{% endfor %}

{% block full_content %}{% endblock %}

<footer class="footer">
  <div class="wrap">
    <div class="footer-grid">
      <div>
        <h3>PJ GUNPLA</h3>
        <p>ร้านจำลองสำหรับโปรเจกต์ Flask</p>
        <p>Gundam Plastic Model • FUN TO BUILD GUNPLA</p>
      </div>
      <div>
        <h3>หมวดสินค้า</h3>
        <p><a href="{{ url_for('home') }}">Gundam Gunpla</a></p>
        <p><a href="{{ url_for('home', grade='HG') }}">High Grade (HG)</a></p>
        <p><a href="{{ url_for('home', grade='RG') }}">Real Grade (RG)</a></p>
        <p><a href="{{ url_for('home', grade='MG') }}">Master Grade (MG)</a></p>
      </div>
      <div>
        <h3>บัญชีของฉัน</h3>
        <p><a href="{{ url_for('cart') }}">ตะกร้าสินค้า</a></p>
        <p><a href="{{ url_for('login') }}">เข้าสู่ระบบ</a></p>
        <p><a href="{{ url_for('register') }}">สมัครสมาชิก</a></p>
      </div>
      <div>
        <h3><a href="{{ url_for('owner_page') }}">ข้อมูลเจ้าของร้าน ›</a></h3>
        <p><strong><a href="{{ url_for('owner_page') }}">{{ owner.full_name }}</a></strong><br>{{ owner.position }}</p>
        <p>📞 <a href="tel:{{ owner.phone }}">{{ owner.phone }}</a></p>
        <p>Facebook: {{ owner.facebook }}</p>
        {% if shop_contact.email %}<p>✉️ <a href="mailto:{{ shop_contact.email }}">{{ shop_contact.email }}</a></p>{% endif %}
        {% if shop_contact.line %}<p>LINE: {{ shop_contact.line }}</p>{% endif %}
        {% if shop_contact.address %}<p>📍 {{ shop_contact.address }}</p>{% endif %}
        <p><a href="{{ url_for('owner_page') }}" style="color:#8edcff">ดูข้อมูลเจ้าของร้านทั้งหมด →</a></p>
      </div>
    </div>
  </div>
</footer>
</body>
</html>
"""

HOME = r"""{% extends 'base.html' %}
{% block title %}PJ GUNPLA | Gundam Plastic Model{% endblock %}

{% block full_content %}
<section class="hero">
  <div class="hero-box">
    <div class="hero-content">
      <div class="hero-kicker">GUNDAM PLASTIC MODEL</div>
      <h1>FUN TO BUILD GUNPLA</h1>
      <p>รวม Gunpla หลายเกรดในหน้าร้านเดียว ค้นหาและเลือกซื้อได้ง่าย พร้อมระบบตะกร้าสินค้า</p>
      <div class="hero-buttons">
        <a class="btn btn-primary" href="#products">ดูสินค้าทั้งหมด</a>
        <a class="btn btn-dark" href="{{ url_for('home', sale='1') }}">ดูสินค้า SALE</a>
      </div>
    </div>
    <img class="hero-logo{{ ' round' if logo_default else '' }}" src="{{ logo_url }}" alt="โลโก้ PJGUNPLA">
  </div>
</section>

<section class="page">
  <div class="wrap">
    <div class="layout">
      <aside class="sidebar">
        <div class="side-title">OUR PRODUCTS</div>

        <div class="side-section">
          <h3>หมวดหลัก</h3>
          <a class="side-link {{ 'active' if not grade and not sale and not new else '' }}" href="{{ url_for('home') }}">
            <span>🔵 GUNDAM GUNPLA</span>
            <span class="count">{{ all_count }}</span>
          </a>
          <a class="side-link {{ 'active' if sale else '' }}" href="{{ url_for('home', sale='1', q=q) }}">
            <span>🔥 CLEARANCE SALE</span>
            <span class="count">{{ sale_count }}</span>
          </a>
          <a class="side-link {{ 'active' if new else '' }}" href="{{ url_for('home', new='1', q=q) }}">
            <span>✨ NEW ARRIVAL</span>
            <span class="count">{{ new_count }}</span>
          </a>
        </div>

        <div class="side-section">
          <h3>GRADE</h3>
          {% for g in grades %}
          <a class="side-link {{ 'active' if grade == g else '' }}" href="{{ url_for('home', grade=g, q=q) }}">
            <span>{{ g }} — {{ grade_names[g] }}</span>
            <span class="count">{{ grade_counts[g] }}</span>
          </a>
          {% endfor %}
        </div>
      </aside>

      <main id="products">
        <div class="content-head">
          <div>
            <h2>🔵 GUNDAM GUNPLA</h2>
            <div class="muted">สินค้าทั้งหมด {{ shown_count }} รายการ</div>
          </div>
        </div>

        <div class="pills">
          <a class="pill {{ 'active' if not grade else '' }}" href="{{ url_for('home', q=q, sale=('1' if sale else None), new=('1' if new else None)) }}">ทั้งหมด</a>
          {% for g in grades %}
            <a class="pill {{ 'active' if grade == g else '' }}" href="{{ url_for('home', grade=g, q=q, sale=('1' if sale else None), new=('1' if new else None)) }}">{{ g }}</a>
          {% endfor %}
        </div>

        <div class="toolbar">
          <form method="get" action="{{ url_for('home') }}">
            {% if grade %}<input type="hidden" name="grade" value="{{ grade }}">{% endif %}
            {% if sale %}<input type="hidden" name="sale" value="1">{% endif %}
            {% if new %}<input type="hidden" name="new" value="1">{% endif %}
            <select name="sort" onchange="this.form.submit()">
              <option value="default" {% if sort == 'default' %}selected{% endif %}>เรียงตามสินค้าแนะนำ</option>
              <option value="price_asc" {% if sort == 'price_asc' %}selected{% endif %}>ราคา: ต่ำ → สูง</option>
              <option value="price_desc" {% if sort == 'price_desc' %}selected{% endif %}>ราคา: สูง → ต่ำ</option>
              <option value="name" {% if sort == 'name' %}selected{% endif %}>ชื่อสินค้า A → Z</option>
            </select>
          </form>

          {% if q %}
            <span class="muted">ผลการค้นหา: “{{ q }}”</span>
          {% endif %}
          {% if grade %}
            <span class="muted">/ เกรด {{ grade }}</span>
          {% endif %}
        </div>

        {% if products %}
        <div class="grid">
          {% for p in products %}
          <article class="card">
            <div class="card-img">
              {% set u = img_of(p) %}
              {% if p.badge == "SALE" %}
                <span class="badge">SALE</span>
              {% elif p.badge == "NEW" %}
                <span class="badge green">NEW</span>
              {% elif p.badge == "HOT" %}
                <span class="badge dark">HOT</span>
              {% elif p.badge == "SOLD OUT" %}
                <span class="badge dark">SOLD OUT</span>
              {% endif %}

              {% if u %}
                <img src="{{ u }}" alt="{{ p.name }}" loading="lazy">
              {% else %}
                <div class="placeholder">{{ p.grade }}<br>{{ p.name }}</div>
              {% endif %}
            </div>

            <div class="card-body">
              <div class="meta">
                <span class="tag">{{ p.grade }}</span>
                <span class="tag">{{ p.scale }}</span>
              </div>
              <a class="product-name" href="{{ url_for('product', pid=p.id) }}">{{ p.name }}</a>

              <div class="price-row">
                <span class="price">฿{{ '{:,}'.format(p.price) }}</span>
                {% if p.old_price %}
                  <span class="old-price">฿{{ '{:,}'.format(p.old_price) }}</span>
                {% endif %}
              </div>

              <div class="card-footer">
                {% if p.stock %}
                  <form method="post" action="{{ url_for('add', pid=p.id) }}">
                    <input type="hidden" name="qty" value="1">
                    <button class="btn btn-primary buy-btn" type="submit">สั่งซื้อ</button>
                  </form>
                {% else %}
                  <button class="btn btn-muted buy-btn" disabled>สินค้าหมด</button>
                {% endif %}
              </div>
            </div>
          </article>
          {% endfor %}
        </div>
        {% else %}
          <div class="empty">
            <div style="font-size:2rem">🔎</div>
            ไม่พบสินค้าที่ตรงกับเงื่อนไขที่เลือก
            <br>
            <a href="{{ url_for('home') }}">แสดงสินค้าทั้งหมด</a>
          </div>
        {% endif %}
      </main>
    </div>
  </div>
</section>
{% endblock %}
"""

PRODUCT = r"""{% extends 'base.html' %}
{% block title %}{{ p.name }} | PJ GUNPLA{% endblock %}

{% block full_content %}
<div class="breadcrumb"><div class="wrap">
  <a href="{{ url_for('home') }}">GUNDAM GUNPLA</a> / {{ p.name }}
</div></div>

<section class="page">
  <div class="wrap">
    <div class="detail">
      <div class="detail-grid">
        <div class="detail-image">
          {% set u = img_of(p) %}
          {% if u %}
            <img src="{{ u }}" alt="{{ p.name }}">
          {% else %}
            <div class="placeholder" style="width:65%;height:65%;margin:17.5%;font-size:1.15rem">
              {{ p.grade }}<br>{{ p.name }}
            </div>
          {% endif %}
        </div>

        <div class="detail-info">
          <div class="meta">
            <span class="tag">{{ p.grade }}</span>
            <span class="tag">{{ p.scale }}</span>
            <span class="tag">{{ p.category }}</span>
          </div>

          <h1>{{ p.name }}</h1>

          <div style="margin:18px 0 4px">
            <span class="detail-price">฿{{ '{:,}'.format(p.price) }}</span>
            {% if p.old_price %}
              <span class="detail-old">฿{{ '{:,}'.format(p.old_price) }}</span>
            {% endif %}
          </div>

          {% if p.stock %}
            <div class="stock-ok">✓ มีสินค้าในสต็อก {{ p.stock }} ชิ้น</div>
          {% else %}
            <div class="stock-out">✕ สินค้าหมดชั่วคราว</div>
          {% endif %}

          <p>{{ p.desc }}</p>

          {% if p.stock %}
          <form method="post" action="{{ url_for('add', pid=p.id) }}">
            <div class="form-row">
              <input class="qty" type="number" name="qty" min="1" max="{{ p.stock }}" value="1">
              <button class="btn btn-primary" type="submit">🛒 เพิ่มลงตะกร้า</button>
            </div>
          </form>
          {% else %}
            <button class="btn btn-muted" disabled>สินค้าหมด</button>
          {% endif %}

          <p style="margin-top:18px">
            <a href="{{ url_for('home') }}">← กลับไปเลือกสินค้า</a>
          </p>
        </div>
      </div>
    </div>
  </div>
</section>
{% endblock %}
"""

CART = r"""{% extends 'base.html' %}
{% block title %}ตะกร้าสินค้า | PJ GUNPLA{% endblock %}

{% block full_content %}
<div class="breadcrumb"><div class="wrap">ตะกร้าสินค้า</div></div>
<section class="page">
  <div class="wrap">
    <h2>🛒 ตะกร้าสินค้า</h2>

    {% if items %}
    <div class="table-wrap">
      <table>
        <tr>
          <th>สินค้า</th>
          <th>เกรด</th>
          <th>ราคา</th>
          <th>จำนวน</th>
          <th>รวม</th>
          <th></th>
        </tr>
        {% for i in items %}
        <tr>
          <td>
            <strong>{{ i.p.name }}</strong>
          </td>
          <td>{{ i.p.grade }}</td>
          <td>฿{{ '{:,}'.format(i.p.price) }}</td>
          <td>{{ i.qty }}</td>
          <td>฿{{ '{:,}'.format(i.sub) }}</td>
          <td>
            <form method="post" action="{{ url_for('remove', pid=i.p.id) }}">
              <button class="btn btn-danger" type="submit">ลบ</button>
            </form>
          </td>
        </tr>
        {% endfor %}
      </table>
    </div>

    <p class="total">รวมทั้งหมด ฿{{ '{:,}'.format(total) }}</p>
    <div style="display:flex;justify-content:flex-end;gap:8px">
      <a class="btn btn-dark" href="{{ url_for('home') }}">เลือกสินค้าเพิ่ม</a>
      <a class="btn btn-primary" href="{{ url_for('checkout') }}">ไปหน้าชำระเงิน</a>
    </div>
    {% else %}
      <div class="empty">
        🛒 ตะกร้ายังว่างอยู่
        <br>
        <a href="{{ url_for('home') }}">เลือก Gunpla ไปต่อได้เลย</a>
      </div>
    {% endif %}
  </div>
</section>
{% endblock %}
"""

CHECKOUT = r"""{% extends 'base.html' %}
{% block title %}ยืนยันที่อยู่จัดส่ง | PJ GUNPLA{% endblock %}
{% block full_content %}
<div class="breadcrumb"><div class="wrap">ยืนยันที่อยู่จัดส่ง</div></div>
<section class="page"><div class="wrap">
  <div class="form-card">
    <h2>📦 ตรวจสอบข้อมูลจัดส่ง</h2>
    <p class="muted">ยอดที่ต้องชำระ <strong style="color:#1d4ed8">฿{{ '{:,}'.format(total) }}</strong></p>
    <form method="post">
      <label for="name">ชื่อผู้รับ <small class="muted">(ชื่อ-นามสกุล)</small></label>
      <input id="name" name="name" maxlength="120" autocomplete="name" placeholder="เช่น สมชาย ใจดี"
             pattern="[A-Za-z\u0E01-\u0E3A\u0E40-\u0E4E][A-Za-z\u0E01-\u0E3A\u0E40-\u0E4E.'\-]+(?:\s+[A-Za-z\u0E01-\u0E3A\u0E40-\u0E4E][A-Za-z\u0E01-\u0E3A\u0E40-\u0E4E.'\-]+)+"
             title="ต้องเป็นชื่อและนามสกุล คั่นด้วยเว้นวรรค ตัวอักษรไทยหรืออังกฤษเท่านั้น เช่น สมชาย ใจดี"
             value="{{ form.get('name', '') }}" required>
      {% if errors.name %}<div class="field-error">{{ errors.name }}</div>{% endif %}

      {% if need_email %}
      <label for="email">อีเมล <small class="muted">(บันทึกเข้าบัญชีของคุณ)</small></label>
      <input id="email" name="email" type="email" maxlength="254" placeholder="name@example.com" value="{{ form.get('email', '') }}" required>
      {% if errors.email %}<div class="field-error">{{ errors.email }}</div>{% endif %}
      {% endif %}

      <label for="phone">เบอร์โทรศัพท์ <small class="muted">(ตัวเลขเท่านั้น 9-10 หลัก)</small></label>
      <input id="phone" name="phone" type="tel" inputmode="numeric" maxlength="10" placeholder="0812345678"
             pattern="0[0-9]{8,9}" title="ตัวเลขเท่านั้น ขึ้นต้นด้วย 0 และมี 9-10 หลัก เช่น 0812345678"
             oninput="this.value=this.value.replace(/[^0-9]/g,'')" value="{{ form.get('phone', '') }}" required>
      {% if errors.phone %}<div class="field-error">{{ errors.phone }}</div>{% endif %}

      <label for="addr">บ้านเลขที่ / หมู่บ้าน / ถนน</label>
      <input id="addr" name="addr" maxlength="250" placeholder="เช่น 123/4 หมู่ 5 ถ.มิตรภาพ"
             pattern=".*[0-9\u0E50-\u0E59].*" title="ต้องมีบ้านเลขที่ (ตัวเลข) เช่น 123/4 หมู่ 5 ถ.มิตรภาพ"
             value="{{ form.get('addr', '') }}" required>
      {% if errors.addr %}<div class="field-error">{{ errors.addr }}</div>{% endif %}

      <label for="subdistrict">ตำบล / แขวง</label>
      <input id="subdistrict" name="subdistrict" maxlength="100" placeholder="ภาษาไทยเท่านั้น เช่น ในเมือง"
             pattern="[\u0E01-\u0E3A\u0E40-\u0E4E\s.\-]{2,}" title="ตัวอักษรไทยเท่านั้น ไม่มีตัวเลข"
             value="{{ form.get('subdistrict', '') }}" required>
      {% if errors.subdistrict %}<div class="field-error">{{ errors.subdistrict }}</div>{% endif %}

      <label for="district">อำเภอ / เขต</label>
      <input id="district" name="district" maxlength="100" placeholder="ภาษาไทยเท่านั้น เช่น เมืองขอนแก่น"
             pattern="[\u0E01-\u0E3A\u0E40-\u0E4E\s.\-]{2,}" title="ตัวอักษรไทยเท่านั้น ไม่มีตัวเลข"
             value="{{ form.get('district', '') }}" required>
      {% if errors.district %}<div class="field-error">{{ errors.district }}</div>{% endif %}

      <label for="province">จังหวัด</label>
      <input id="province" name="province" maxlength="100" list="province-list" autocomplete="off"
             placeholder="พิมพ์แล้วเลือกจากรายการ" value="{{ form.get('province', '') }}" required>
      <datalist id="province-list">{% for pv in provinces %}<option value="{{ pv }}">{% endfor %}</datalist>
      {% if errors.province %}<div class="field-error">{{ errors.province }}</div>{% endif %}

      <label for="zipcode">รหัสไปรษณีย์</label>
      <input id="zipcode" name="zipcode" pattern="[0-9]{5}" maxlength="5" inputmode="numeric" placeholder="เช่น 40000"
             title="ตัวเลข 5 หลัก" oninput="this.value=this.value.replace(/[^0-9]/g,'')"
             value="{{ form.get('zipcode', '') }}" required>
      {% if errors.zipcode %}<div class="field-error">{{ errors.zipcode }}</div>{% endif %}
      <p class="muted">เมื่อกดปุ่มด้านล่าง ระบบจะบันทึกคำสั่งซื้อและแสดง QR สำหรับสแกนจ่ายเงิน โปรดตรวจสอบชื่อผู้รับและที่อยู่ให้ถูกต้อง</p>
      <div style="margin-top:18px"><button class="btn btn-primary" type="submit">ยืนยันที่อยู่และไปชำระเงิน</button>
      <a class="btn btn-dark" href="{{ url_for('cart') }}">กลับไปตะกร้า</a></div>
    </form>
  </div>
</div></section>
<style>.field-error{color:#b91c1c;font-size:13.5px;margin:4px 2px 0}</style>
<script>
(function(){
  var input=document.getElementById('province');
  var list=[].map.call(document.querySelectorAll('#province-list option'),function(o){return o.value});
  var alias={'กทม':'กรุงเทพมหานคร','กรุงเทพ':'กรุงเทพมหานคร','กรุงเทพฯ':'กรุงเทพมหานคร','อยุธยา':'พระนครศรีอยุธยา','โคราช':'นครราชสีมา'};
  function check(){
    var v=input.value.trim().replace(/^(จังหวัด|จ\.)\s*/,'');
    v=alias[v]||v;
    input.setCustomValidity(v&&list.indexOf(v)<0?'ไม่พบจังหวัดนี้ กรุณาพิมพ์ชื่อจังหวัดให้ถูกต้อง':'');
  }
  input.addEventListener('input',check); check();
})();
</script>
{% endblock %}
"""

LOGIN = r"""{% extends 'base.html' %}
{% block title %}เข้าสู่ระบบ | PJ GUNPLA{% endblock %}

{% block full_content %}
<section class="page">
  <div class="wrap">
    <div class="form-card">
      <h2>เข้าสู่ระบบ</h2>
      <form method="post">
        <input type="hidden" name="next" value="{{ next }}">
        <label for="u">ชื่อผู้ใช้</label>
        <input id="u" name="username" required autofocus>

        <label for="p">รหัสผ่าน</label>
        <input id="p" name="password" type="password" required>

        <div style="margin-top:18px;display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn btn-primary" type="submit">เข้าสู่ระบบ</button>
          <button class="btn btn-dark" type="submit" name="admin_login" value="1">⚙️ แอดมิน</button>
        </div>
      </form>
      <p class="muted">ยังไม่มีบัญชี? <a href="{{ url_for('register') }}">สมัครสมาชิก</a></p>
    </div>
  </div>
</section>
{% endblock %}
"""

REGISTER = r"""{% extends 'base.html' %}
{% block title %}สมัครสมาชิก | PJ GUNPLA{% endblock %}

{% block full_content %}
<section class="page">
  <div class="wrap">
    <div class="form-card">
      <h2>สมัครสมาชิก</h2>
      <form method="post">
        <label for="u">ชื่อผู้ใช้ (อย่างน้อย 3 ตัวอักษร)</label>
        <input id="u" name="username" required autofocus value="{{ request.form.get('username', '') }}">

        <label for="em">อีเมล</label>
        <input id="em" name="email" type="email" maxlength="254" placeholder="name@example.com" required value="{{ request.form.get('email', '') }}">

        <label for="p">รหัสผ่าน (อย่างน้อย 6 ตัวอักษร)</label>
        <input id="p" name="password" type="password" required>

        <label for="c">ยืนยันรหัสผ่าน</label>
        <input id="c" name="confirm" type="password" required>

        <div style="margin-top:18px">
          <button class="btn btn-primary" type="submit">สมัครสมาชิก</button>
        </div>
      </form>
      <p class="muted">มีบัญชีแล้ว? <a href="{{ url_for('login') }}">เข้าสู่ระบบ</a></p>
    </div>
  </div>
</section>
{% endblock %}
"""

PAYMENT = r"""{% extends 'base.html' %}
{% block title %}ชำระเงิน | PJ GUNPLA{% endblock %}
{% block full_content %}
<section class="page"><div class="wrap">
  <div class="detail" style="max-width:760px;margin:auto">
    <h2>💳 ชำระเงินด้วย PromptPay</h2>
    <p>เลขคำสั่งซื้อ <strong>{{ order.order_code }}</strong></p>
    <p class="total" style="text-align:left">ยอดชำระ ฿{{ '{:,.2f}'.format(order.total) }}</p>
    <div style="display:flex;gap:14px;flex-wrap:wrap;background:#f1f6ff;border:1px solid #cfe0ff;border-radius:10px;padding:12px 16px;margin:10px 0">
      <div><div class="muted" style="font-size:13px">ธนาคาร</div><strong>{{ pay.bank }} ({{ pay.bank_short }})</strong></div>
      <div><div class="muted" style="font-size:13px">PromptPay (เบอร์โทร)</div><strong>{{ pay.promptpay_display }}</strong></div>
      <div><div class="muted" style="font-size:13px">ยอดที่ต้องโอน</div><strong>฿{{ '{:,.2f}'.format(order.total) }}</strong></div>
    </div>
    {% if qr_data_uri %}
      <div style="text-align:center;margin:20px 0">
        <img src="{{ qr_data_uri }}" alt="PromptPay QR สำหรับคำสั่งซื้อ {{ order.order_code }}" style="display:block;width:320px;max-width:90%;height:auto;margin:0 auto;background:#fff;padding:10px;border:1px solid #e5e7eb;border-radius:10px">
        {% if qr_is_static %}
          <p class="muted">QR PromptPay ของร้าน กรุณาสแกนเพื่อตรวจสอบชื่อผู้รับ และกรอกยอดให้ตรงกับคำสั่งซื้อ ฿{{ '{:,.2f}'.format(order.total) }} ก่อนชำระเงิน</p>
        {% else %}
          <p class="muted">สแกนด้วยแอปธนาคารใดก็ได้ ยอดเงิน ฿{{ '{:,.2f}'.format(order.total) }} ถูกกำหนดใน QR ให้ตรงกับคำสั่งซื้อแล้ว กรุณาตรวจสอบชื่อผู้รับและยอดเงินก่อนยืนยันการโอน</p>
          <p class="muted" style="font-size:13.5px">สแกนไม่ได้? โอนเข้า PromptPay {{ pay.promptpay_display }} ({{ pay.bank }}) ยอด ฿{{ '{:,.2f}'.format(order.total) }}</p>
        {% endif %}
      </div>
    {% else %}
      <div class="flash"><div>ยังไม่สามารถสร้าง QR ได้ กรุณาแจ้งผู้ดูแลร้าน</div></div>
    {% endif %}
    <p><strong>สถานะ:</strong> {{ payment_label }}</p>
    <p class="muted">ระบบตัวอย่างนี้ยังตรวจสอบยอดเงินกับธนาคารโดยอัตโนมัติไม่ได้ หลังโอนเงินให้กดแจ้งชำระเงิน และรอผู้ดูแลตรวจสอบก่อนถือว่าชำระสำเร็จ</p>
    {% if order.payment_status == 'pending' %}
    <form method="post" enctype="multipart/form-data" action="{{ url_for('report_payment', order_id=order.id) }}" onsubmit="return confirm('ยืนยันว่าได้โอนเงินและแนบสลิปถูกต้องแล้วใช่หรือไม่?');" style="margin-top:14px;padding:14px;border:1px dashed #cbd5e1;border-radius:10px;background:#f8fafc">
      <label for="slip" style="margin-top:0">📎 แนบสลิปโอนเงิน (JPG / PNG / WEBP ไม่เกิน 8 MB)</label>
      <input id="slip" name="slip" type="file" accept="image/png,image/jpeg,image/webp" required onchange="var f=this.files[0],i=document.getElementById('slip-preview');if(f){i.src=URL.createObjectURL(f);i.style.display='block'}">
      <img id="slip-preview" alt="ตัวอย่างสลิป" style="display:none;max-width:240px;max-height:320px;margin:10px 0;border:1px solid #e5e7eb;border-radius:8px">
      <div style="margin-top:10px"><button class="btn btn-primary" type="submit">ฉันชำระเงินแล้ว — ส่งสลิปให้ร้านตรวจสอบ</button></div>
    </form>
    {% else %}{% if order.slip_path %}<p><strong>สลิปที่แนบ:</strong><br><a href="{{ url_for('order_slip', order_id=order.id) }}" target="_blank"><img src="{{ url_for('order_slip', order_id=order.id) }}" alt="สลิปโอนเงิน" style="max-width:220px;max-height:300px;border:1px solid #e5e7eb;border-radius:8px"></a></p>{% endif %}<a class="btn btn-primary" href="{{ url_for('order_detail', order_id=order.id) }}">ดูคำสั่งซื้อและใบ PDF</a>{% if order.payment_status in ['reported', 'paid'] %} <a class="btn btn-dark" target="_blank" href="{{ url_for('payment_receipt_print', order_id=order.id, download=1) }}">⬇️ ใบเสร็จ PDF</a>{% endif %}{% endif %}
  </div>
</div></section>
{% endblock %}
"""

ORDER_DETAIL = r"""{% extends 'base.html' %}
{% block title %}คำสั่งซื้อ {{ order.order_code }} | PJ GUNPLA{% endblock %}
{% block full_content %}
<section class="page"><div class="wrap">
  <div class="detail">
    <h2>🧾 รายละเอียดคำสั่งซื้อ</h2>
    <p>เลขคำสั่งซื้อ: <strong>{{ order.order_code }}</strong></p>
    <p>วันที่: {{ order.created_at }}</p>
    <p>สถานะชำระเงิน: <strong>{{ payment_label }}</strong></p>
    <p>ผู้รับ: {{ order.recipient }} | โทร. {{ order.phone }}</p>
    <p>ที่อยู่: {{ order.address }}</p>
    <div class="table-wrap"><table><tr><th>สินค้า</th><th>ราคา</th><th>จำนวน</th><th>รวม</th></tr>
    {% for item in items %}<tr><td>{{ item.product_name }}</td><td>฿{{ '{:,}'.format(item.price) }}</td><td>{{ item.quantity }}</td><td>฿{{ '{:,}'.format(item.subtotal) }}</td></tr>{% endfor %}
    </table></div>
    <p class="total">ยอดรวม ฿{{ '{:,.2f}'.format(order.total) }}</p>
    {% if order.payment_status in ['reported', 'paid'] %}
    <a class="btn btn-primary" target="_blank" href="{{ url_for('payment_receipt_print', order_id=order.id, download=1) }}">⬇️ ดาวน์โหลดเอกสาร PDF</a> <a class="btn btn-dark" target="_blank" href="{{ url_for('payment_receipt_print', order_id=order.id) }}">🖨️ พิมพ์ใบเสร็จ</a>
    {% if order.payment_status != 'paid' %}<p class="muted">ใบเสร็จจะระบุสถานะรอตรวจสอบจนกว่าผู้ดูแลร้านจะยืนยันว่าได้รับเงินจริงแล้ว</p>{% endif %}
    {% elif order.payment_status == 'pending' %}
    <a class="btn btn-primary" href="{{ url_for('payment', order_id=order.id) }}">ชำระเงิน / แนบสลิป</a>
    <p class="muted">แนบสลิปโอนเงินและกดแจ้งชำระเงินก่อน จึงจะดาวน์โหลดใบเสร็จชำระเงินได้</p>
    {% endif %}
    {% if order.payment_status in ['pending', 'reported'] and order.user_id == session.get('uid') %}
    <form method="post" action="{{ url_for('cancel_my_order', order_id=order.id) }}" style="display:inline" onsubmit="return confirm('{{ 'ยืนยันยกเลิกคำสั่งซื้อนี้? สินค้าจะถูกคืนเข้าสต็อก' ~ (' หากโอนเงินไปแล้ว กรุณาติดต่อร้านเพื่อขอคืนเงิน' if order.payment_status == 'reported' else '') }}');"><button class="btn btn-danger" type="submit">ยกเลิกคำสั่งซื้อ</button></form>
    {% elif order.payment_status == 'cancelled' %}
    <p class="muted">คำสั่งซื้อนี้ถูกยกเลิกแล้ว</p>
    {% endif %}
    <a class="btn btn-dark" href="{{ url_for('home') }}">กลับหน้าร้าน</a>
  </div>
</div></section>
{% endblock %}
"""

MY_ORDERS = r"""{% extends 'base.html' %}
{% block title %}คำสั่งซื้อของฉัน | PJ GUNPLA{% endblock %}
{% block full_content %}
<section class="page"><div class="wrap">
  <h2>📦 คำสั่งซื้อของฉัน</h2>
  <div class="table-wrap"><table><tr><th>เลขคำสั่งซื้อ</th><th>วันที่</th><th>ยอดรวม</th><th>สถานะ</th><th>เอกสาร</th><th>จัดการ</th></tr>
  {% for o in orders %}<tr><td>{{ o.order_code }}</td><td>{{ o.created_at }}</td><td>฿{{ '{:,.2f}'.format(o.total) }}</td><td>{% set st = order_status(o) %}<span class="st st-{{ st.key }}">{{ st.label }}</span></td><td><a href="{{ url_for('order_detail', order_id=o.id) }}">รายละเอียด</a> · <a href="{{ url_for('receipt_pdf', order_id=o.id) }}">PDF</a>{% if o.payment_status in ['reported', 'paid'] %} · <a target="_blank" href="{{ url_for('payment_receipt_print', order_id=o.id, download=1) }}">ใบเสร็จ PDF</a>{% endif %}</td><td>{% if o.payment_status in ['pending', 'reported'] %}<form method="post" action="{{ url_for('cancel_my_order', order_id=o.id) }}" style="display:inline" onsubmit="return confirm('{{ 'ยืนยันยกเลิกคำสั่งซื้อนี้? สินค้าจะถูกคืนเข้าสต็อก' ~ (' หากโอนเงินไปแล้ว กรุณาติดต่อร้านเพื่อขอคืนเงิน' if o.payment_status == 'reported' else '') }}');"><button class="link-danger" type="submit">ยกเลิกคำสั่งซื้อ</button></form>{% elif o.payment_status == 'paid' %}<span class="muted" title="ร้านยืนยันรับเงินแล้ว">ติดต่อร้านเพื่อยกเลิก</span>{% else %}<span class="muted">—</span>{% endif %}</td></tr>{% else %}<tr><td colspan="6">ยังไม่มีคำสั่งซื้อ</td></tr>{% endfor %}
  </table></div>
  <style>.link-danger{background:none;border:0;padding:0;font:inherit;color:#b91c1c;text-decoration:underline;cursor:pointer}.link-danger:hover{color:#7f1d1d}</style>
</div></section>
{% endblock %}
"""

ADMIN_DASHBOARD = r"""{% extends 'base.html' %}
{% block title %}จัดการร้าน | PJ GUNPLA{% endblock %}
{% block full_content %}
<section class="page"><div class="wrap">
  <div class="content-head"><div><h2>⚙️ ระบบแอดมิน PJ GUNPLA</h2><div class="muted">จัดการสินค้า สต็อก รูปสินค้า และคำสั่งซื้อ</div></div><a class="btn btn-primary" href="{{ url_for('admin_product_new') }}">＋ เพิ่มสินค้า</a></div>
  <div class="pills"><a class="pill active" href="{{ url_for('admin_dashboard') }}">สินค้า ({{ products|length }})</a><a class="pill" href="{{ url_for('admin_orders') }}">คำสั่งซื้อ</a><a class="pill" href="{{ url_for('admin_settings') }}">ตั้งค่าร้าน</a></div>
  <div class="table-wrap"><table><tr><th>รูป</th><th>สินค้า</th><th>เกรด</th><th>ราคา</th><th>คงเหลือ</th><th>ป้าย</th><th>จัดการ</th></tr>
  {% for p in products %}<tr><td>{% if img_of(p) %}<img src="{{ img_of(p) }}" alt="{{ p.name }}" style="width:58px;height:58px;object-fit:contain">{% else %}<span class="muted">ไม่มีรูป</span>{% endif %}</td><td><strong>{{ p.name }}</strong></td><td>{{ p.grade }}</td><td>฿{{ '{:,}'.format(p.price) }}</td><td>{{ p.stock }}</td><td>{{ p.badge or '-' }}</td><td style="white-space:nowrap"><a class="btn btn-primary" href="{{ url_for('admin_product_edit', pid=p.id) }}">แก้ไข</a> <form method="post" action="{{ url_for('admin_product_delete', pid=p.id) }}" style="display:inline" onsubmit="return confirm('ต้องการลบสินค้านี้หรือไม่?');"><button class="btn btn-danger" type="submit">ลบ</button></form></td></tr>{% endfor %}
  </table></div>
</div></section>
{% endblock %}
"""

ADMIN_PRODUCT_FORM = r"""{% extends 'base.html' %}
{% block title %}{{ 'แก้ไขสินค้า' if p else 'เพิ่มสินค้า' }} | PJ GUNPLA{% endblock %}
{% block full_content %}
<section class="page"><div class="wrap"><div class="form-card" style="max-width:760px">
  <h2>{{ '✏️ แก้ไขสินค้า' if p else '＋ เพิ่มสินค้าใหม่' }}</h2>
  <form method="post" enctype="multipart/form-data">
    <label for="name">ชื่อสินค้า</label><input id="name" name="name" maxlength="160" value="{{ p.name if p else '' }}" required>
    <label for="grade">เกรด</label><select id="grade" name="grade" required>{% for g in grades %}<option value="{{ g }}" {% if p and p.grade == g %}selected{% endif %}>{{ g }}</option>{% endfor %}</select>
    <label for="scale">Scale</label><input id="scale" name="scale" maxlength="30" value="{{ p.scale if p else '1/144' }}" required>
    <label for="price">ราคาขาย (บาท)</label><input id="price" name="price" type="number" min="0" step="1" value="{{ p.price if p else 0 }}" required>
    <label for="old_price">ราคาเดิม (ปล่อยว่างถ้าไม่มีส่วนลด)</label><input id="old_price" name="old_price" type="number" min="0" step="1" value="{{ p.old_price if p and p.old_price is not none else '' }}">
    <label for="stock">จำนวนสินค้าในสต็อก</label><input id="stock" name="stock" type="number" min="0" step="1" value="{{ p.stock if p else 0 }}" required>
    <label for="category">หมวดสินค้า</label><input id="category" name="category" maxlength="100" value="{{ p.category if p else 'GUNDAM GUNPLA' }}" required>
    <label for="badge">ป้ายสินค้า</label><select id="badge" name="badge">{% for value, label in [('','ไม่มีป้าย'),('NEW','NEW — สินค้ามาใหม่'),('SALE','SALE — ลดราคา'),('HOT','HOT — ยอดนิยม'),('SOLD OUT','SOLD OUT — สินค้าหมด')] %}<option value="{{ value }}" {% if p and p.badge == value %}selected{% elif not p and value == 'NEW' %}selected{% endif %}>{{ label }}</option>{% endfor %}</select>
    <label for="description">รายละเอียดสินค้า</label><textarea id="description" name="description" rows="4" style="width:100%;border:1px solid #cfd7e3;border-radius:6px;padding:10px" maxlength="1500">{{ p.desc if p else '' }}</textarea>
    <label for="image">รูปสินค้า (JPG, PNG, WEBP ไม่เกิน 8 MB)</label><input id="image" name="image" type="file" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" style="height:auto;padding:10px">
    {% if p and p.image_filename %}<p class="muted">รูปปัจจุบัน: {{ p.image_filename }}</p>{% endif %}
    <div style="margin-top:20px"><button class="btn btn-primary" type="submit">บันทึกสินค้า</button> <a class="btn btn-dark" href="{{ url_for('admin_dashboard') }}">ยกเลิก</a></div>
  </form>
</div></div></section>
{% endblock %}
"""

ADMIN_ORDERS = r"""{% extends 'base.html' %}
{% block title %}รายการสั่งซื้อทั้งหมด | PJ GUNPLA{% endblock %}
{% block full_content %}
<style>
  .ord-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:10px;margin:16px 0 18px}
  .ord-stat{display:block;background:#fff;border:1px solid var(--line);border-radius:9px;padding:12px 14px;color:inherit;text-decoration:none}
  .ord-stat:hover{border-color:#9db7e6}
  .ord-stat.on{border-color:var(--blue);box-shadow:0 0 0 2px rgba(37,99,235,.15)}
  .ord-stat .n{font-size:1.5rem;font-weight:800;line-height:1.2}
  .ord-tbl td,.ord-tbl th{vertical-align:top}
  .ord-id{font-weight:800;font-size:1.05rem}
  .ord-money{color:#15803d;font-weight:800;white-space:nowrap}
  .ord-addr{color:#64748b;font-size:13.5px;white-space:normal;margin-top:2px}
  .ord-sel{height:38px;border:1px solid #cbd5e1;border-radius:8px;padding:0 10px;background:#fff;min-width:168px;font:inherit}
  .ord-sel:disabled{background:#f1f5f9;color:#64748b}
  .stform{display:flex;gap:8px;align-items:center;flex-wrap:nowrap}
  .ord-more a{display:block;margin-bottom:4px;white-space:nowrap}
  .ord-more form{margin-top:6px}
  .ord-more .btn,.ord-tbl .btn{white-space:nowrap}
  .ord-tbl .btn:disabled{opacity:.45;cursor:not-allowed}
  .ord-slip{white-space:nowrap}
</style>
<section class="page"><div class="wrap">
  <div class="content-head">
    <div><h2>📦 รายการสั่งซื้อทั้งหมด และอัปเดตสถานะ</h2><div class="muted">ตรวจสลิป ยืนยันรับเงิน แล้วเปลี่ยนสถานะ: รอดำเนินการ → กำลังเตรียมพัสดุ → กำลังจัดส่ง → จัดส่งสำเร็จ</div></div>
  </div>
  <div class="pills"><a class="pill" href="{{ url_for('admin_dashboard') }}">สินค้า</a><a class="pill active" href="{{ url_for('admin_orders') }}">รายการสั่งซื้อ</a><a class="pill" href="{{ url_for('admin_settings') }}">ตั้งค่าร้าน</a></div>

  <div class="ord-stats">
    <a class="ord-stat {{ 'on' if not selected_status else '' }}" href="{{ url_for('admin_orders') }}"><div class="muted">คำสั่งซื้อทั้งหมด</div><div class="n">{{ stats.total }}</div></a>
    {% for key, label in status_labels.items() %}
    <a class="ord-stat {{ 'on' if selected_status == key else '' }}" href="{{ url_for('admin_orders', status=key) }}"><div class="muted">{{ label }}</div><div class="n">{{ stats[key] }}</div></a>
    {% endfor %}
  </div>

  <form method="get" action="{{ url_for('admin_orders') }}" style="background:#fff;border:1px solid var(--line);border-radius:9px;padding:14px;display:flex;gap:10px;flex-wrap:wrap;align-items:end;margin-bottom:16px">
    <div style="flex:1;min-width:230px"><label for="q" style="display:block;font-weight:600;margin-bottom:5px">ค้นหาคำสั่งซื้อ / ชื่อลูกค้า / เบอร์โทร / ที่อยู่ / สินค้า</label><input id="q" name="q" value="{{ q }}" placeholder="เช่น PJG-..., สมชาย, 08..., Gundam" style="width:100%;height:40px;border:1px solid #cfd7e3;border-radius:6px;padding:0 10px"></div>
    <div style="min-width:210px"><label for="status" style="display:block;font-weight:600;margin-bottom:5px">สถานะ</label><select id="status" name="status" style="width:100%;height:40px;border:1px solid #cfd7e3;border-radius:6px;padding:0 10px;background:white"><option value="">ทุกสถานะ</option>{% for key, label in status_labels.items() %}<option value="{{ key }}" {% if selected_status == key %}selected{% endif %}>{{ label }}</option>{% endfor %}</select></div>
    <button class="btn btn-primary" type="submit">ค้นหา</button><a class="btn btn-dark" href="{{ url_for('admin_orders') }}">ล้างตัวกรอง</a>
  </form>

  {% if cancelled_count %}<form method="post" action="{{ url_for('admin_delete_cancelled_orders') }}" style="margin:0 0 10px" onsubmit="return confirm('ลบคำสั่งซื้อที่ยกเลิกแล้วทั้งหมด {{ cancelled_count }} รายการ ออกจากระบบถาวร (รวมสลิปที่แนบ) ใช่หรือไม่? กู้คืนไม่ได้');"><button class="btn btn-danger" type="submit">🗑️ ลบรายการที่ยกเลิกทั้งหมด ({{ cancelled_count }})</button></form>{% endif %}
  <p class="muted">พบ {{ orders|length }} รายการ{% if q %} จากคำค้น “{{ q }}”{% endif %}{% if selected_status %} · กรองสถานะ: {{ status_labels.get(selected_status, selected_status) }}{% endif %}</p>
  <div class="table-wrap"><table class="ord-tbl" style="min-width:1080px">
    <tr><th>รหัสบิล</th><th>ชื่อลูกค้า &amp; ที่อยู่</th><th>ยอดเงิน</th><th style="white-space:nowrap">สลิปโอนเงิน</th><th>สถานะปัจจุบัน</th><th>เปลี่ยนสถานะ</th><th>เพิ่มเติม</th></tr>
    {% for o in orders %}
    {% set st = order_status(o) %}
    {% set cancelled = o.payment_status == 'cancelled' %}
    {% set cur = 'cancelled' if cancelled else (o.fulfillment_status if o.payment_status == 'paid' else 'waiting') %}
    <tr>
      <td><div class="ord-id">#{{ o.id }}</div><div class="muted" style="font-size:12.5px">{{ o.order_code or ('ORDER-' ~ o.id) }}</div><div class="muted" style="font-size:12.5px">{{ o.created_at or '-' }}</div></td>
      <td style="white-space:normal;min-width:260px;max-width:340px">
        <strong>{{ o.recipient or o.customer_name or 'ไม่ระบุชื่อ' }}</strong> <span>📞 {{ o.phone or '-' }}</span>
        <div class="muted" style="font-size:13px">บัญชี: {{ o.customer_username or ('UID ' ~ o.user_id if o.user_id else 'ไม่ระบุ') }}{% if o.customer_email %} · ✉️ {{ o.customer_email }}{% endif %}</div>
        <div class="ord-addr">{{ o.address or 'ไม่ได้ระบุที่อยู่' }}</div>
        <details style="margin-top:6px"><summary style="cursor:pointer;color:var(--blue)">ดูสินค้า {{ items_by_order.get(o.id, [])|length }} รายการ</summary><ul style="padding-left:19px;margin:8px 0">{% for item in items_by_order.get(o.id, []) %}<li style="margin-bottom:6px">{{ item.product_name }}{% if item.grade %} ({{ item.grade }}){% endif %}<br><span class="muted">{{ item.quantity }} ชิ้น × ฿{{ '{:,.2f}'.format(item.display_price) }} = ฿{{ '{:,.2f}'.format(item.display_subtotal) }}</span></li>{% else %}<li>ไม่พบรายละเอียดสินค้า</li>{% endfor %}</ul></details>
      </td>
      <td><span class="ord-money">฿{{ '{:,.2f}'.format(o.total or 0) }}</span></td>
      <td class="ord-slip">{% if o.slip_path %}<a href="{{ url_for('order_slip', order_id=o.id) }}" target="_blank">📄 ดูสลิป</a>{% else %}<span class="muted">—</span>{% endif %}</td>
      <td style="white-space:normal;min-width:150px"><span class="st st-{{ st.key }}">{{ st.label }}</span></td>
      <td style="min-width:310px">
        <form class="stform" method="post" action="{{ url_for('admin_set_order_status', order_id=o.id) }}" data-paid="{{ 1 if o.payment_status in ['reported', 'paid'] else 0 }}" onsubmit="return pjConfirmStatus(this)">
          <select class="ord-sel" name="status" aria-label="เปลี่ยนสถานะคำสั่งซื้อ {{ o.id }}" {% if cancelled %}disabled{% endif %}>
            {% for key, label in step_options %}<option value="{{ key }}" {% if cur == key %}selected{% endif %} {% if key in ['preparing', 'shipping', 'delivered'] and o.payment_status != 'paid' %}disabled title="ต้องยืนยันรับเงินก่อน"{% endif %}>{{ label }}</option>{% endfor %}
          </select>
          <button class="btn btn-primary" type="submit" {% if cancelled %}disabled{% endif %}>อัปเดต</button>
        </form>
        {% if o.payment_status == 'reported' %}<form method="post" action="{{ url_for('admin_mark_paid', order_id=o.id) }}" style="margin-top:8px" onsubmit="return confirm('ยืนยันว่าตรวจสอบและได้รับเงินจริงสำหรับคำสั่งซื้อนี้แล้ว?');"><button class="btn btn-dark" type="submit">✅ ยืนยันรับเงิน</button></form>{% endif %}
      </td>
      <td class="ord-more" style="min-width:150px">
        <a href="{{ url_for('order_detail', order_id=o.id) }}">ดูคำสั่งซื้อ</a>
        {% if o.payment_status in ['reported', 'paid'] %}<a target="_blank" href="{{ url_for('payment_receipt_print', order_id=o.id, download=1) }}">⬇️ ใบเสร็จ PDF</a>{% endif %}
        {% if o.payment_status not in ['pending', 'cancelled'] %}<form method="post" action="{{ url_for('admin_reset_status', order_id=o.id) }}" onsubmit="return confirm('ล้างสถานะคำสั่งซื้อนี้กลับเป็น รอชำระเงิน ใช่หรือไม่?');"><button class="btn btn-danger" type="submit">ล้างสถานะ</button></form>{% endif %}
        {% if cancelled %}<form method="post" action="{{ url_for('admin_delete_order', order_id=o.id) }}" onsubmit="return confirm('ลบคำสั่งซื้อ {{ o.order_code }} ออกจากระบบถาวร (รวมสลิปที่แนบ) ใช่หรือไม่? กู้คืนไม่ได้');"><button class="btn btn-danger" type="submit">🗑️ ลบรายการ</button></form>{% endif %}
      </td>
    </tr>
    {% else %}<tr><td colspan="7" style="text-align:center;padding:28px">ไม่พบคำสั่งซื้อที่ตรงกับเงื่อนไข</td></tr>{% endfor %}
  </table></div>
</div></section>
<script>
function pjConfirmStatus(f){
  if (f.status.value === 'cancelled') {
    return confirm('ยกเลิกคำสั่งซื้อนี้และคืนสต็อกสินค้า ใช่หรือไม่?' + (f.dataset.paid === '1' ? ' ลูกค้าโอนเงินแล้ว ต้องคืนเงินให้ลูกค้าเอง' : ''));
  }
  return true;
}
</script>
{% endblock %}
"""

ADMIN_SETTINGS = r"""{% extends 'base.html' %}
{% block title %}ตั้งค่าร้าน | PJ GUNPLA{% endblock %}
{% block full_content %}
<style>
  .field-error{color:#b91c1c;font-size:13.5px;margin:4px 2px 0}
  .lk{display:flex;gap:14px;padding:9px 0;border-bottom:1px solid #eef2f7}
  .lk dt{flex:0 0 170px;color:#64748b}
  .lk dd{margin:0;font-weight:600}
  .lock-badge{display:inline-block;font-size:12px;background:#fef3c7;color:#92400e;border-radius:99px;padding:2px 10px;margin-left:8px;font-weight:600}
  .set-logo{max-width:150px;max-height:150px;border:1px solid #e5e7eb;border-radius:8px;display:block;margin:6px 0}
  .set-logo.round{border-radius:50%}
  textarea.own{width:100%;min-height:110px;padding:10px 12px;border:1px solid #cbd5e1;border-radius:8px;font:inherit}
</style>
<section class="page"><div class="wrap"><div class="form-card">
  <h2>🏪 ตั้งค่าร้าน</h2>
  <p class="muted">ข้อมูลร้านที่แสดงบนใบเสร็จและหน้า "ข้อมูลเจ้าของร้าน"</p>
  <form method="post" enctype="multipart/form-data">
    <label for="shop_name">ชื่อร้าน (แสดงบนใบเสร็จ)</label><input id="shop_name" name="shop_name" value="{{ settings.shop_name }}" required maxlength="100">
    <label for="shop_address">ที่อยู่ร้าน (แสดงบนใบเสร็จ)</label><input id="shop_address" name="shop_address" value="{{ settings.shop_address }}" maxlength="300">

    <h3 style="margin:26px 0 6px">3. ข้อมูลเกี่ยวกับร้าน</h3>
    <dl style="margin:0">
      <div class="lk"><dt>ชื่อร้าน</dt><dd>{{ owner.shop_name }}<span class="lock-badge">🔒 ล็อก</span></dd></div>
      <div class="lk"><dt>ประเภทธุรกิจ</dt><dd>{{ owner.business_type }}<span class="lock-badge">🔒 ล็อก</span></dd></div>
    </dl>
    <label for="shop_logo">โลโก้ร้าน <small class="muted">(JPG, PNG, WEBP)</small></label>
    <img class="set-logo{{ ' round' if logo_default else '' }}" src="{{ logo_url }}" alt="โลโก้ร้าน">
    {% if not info.shop_logo %}<div class="muted">โลโก้ PJGUNPLA เริ่มต้นของระบบ — อัปโหลดไฟล์ใหม่เพื่อเปลี่ยนได้</div>{% endif %}
    <input id="shop_logo" name="shop_logo" type="file" accept="image/png,image/jpeg,image/webp">
    {% if info.shop_logo %}<label style="font-weight:400"><input type="checkbox" name="remove_shop_logo" value="1"> ลบโลโก้ปัจจุบัน</label>{% endif %}
    {% if errors.shop_logo %}<div class="field-error">{{ errors.shop_logo }}</div>{% endif %}
    <label for="shop_opened_date">วันที่เริ่มเปิดร้าน</label>
    <input id="shop_opened_date" name="shop_opened_date" type="date" value="{{ info.shop_opened_date }}">
    {% if errors.shop_opened_date %}<div class="field-error">{{ errors.shop_opened_date }}</div>{% endif %}
    <label for="shop_products_services">รายละเอียดสินค้าและบริการ</label>
    <textarea class="own" id="shop_products_services" name="shop_products_services" maxlength="2000">{{ info.shop_products_services }}</textarea>
    {% if errors.shop_products_services %}<div class="field-error">{{ errors.shop_products_services }}</div>{% endif %}
    <label for="shop_shipping_policy">นโยบายการจัดส่งสินค้า</label>
    <textarea class="own" id="shop_shipping_policy" name="shop_shipping_policy" maxlength="2000">{{ info.shop_shipping_policy }}</textarea>
    {% if errors.shop_shipping_policy %}<div class="field-error">{{ errors.shop_shipping_policy }}</div>{% endif %}
    <label for="shop_return_policy">นโยบายการเปลี่ยนหรือคืนสินค้า</label>
    <textarea class="own" id="shop_return_policy" name="shop_return_policy" maxlength="2000">{{ info.shop_return_policy }}</textarea>
    {% if errors.shop_return_policy %}<div class="field-error">{{ errors.shop_return_policy }}</div>{% endif %}

    <hr style="border:0;border-top:1px solid #e4e8ee;margin:24px 0">
    <h3>🔐 เปลี่ยนรหัสผ่านแอดมิน (เว้นว่างได้)</h3>
    <label for="current_password">รหัสผ่านปัจจุบัน</label><input id="current_password" name="current_password" type="password" autocomplete="current-password">
    <label for="new_password">รหัสผ่านใหม่ (อย่างน้อย 8 ตัวอักษร)</label><input id="new_password" name="new_password" type="password" autocomplete="new-password" minlength="8">
    <label for="confirm_password">ยืนยันรหัสผ่านใหม่</label><input id="confirm_password" name="confirm_password" type="password" autocomplete="new-password" minlength="8">
    <div style="margin-top:20px"><button class="btn btn-primary" type="submit">บันทึกการตั้งค่า</button> <a class="btn btn-dark" href="{{ url_for('admin_dashboard') }}">กลับหน้าจัดการ</a></div>
  </form>
</div></div></section>
{% endblock %}
"""

PRINT_RECEIPT = r"""<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ doc_title }} {{ receipt_no }}</title>
<style>
  *{box-sizing:border-box}
  body{margin:0;background:#e5e7eb;color:#1f2937;font-family:'Sarabun','Noto Sans Thai','Tahoma','Leelawadee UI',sans-serif;font-size:15px;line-height:1.55}
  .toolbar{position:sticky;top:0;z-index:5;display:flex;gap:10px;justify-content:center;flex-wrap:wrap;padding:12px;background:#111827}
  .toolbar button,.toolbar a{font:inherit;font-weight:700;padding:9px 18px;border-radius:8px;border:0;cursor:pointer;text-decoration:none;background:#2563eb;color:#fff}
  .toolbar a{background:#374151}
  .hint{width:210mm;max-width:100%;margin:10px auto 0;text-align:center;color:#6b7280;font-size:13px}
  .sheet{width:210mm;max-width:100%;min-height:200mm;margin:14px auto 30px;padding:16mm 16mm 14mm;background:#fff;box-shadow:0 2px 14px rgba(0,0,0,.15)}
  .rc-logo{display:block;margin:0 auto 6px;width:88px;height:88px;object-fit:contain}
  .rc-logo.round{border-radius:50%}
  h1.shop{margin:0;text-align:center;font-size:26px}
  .addr{text-align:center;color:#4b5563;margin-top:2px}
  h2.title{margin:14px 0 18px;text-align:center;font-size:21px;color:#1d4ed8}
  .meta{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px}
  .meta div p{margin:2px 0}
  .stamp{border:2px solid {{ '#15803d' if is_paid else '#b45309' }};color:{{ '#15803d' if is_paid else '#b45309' }};font-weight:800;font-size:19px;padding:6px 18px;border-radius:6px;transform:rotate(-4deg);white-space:nowrap}
  .box{border:1px solid #cbd5e1;border-radius:6px;margin-bottom:16px}
  .box .hd{background:#eaf1fb;padding:6px 12px;font-weight:700}
  .box .bd{padding:8px 12px}
  table{width:100%;border-collapse:collapse}
  th,td{border:1px solid #cbd5e1;padding:7px 10px;text-align:left;vertical-align:top}
  th{background:#eaf1fb}
  td.n,th.n{text-align:right;white-space:nowrap}
  td.c,th.c{text-align:center;width:44px}
  tr.sub td{border:0;padding:4px 10px;color:#334155}
  .vatnote{margin:6px 0 0;color:#6b7280;font-size:13px;text-align:right}
  tr.total td{border:0;border-top:2px solid #334155;font-weight:800;font-size:16px}
  .words{margin:12px 0 26px}
  .thanks{text-align:center;margin-top:34px}
  .foot{text-align:center;color:#6b7280;font-size:12.5px;margin-top:16px}
  .pdfmode .sheet{width:210mm;max-width:none;min-height:0;margin:0;box-shadow:none}
  @page{size:A4;margin:0}
  @media print{
    body{background:#fff}
    .toolbar,.hint{display:none}
    .sheet{margin:0;box-shadow:none;width:auto;min-height:0;padding:16mm}
  }
</style>
</head>
<body>
<div class="toolbar">
  <button type="button" id="btn-pdf" onclick="downloadPdf()">⬇️ ดาวน์โหลด PDF</button>
  <button type="button" onclick="window.print()" style="background:#0f766e">🖨️ พิมพ์ใบเสร็จ</button>
  <a href="{{ url_for('order_detail', order_id=order.id) }}">← กลับ</a>
</div>
<p class="hint">กด "ดาวน์โหลด PDF" เพื่อบันทึกเป็นไฟล์ หรือกด "พิมพ์ใบเสร็จ" เพื่อสั่งพิมพ์</p>
<div class="sheet" id="sheet">
  <img class="rc-logo{{ ' round' if logo_default else '' }}" src="{{ logo_url }}" alt="โลโก้ร้าน">
  <h1 class="shop">{{ shop_name }}</h1>
  {% if shop_address %}<div class="addr">{{ shop_address }}</div>{% endif %}
  <h2 class="title">{{ doc_title }}</h2>
  <div class="meta">
    <div>
      <p><b>เลขที่ใบเสร็จ:</b> {{ receipt_no }}</p>
      <p><b>อ้างอิงคำสั่งซื้อ:</b> {{ order.order_code }}</p>
      <p><b>วันที่สั่งซื้อ:</b> {{ order.created_at }}</p>
      <p><b>ช่องทางชำระเงิน:</b> PromptPay QR — ธนาคารกสิกรไทย</p>
    </div>
    {% if is_paid %}<div class="stamp">ชำระเงินแล้ว</div>{% endif %}
  </div>
  <div class="box">
    <div class="hd">ข้อมูลลูกค้า</div>
    <div class="bd">{{ order.recipient }} &nbsp;|&nbsp; โทร. {{ order.phone }}<br>{{ order.address }}</div>
  </div>
  <table>
    <thead><tr><th class="c">#</th><th>รายการสินค้า</th><th class="n">ราคา/ชิ้น</th><th class="n">จำนวน</th><th class="n">รวม</th></tr></thead>
    <tbody>
    {% for item in items %}
      <tr><td class="c">{{ loop.index }}</td><td>{{ item.product_name }}</td><td class="n">฿{{ '{:,.2f}'.format(item.price) }}</td><td class="n">{{ item.quantity }}</td><td class="n">฿{{ '{:,.2f}'.format(item.subtotal) }}</td></tr>
    {% endfor %}
      <tr class="sub"><td colspan="4" class="n">ราคาสินค้า (ก่อนภาษีมูลค่าเพิ่ม)</td><td class="n">฿{{ '{:,.2f}'.format(net) }}</td></tr>
      <tr class="sub"><td colspan="4" class="n">ภาษีมูลค่าเพิ่ม (VAT) 7%</td><td class="n">฿{{ '{:,.2f}'.format(vat) }}</td></tr>
      <tr class="total"><td colspan="4" class="n">ยอดรวมทั้งสิ้น</td><td class="n">฿{{ '{:,.2f}'.format(total) }}</td></tr>
    </tbody>
  </table>
  <p class="vatnote">ราคาสินค้าข้างต้นรวมภาษีมูลค่าเพิ่ม 7% แล้ว</p>
  <p class="words"><b>จำนวนเงินตัวอักษร:</b> ({{ baht_text }})</p>
  <p class="thanks">{% if is_paid %}ได้รับชำระเงินตามรายการข้างต้นเรียบร้อยแล้ว ขอบคุณที่อุดหนุน {{ shop_name }}{% else %}ลูกค้าแจ้งชำระเงินแล้ว ร้านอยู่ระหว่างตรวจสอบยอดเงิน — เอกสารนี้ยังไม่ใช่หลักฐานการรับเงินจนกว่าร้านจะยืนยัน{% endif %}</p>
  <p class="foot">พิมพ์เอกสารเมื่อ {{ printed_at }} · เอกสารนี้ออกโดยระบบอัตโนมัติ</p>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
function downloadPdf(){
  if (typeof html2pdf === 'undefined') {
    alert('โหลดตัวสร้าง PDF ไม่สำเร็จ (ต้องต่ออินเทอร์เน็ต) กรุณาเลือก "บันทึกเป็น PDF" ในหน้าต่างพิมพ์แทน');
    window.print();
    return;
  }
  var btn = document.getElementById('btn-pdf');
  btn.disabled = true; btn.textContent = 'กำลังสร้าง PDF...';
  document.body.classList.add('pdfmode');
  window.scrollTo(0, 0);
  html2pdf().set({
    margin: 0,
    filename: 'receipt-{{ order.order_code }}.pdf',
    image: {type: 'jpeg', quality: 0.98},
    html2canvas: {scale: 2, useCORS: true, scrollX: 0, scrollY: 0},
    jsPDF: {unit: 'mm', format: 'a4', orientation: 'portrait'}
  }).from(document.getElementById('sheet')).save().catch(function(){
    alert('สร้าง PDF ไม่สำเร็จ กรุณาเลือก "บันทึกเป็น PDF" ในหน้าต่างพิมพ์แทน');
  }).then(function(){
    document.body.classList.remove('pdfmode');
    btn.disabled = false; btn.textContent = '⬇️ ดาวน์โหลด PDF';
  });
}
if (location.search.indexOf('download=1') > -1) {
  window.addEventListener('load', function(){ setTimeout(downloadPdf, 500); });
}
</script>
</body>
</html>
"""

PROFILE = r"""{% extends 'base.html' %}
{% block title %}ข้อมูลส่วนตัว | PJ GUNPLA{% endblock %}
{% block full_content %}
<div class="breadcrumb"><div class="wrap">ข้อมูลส่วนตัว</div></div>
<section class="page"><div class="wrap">
  <div class="form-card">
    <h2>👤 ข้อมูลส่วนตัว</h2>
    <p class="muted">ชื่อผู้ใช้: <strong>{{ account.username }}</strong>{% if is_admin %} · บัญชีแอดมิน (ไม่ต้องมีอีเมล){% endif %}</p>
    <form method="post">
      <input type="hidden" name="action" value="info">
      <label for="email">อีเมล{% if not is_admin %} <small class="muted">(จำเป็น)</small>{% else %} <small class="muted">(ไม่บังคับ)</small>{% endif %}</label>
      <input id="email" name="email" type="email" maxlength="254" placeholder="name@example.com" value="{{ form.get('email', '') }}" {% if not is_admin %}required{% endif %}>
      {% if errors.email %}<div class="field-error">{{ errors.email }}</div>{% endif %}

      <label for="full_name">ชื่อ - นามสกุล</label>
      <input id="full_name" name="full_name" maxlength="120" placeholder="เช่น สมชาย ใจดี" value="{{ form.get('full_name', '') }}">
      {% if errors.full_name %}<div class="field-error">{{ errors.full_name }}</div>{% endif %}

      <label for="phone">เบอร์โทรศัพท์ <small class="muted">(ตัวเลขเท่านั้น 9-10 หลัก)</small></label>
      <input id="phone" name="phone" type="tel" inputmode="numeric" maxlength="10" placeholder="0812345678"
             pattern="0[0-9]{8,9}" title="ตัวเลขเท่านั้น ขึ้นต้นด้วย 0 และมี 9-10 หลัก"
             oninput="this.value=this.value.replace(/[^0-9]/g,'')" value="{{ form.get('phone', '') }}">
      {% if errors.phone %}<div class="field-error">{{ errors.phone }}</div>{% endif %}

      <h3 style="margin:22px 0 4px">ที่อยู่จัดส่งเริ่มต้น</h3>
      <p class="muted" style="margin-top:0">ใช้เติมในหน้าสั่งซื้ออัตโนมัติ เว้นว่างทั้งหมดได้ แต่ถ้ากรอกต้องกรอกให้ครบทุกช่อง</p>

      <label for="addr">บ้านเลขที่ / หมู่บ้าน / ถนน</label>
      <input id="addr" name="addr" maxlength="250" placeholder="เช่น 123/4 หมู่ 5 ถ.มิตรภาพ" value="{{ form.get('addr', '') }}">
      {% if errors.addr %}<div class="field-error">{{ errors.addr }}</div>{% endif %}

      <label for="subdistrict">ตำบล / แขวง</label>
      <input id="subdistrict" name="subdistrict" maxlength="100" placeholder="ภาษาไทยเท่านั้น เช่น ในเมือง"
             pattern="[\u0E01-\u0E3A\u0E40-\u0E4E\s.\-]{2,}" title="ตัวอักษรไทยเท่านั้น ไม่มีตัวเลข" value="{{ form.get('subdistrict', '') }}">
      {% if errors.subdistrict %}<div class="field-error">{{ errors.subdistrict }}</div>{% endif %}

      <label for="district">อำเภอ / เขต</label>
      <input id="district" name="district" maxlength="100" placeholder="ภาษาไทยเท่านั้น เช่น เมืองขอนแก่น"
             pattern="[\u0E01-\u0E3A\u0E40-\u0E4E\s.\-]{2,}" title="ตัวอักษรไทยเท่านั้น ไม่มีตัวเลข" value="{{ form.get('district', '') }}">
      {% if errors.district %}<div class="field-error">{{ errors.district }}</div>{% endif %}

      <label for="province">จังหวัด</label>
      <input id="province" name="province" maxlength="100" list="province-list" autocomplete="off"
             placeholder="พิมพ์แล้วเลือกจากรายการ" value="{{ form.get('province', '') }}">
      <datalist id="province-list">{% for pv in provinces %}<option value="{{ pv }}">{% endfor %}</datalist>
      {% if errors.province %}<div class="field-error">{{ errors.province }}</div>{% endif %}

      <label for="zipcode">รหัสไปรษณีย์</label>
      <input id="zipcode" name="zipcode" pattern="[0-9]{5}" maxlength="5" inputmode="numeric" placeholder="เช่น 40000"
             title="ตัวเลข 5 หลัก" oninput="this.value=this.value.replace(/[^0-9]/g,'')" value="{{ form.get('zipcode', '') }}">
      {% if errors.zipcode %}<div class="field-error">{{ errors.zipcode }}</div>{% endif %}

      <div style="margin-top:18px"><button class="btn btn-primary" type="submit">บันทึกข้อมูลส่วนตัว</button></div>
    </form>
  </div>

  <div class="form-card" style="margin-top:20px">
    <h2>🔒 เปลี่ยนรหัสผ่าน</h2>
    <form method="post">
      <input type="hidden" name="action" value="password">
      <label for="current_password">รหัสผ่านปัจจุบัน</label>
      <input id="current_password" name="current_password" type="password" autocomplete="current-password" required>
      <label for="new_password">รหัสผ่านใหม่ (อย่างน้อย 6 ตัวอักษร)</label>
      <input id="new_password" name="new_password" type="password" autocomplete="new-password" minlength="6" required>
      <label for="confirm_password">ยืนยันรหัสผ่านใหม่</label>
      <input id="confirm_password" name="confirm_password" type="password" autocomplete="new-password" minlength="6" required>
      <div style="margin-top:18px"><button class="btn btn-dark" type="submit">เปลี่ยนรหัสผ่าน</button>
      <a class="btn btn-dark" href="{{ url_for('my_orders') }}">📦 คำสั่งซื้อของฉัน</a></div>
    </form>
  </div>
</div></section>
<style>.field-error{color:#b91c1c;font-size:13.5px;margin:4px 2px 0}</style>
<script>
(function(){
  var input=document.getElementById('province');
  var list=[].map.call(document.querySelectorAll('#province-list option'),function(o){return o.value});
  var alias={'กทม':'กรุงเทพมหานคร','กรุงเทพ':'กรุงเทพมหานคร','กรุงเทพฯ':'กรุงเทพมหานคร','อยุธยา':'พระนครศรีอยุธยา','โคราช':'นครราชสีมา'};
  function check(){
    var v=input.value.trim().replace(/^(จังหวัด|จ\.)\s*/,'');
    v=alias[v]||v;
    input.setCustomValidity(v&&list.indexOf(v)<0?'ไม่พบจังหวัดนี้ กรุณาพิมพ์ชื่อจังหวัดให้ถูกต้อง':'');
  }
  input.addEventListener('input',check); check();
})();
</script>
{% endblock %}
"""

ADMIN_PROFILE = r"""{% extends 'base.html' %}
{% block title %}ข้อมูลส่วนตัวเจ้าของร้าน | PJ GUNPLA{% endblock %}
{% block full_content %}
<div class="breadcrumb"><div class="wrap">ข้อมูลส่วนตัว (เจ้าของร้าน)</div></div>
<style>
  .own-head{display:flex;gap:22px;align-items:center;flex-wrap:wrap}
  .own-photo{width:130px;height:130px;border-radius:50%;object-fit:cover;border:3px solid #dbe4f3;background:#eef2f7;display:flex;align-items:center;justify-content:center;font-size:52px}
  .own-head h2{margin:0}
  .own-pos{color:#1d4ed8;font-weight:700;margin:2px 0 8px}
  .own-bio{margin:0;max-width:62ch;line-height:1.65}
  .lk{display:flex;gap:14px;padding:9px 0;border-bottom:1px solid #eef2f7}
  .lk dt{flex:0 0 170px;color:#64748b}
  .lk dd{margin:0;font-weight:600}
  .lock-badge{display:inline-block;font-size:12px;background:#fef3c7;color:#92400e;border-radius:99px;padding:2px 10px;margin-left:8px;font-weight:600}
  .own-sec{margin-top:20px}
  .own-sec h3{margin:0 0 6px}
  .field-error{color:#b91c1c;font-size:13.5px;margin:4px 2px 0}
  .own-img.round{border-radius:50%}
  .own-img{max-width:150px;max-height:150px;border:1px solid #e5e7eb;border-radius:8px;display:block;margin:6px 0}
  textarea.own{width:100%;min-height:110px;padding:10px 12px;border:1px solid #cbd5e1;border-radius:8px;font:inherit}
</style>
<section class="page"><div class="wrap">
 <form method="post" enctype="multipart/form-data">
  <input type="hidden" name="action" value="owner">
  <div class="form-card">
    <div class="own-head">
      {% if vals.owner_photo %}<img class="own-photo" src="{{ url_for('static', filename='uploads/' ~ vals.owner_photo) }}" alt="รูปเจ้าของร้าน">{% else %}<div class="own-photo">👤</div>{% endif %}
      <div>
        <div class="muted">{{ owner.role_title }}</div>
        <h2>{{ owner.full_name }}{% if vals.owner_nickname %} <small class="muted">({{ vals.owner_nickname }})</small>{% endif %}</h2>
        <div class="own-pos">{{ owner.position }}</div>
        <p class="own-bio">{{ owner.bio }}</p>
      </div>
    </div>
    <p class="muted" style="margin-bottom:0">🔒 ข้อมูลที่มีเครื่องหมายล็อกถูกกำหนดไว้ในระบบ แก้ไขผ่านหน้าเว็บไม่ได้ ส่วนช่องกรอกด้านล่างแอดมินแก้ไขได้</p>
  </div>

  <div class="form-card own-sec">
    <h3>1. ข้อมูลส่วนตัวของเจ้าของร้าน</h3>
    <dl style="margin:0">
      <div class="lk"><dt>ชื่อ - นามสกุล</dt><dd>{{ owner.full_name }}<span class="lock-badge">🔒 ล็อก</span></dd></div>
      <div class="lk"><dt>ตำแหน่ง</dt><dd>{{ owner.position }}<span class="lock-badge">🔒 ล็อก</span></dd></div>
      <div class="lk"><dt>ประวัติย่อ</dt><dd style="font-weight:400">{{ owner.bio }}<span class="lock-badge">🔒 ล็อก</span></dd></div>
    </dl>
    <label for="owner_nickname">ชื่อเล่น <small class="muted">(ไม่จำเป็น)</small></label>
    <input id="owner_nickname" name="owner_nickname" maxlength="40" value="{{ vals.owner_nickname }}">
    {% if errors.owner_nickname %}<div class="field-error">{{ errors.owner_nickname }}</div>{% endif %}
    <label for="owner_photo">รูปโปรไฟล์ / รูปเจ้าของร้าน <small class="muted">(JPG, PNG, WEBP — แก้ไขได้)</small></label>
    {% if vals.owner_photo %}<img class="own-img" src="{{ url_for('static', filename='uploads/' ~ vals.owner_photo) }}" alt="รูปเจ้าของร้าน">{% endif %}
    <input id="owner_photo" name="owner_photo" type="file" accept="image/png,image/jpeg,image/webp">
    {% if vals.owner_photo %}<label style="font-weight:400"><input type="checkbox" name="remove_owner_photo" value="1"> ลบรูปปัจจุบัน</label>{% endif %}
    {% if errors.owner_photo %}<div class="field-error">{{ errors.owner_photo }}</div>{% endif %}
  </div>

  <div class="form-card own-sec">
    <h3>2. ข้อมูลติดต่อ</h3>
    <dl style="margin:0">
      <div class="lk"><dt>เบอร์โทรศัพท์ติดต่อร้าน</dt><dd>{{ owner.phone }}<span class="lock-badge">🔒 ล็อก</span></dd></div>
      <div class="lk"><dt>Facebook Page</dt><dd>{{ owner.facebook }}<span class="lock-badge">🔒 ล็อก</span></dd></div>
    </dl>
    <label for="owner_email">อีเมลของร้าน</label>
    <input id="owner_email" name="owner_email" type="email" maxlength="254" placeholder="shop@example.com" value="{{ vals.owner_email }}">
    {% if errors.owner_email %}<div class="field-error">{{ errors.owner_email }}</div>{% endif %}
    <label for="owner_line_oa">LINE Official Account</label>
    <input id="owner_line_oa" name="owner_line_oa" maxlength="100" placeholder="เช่น @pjgunpla" value="{{ vals.owner_line_oa }}">
    {% if errors.owner_line_oa %}<div class="field-error">{{ errors.owner_line_oa }}</div>{% endif %}
    <label for="shop_address">ที่อยู่ร้าน <small class="muted">(กรณีมีหน้าร้านจริง — ใช้แสดงบนใบเสร็จด้วย)</small></label>
    <input id="shop_address" name="shop_address" maxlength="300" value="{{ vals.shop_address }}">
    {% if errors.shop_address %}<div class="field-error">{{ errors.shop_address }}</div>{% endif %}
  </div>

  <div class="form-card own-sec">
    <h3>3. ข้อมูลเกี่ยวกับร้าน</h3>
    <p class="muted" style="margin-top:0">โลโก้ร้าน วันที่เริ่มเปิดร้าน รายละเอียดสินค้าและบริการ นโยบายการจัดส่ง และนโยบายการเปลี่ยน/คืนสินค้า ย้ายไปจัดการที่หน้า <strong>ตั้งค่าร้าน</strong> แล้ว</p>
    <a class="btn btn-primary" href="{{ url_for('admin_settings') }}">🏪 ไปที่ตั้งค่าร้าน</a>
    <div style="margin-top:18px"><button class="btn btn-primary" type="submit">บันทึกข้อมูลที่แก้ไขได้</button></div>
  </div>
 </form>

</div></section>
{% endblock %}
"""

OWNER_PAGE = r"""{% extends 'base.html' %}
{% block title %}ข้อมูลเจ้าของร้าน | PJ GUNPLA{% endblock %}
{% block full_content %}
<div class="breadcrumb"><div class="wrap"><a href="{{ url_for('home') }}">หน้าแรก</a> › ข้อมูลเจ้าของร้าน</div></div>
<style>
  .own-head{display:flex;gap:22px;align-items:center;flex-wrap:wrap}
  .own-photo{width:130px;height:130px;border-radius:50%;object-fit:cover;border:3px solid #dbe4f3;background:#eef2f7;display:flex;align-items:center;justify-content:center;font-size:52px}
  .own-head h2{margin:0}
  .own-pos{color:#1d4ed8;font-weight:700;margin:2px 0 8px}
  .own-bio{margin:0;max-width:62ch;line-height:1.65}
  .lk{display:flex;gap:14px;padding:9px 0;border-bottom:1px solid #eef2f7}
  .lk:last-child{border-bottom:0}
  .lk dt{flex:0 0 170px;color:#64748b}
  .lk dd{margin:0;font-weight:600;min-width:0;overflow-wrap:anywhere}
  .lk dd.plain{font-weight:400;white-space:pre-line}
  .own-sec{margin-top:20px}
  .own-sec h3{margin:0 0 6px}
  .own-logo{width:110px;height:110px;object-fit:contain;margin:8px 0 4px;display:block}
  .own-logo.round{border-radius:50%}
  @media (max-width:560px){.lk{flex-direction:column;gap:2px}.lk dt{flex:none}}
</style>
<section class="page"><div class="wrap">
  <div class="form-card">
    <div class="own-head">
      {% if vals.owner_photo %}<img class="own-photo" src="{{ url_for('static', filename='uploads/' ~ vals.owner_photo) }}" alt="รูปเจ้าของร้าน">{% else %}<div class="own-photo">👤</div>{% endif %}
      <div>
        <div class="muted">{{ owner.role_title }}</div>
        <h2>{{ owner.full_name }}{% if vals.owner_nickname %} <small class="muted">({{ vals.owner_nickname }})</small>{% endif %}</h2>
        <div class="own-pos">{{ owner.position }}</div>
        <p class="own-bio">{{ owner.bio }}</p>
      </div>
    </div>
    {% if user_role == 'admin' %}<p style="margin-bottom:0"><a class="btn btn-dark" href="{{ url_for('profile') }}">✏️ แก้ไขข้อมูล</a></p>{% endif %}
  </div>

  <div class="form-card own-sec">
    <h3>1. ข้อมูลส่วนตัวของเจ้าของร้าน</h3>
    <dl style="margin:0">
      <div class="lk"><dt>ชื่อ - นามสกุล</dt><dd>{{ owner.full_name }}</dd></div>
      {% if vals.owner_nickname %}<div class="lk"><dt>ชื่อเล่น</dt><dd>{{ vals.owner_nickname }}</dd></div>{% endif %}
      <div class="lk"><dt>ตำแหน่ง</dt><dd>{{ owner.position }}</dd></div>
      <div class="lk"><dt>ประวัติย่อ</dt><dd class="plain">{{ owner.bio }}</dd></div>
    </dl>
  </div>

  <div class="form-card own-sec">
    <h3>2. ข้อมูลติดต่อ</h3>
    <dl style="margin:0">
      <div class="lk"><dt>เบอร์โทรศัพท์</dt><dd><a href="tel:{{ owner.phone }}">{{ owner.phone }}</a></dd></div>
      <div class="lk"><dt>Facebook Page</dt><dd>{{ owner.facebook }}</dd></div>
      {% if vals.owner_email %}<div class="lk"><dt>อีเมล</dt><dd><a href="mailto:{{ vals.owner_email }}">{{ vals.owner_email }}</a></dd></div>{% endif %}
      {% if vals.owner_line_oa %}<div class="lk"><dt>LINE Official Account</dt><dd>{{ vals.owner_line_oa }}</dd></div>{% endif %}
      {% if vals.shop_address %}<div class="lk"><dt>ที่อยู่ร้าน</dt><dd class="plain">{{ vals.shop_address }}</dd></div>{% endif %}
    </dl>
  </div>

  <div class="form-card own-sec">
    <h3>3. ข้อมูลเกี่ยวกับร้าน</h3>
    <img class="own-logo{{ ' round' if logo_default else '' }}" src="{{ logo_url }}" alt="โลโก้ร้าน">
    <dl style="margin:0">
      <div class="lk"><dt>ชื่อร้าน</dt><dd>{{ owner.shop_name }}</dd></div>
      <div class="lk"><dt>ประเภทธุรกิจ</dt><dd>{{ owner.business_type }}</dd></div>
      {% if opened_th %}<div class="lk"><dt>วันที่เริ่มเปิดร้าน</dt><dd>{{ opened_th }}</dd></div>{% endif %}
      {% if vals.shop_products_services %}<div class="lk"><dt>สินค้าและบริการ</dt><dd class="plain">{{ vals.shop_products_services }}</dd></div>{% endif %}
      {% if vals.shop_shipping_policy %}<div class="lk"><dt>นโยบายการจัดส่งสินค้า</dt><dd class="plain">{{ vals.shop_shipping_policy }}</dd></div>{% endif %}
      {% if vals.shop_return_policy %}<div class="lk"><dt>นโยบายการเปลี่ยน/คืนสินค้า</dt><dd class="plain">{{ vals.shop_return_policy }}</dd></div>{% endif %}
    </dl>
  </div>
</div></section>
{% endblock %}
"""

app.jinja_loader = DictLoader({
    "base.html": BASE,
    "home.html": HOME,
    "product.html": PRODUCT,
    "cart.html": CART,
    "checkout.html": CHECKOUT,
    "login.html": LOGIN,
    "register.html": REGISTER,
    "payment.html": PAYMENT,
    "order_detail.html": ORDER_DETAIL,
    "my_orders.html": MY_ORDERS,
    "admin_dashboard.html": ADMIN_DASHBOARD,
    "admin_product_form.html": ADMIN_PRODUCT_FORM,
    "admin_orders.html": ADMIN_ORDERS,
    "admin_settings.html": ADMIN_SETTINGS,
    "profile.html": PROFILE,
    "admin_profile.html": ADMIN_PROFILE,
    "owner.html": OWNER_PAGE,
    "print_receipt.html": PRINT_RECEIPT,
})


# ------------------------------------------------------------------
# Database and helpers
# ------------------------------------------------------------------
IMG_EXTS = ("jpg", "jpeg", "png", "webp")
_EXT_RE = re.compile(r"(\. (?:jpg|jpeg|png|webp))+$", re.IGNORECASE | re.VERBOSE)
IMG_DIRS = [IMG_DIR, os.path.join(BASE_DIR, "images"), BASE_DIR]
GRADE_NAMES = {
    "SD": "SUPER DEFORMED", "EG": "ENTRY GRADE", "HG": "HIGH GRADE",
    "RG": "REAL GRADE", "MG": "MASTER GRADE", "PG": "PERFECT GRADE",
}
PAYMENT_LABELS = {
    "pending": "รอชำระเงิน", "reported": "แจ้งชำระแล้ว — รอตรวจสอบ",
    "paid": "ตรวจสอบและยืนยันรับเงินแล้ว", "cancelled": "ยกเลิก",
}


# สถานะที่แสดงให้ลูกค้า/แอดมินเห็น = สถานะชำระเงิน + สถานะการจัดส่ง (fulfillment_status)
ORDER_STATUS_LABELS = {
    "pending": "รอชำระเงิน",
    "reported": "แจ้งชำระแล้ว — รอตรวจสอบ",
    "paid": "ชำระแล้ว — รอดำเนินการ",
    "preparing": "กำลังเตรียมพัสดุ",
    "shipping": "กำลังจัดส่ง",
    "delivered": "จัดส่งสำเร็จ",
    "cancelled": "ยกเลิกแล้ว",
}
# ตัวเลือกใน dropdown "เปลี่ยนสถานะ" ของแอดมิน
ORDER_STEP_OPTIONS = [("waiting", "รอดำเนินการ"), ("preparing", "กำลังเตรียมพัสดุ"),
                      ("shipping", "กำลังจัดส่ง"), ("delivered", "จัดส่งสำเร็จ"), ("cancelled", "ยกเลิกแล้ว")]
ORDER_STATUS_SQL = {
    "pending": "o.payment_status='pending'",
    "reported": "o.payment_status='reported'",
    "paid": "o.payment_status='paid' AND COALESCE(o.fulfillment_status,'waiting') NOT IN ('preparing','shipping','delivered')",
    "preparing": "o.payment_status='paid' AND o.fulfillment_status='preparing'",
    "shipping": "o.payment_status='paid' AND o.fulfillment_status='shipping'",
    "delivered": "o.payment_status='paid' AND o.fulfillment_status='delivered'",
    "cancelled": "o.payment_status='cancelled'",
}


def order_status_key(payment_status, fulfillment_status="waiting"):
    if payment_status == "paid" and fulfillment_status in ("preparing", "shipping", "delivered"):
        return fulfillment_status
    return payment_status if payment_status in ("pending", "reported", "paid", "cancelled") else "pending"


def order_status_info(order):
    """คืน {'key', 'label'} สำหรับแสดงเป็นป้ายสถานะ (รับ dict หรือ sqlite3.Row)"""
    def pick(name, default):
        try:
            return order[name] or default
        except (KeyError, IndexError):
            return default
    key = order_status_key(pick("payment_status", "pending"), pick("fulfillment_status", "waiting"))
    return {"key": key, "label": ORDER_STATUS_LABELS[key]}


app.add_template_global(order_status_info, "order_status")


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=15)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_error):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    os.makedirs(IMG_DIR, exist_ok=True)
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    with sqlite3.connect(DB_PATH) as db:
        db.execute("PRAGMA foreign_keys = ON")
        db.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'customer'
        )""")
        columns = {r[1] for r in db.execute("PRAGMA table_info(users)").fetchall()}
        if "role" not in columns:
            db.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'customer'")
        if "email" not in columns:
            db.execute("ALTER TABLE users ADD COLUMN email TEXT NOT NULL DEFAULT ''")
        for col in ("full_name", "phone", "addr", "subdistrict", "district", "province", "zipcode"):
            if col not in columns:
                db.execute(f"ALTER TABLE users ADD COLUMN {col} TEXT NOT NULL DEFAULT ''")
        # อีเมลห้ามซ้ำ (บัญชีที่ยังไม่มีอีเมล เช่น แอดมิน จะเป็นค่าว่างและไม่ถูกนับ)
        db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email) WHERE email <> ''")
        db.execute("""CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            grade TEXT NOT NULL,
            scale TEXT NOT NULL DEFAULT '1/144',
            price INTEGER NOT NULL DEFAULT 0,
            old_price INTEGER,
            stock INTEGER NOT NULL DEFAULT 0,
            category TEXT NOT NULL DEFAULT 'GUNDAM GUNPLA',
            badge TEXT NOT NULL DEFAULT '',
            description TEXT NOT NULL DEFAULT '',
            image_filename TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        db.execute("""CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_code TEXT UNIQUE,
            user_id INTEGER NOT NULL,
            recipient TEXT NOT NULL,
            phone TEXT NOT NULL,
            address TEXT NOT NULL,
            total REAL NOT NULL,
            payment_status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )""")
        db.execute("""CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            product_id INTEGER,
            product_name TEXT NOT NULL,
            price INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            subtotal INTEGER NOT NULL,
            FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE
        )""")
        db.execute("""CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT ''
        )""")

        # --- Schema migration: keep databases from earlier PJ GUNPLA versions usable. ---
        # CREATE TABLE IF NOT EXISTS does not add new columns to an existing SQLite table.
        # Add the newer columns in-place rather than asking the user to delete shop.db.
        def ensure_columns(table, definitions):
            existing = {row[1] for row in db.execute(f'PRAGMA table_info("{table}")').fetchall()}
            for column, declaration in definitions.items():
                if column not in existing:
                    db.execute(f'ALTER TABLE "{table}" ADD COLUMN "{column}" {declaration}')
                    existing.add(column)
            return existing

        ensure_columns("products", {
            "scale": "TEXT NOT NULL DEFAULT '1/144'",
            "old_price": "INTEGER",
            "stock": "INTEGER NOT NULL DEFAULT 0",
            "category": "TEXT NOT NULL DEFAULT 'GUNDAM GUNPLA'",
            "badge": "TEXT NOT NULL DEFAULT ''",
            "description": "TEXT NOT NULL DEFAULT ''",
            "image_filename": "TEXT NOT NULL DEFAULT ''",
            "created_at": "TEXT NOT NULL DEFAULT ''",
        })
        order_cols = ensure_columns("orders", {
            "order_code": "TEXT",
            "user_id": "INTEGER",
            "recipient": "TEXT NOT NULL DEFAULT ''",
            "customer_name": "TEXT NOT NULL DEFAULT ''",
            "phone": "TEXT NOT NULL DEFAULT ''",
            "address": "TEXT NOT NULL DEFAULT ''",
            "total": "REAL NOT NULL DEFAULT 0",
            "payment_status": "TEXT NOT NULL DEFAULT 'pending'",
            "payment_ref": "TEXT NOT NULL DEFAULT ''",
            "created_at": "TEXT NOT NULL DEFAULT ''",
            "slip_path": "TEXT NOT NULL DEFAULT ''",
            "fulfillment_status": "TEXT NOT NULL DEFAULT 'waiting'",
        })
        item_cols = ensure_columns("order_items", {
            "order_id": "INTEGER",
            "product_id": "INTEGER",
            "product_name": "TEXT NOT NULL DEFAULT ''",
            "grade": "TEXT NOT NULL DEFAULT ''",
            "price": "INTEGER NOT NULL DEFAULT 0",
            "unit_price": "INTEGER NOT NULL DEFAULT 0",
            "quantity": "INTEGER NOT NULL DEFAULT 1",
            "subtotal": "INTEGER NOT NULL DEFAULT 0",
        })

        # Copy old column values into the newer names (and vice versa) for history pages/PDFs.
        if "recipient" in order_cols and "customer_name" in order_cols:
            db.execute("UPDATE orders SET recipient=customer_name WHERE (recipient IS NULL OR recipient='') AND customer_name<>''")
            db.execute("UPDATE orders SET customer_name=recipient WHERE (customer_name IS NULL OR customer_name='') AND recipient IS NOT NULL")
        if "order_code" in order_cols and "payment_ref" in order_cols:
            db.execute("UPDATE orders SET order_code=payment_ref WHERE (order_code IS NULL OR order_code='') AND payment_ref<>''")
            db.execute("UPDATE orders SET payment_ref=order_code WHERE (payment_ref IS NULL OR payment_ref='') AND order_code IS NOT NULL")
        current_orders = db.execute("SELECT id FROM orders WHERE order_code IS NULL OR order_code='' ").fetchall()
        for row in current_orders:
            legacy_code = f"PJG-LEGACY-{int(row[0]):06d}"
            db.execute("UPDATE orders SET order_code=? WHERE id=?", (legacy_code, row[0]))
            if "payment_ref" in order_cols:
                db.execute("UPDATE orders SET payment_ref=? WHERE id=? AND (payment_ref IS NULL OR payment_ref='')", (legacy_code, row[0]))
        if "price" in item_cols and "unit_price" in item_cols:
            db.execute("UPDATE order_items SET price=unit_price WHERE (price IS NULL OR price=0) AND unit_price<>0")
            db.execute("UPDATE order_items SET unit_price=price WHERE (unit_price IS NULL OR unit_price=0) AND price<>0")
        db.execute("UPDATE orders SET recipient=customer_name WHERE (recipient IS NULL OR recipient='') AND customer_name IS NOT NULL")
        db.execute("UPDATE orders SET customer_name=recipient WHERE (customer_name IS NULL OR customer_name='') AND recipient IS NOT NULL")

        count = db.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        if count == 0:
            for p in PRODUCTS:
                db.execute("""INSERT INTO products
                    (id,name,grade,scale,price,old_price,stock,category,badge,description)
                    VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (p["id"], p["name"], p["grade"], p["scale"], p["price"],
                     p["old_price"], p["stock"], p["category"], p["badge"], p["desc"]))
        # สร้างบัญชีแอดมินเฉพาะเมื่อเจ้าของร้านกำหนดรหัสผ่านใน .env แล้วเท่านั้น
        if DEFAULT_ADMIN_PASSWORD:
            admin = db.execute("SELECT id FROM users WHERE username=?", (DEFAULT_ADMIN_USERNAME,)).fetchone()
            if admin is None:
                db.execute("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
                           (DEFAULT_ADMIN_USERNAME, generate_password_hash(DEFAULT_ADMIN_PASSWORD), "admin"))
            else:
                db.execute("UPDATE users SET role='admin' WHERE username=?", (DEFAULT_ADMIN_USERNAME,))
        defaults = {
            "shop_name": "PJ GUNPLA",
            "shop_address": "",
            "promptpay_id": os.environ.get("PJ_GUNPLA_PROMPTPAY_ID", "").strip(),
        }
        for key, value in defaults.items():
            db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (key, value))
        # Allow a PromptPay ID supplied through the environment to update settings.
        env_pp = os.environ.get("PJ_GUNPLA_PROMPTPAY_ID", "").strip()
        if env_pp:
            db.execute("UPDATE settings SET value=? WHERE key='promptpay_id'", (env_pp,))
        db.commit()


def row_dict(row):
    if row is None:
        return None
    item = dict(row)
    if "description" in item:
        item["desc"] = item["description"]  # Backwards compatibility for existing templates
    return item


def get_product(pid):
    return row_dict(get_db().execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone())


def get_setting(key, default=""):
    row = get_db().execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def all_settings():
    return {r["key"]: r["value"] for r in get_db().execute("SELECT key,value FROM settings")}


def find_image_file(p):
    """รองรับรูปเดิมที่วางไว้ใน static/images/<id>.jpg หรือชื่อสินค้า"""
    want_id = str(p["id"])
    want_name = re.sub(r"[^a-z0-9]+", "", str(p["name"]).lower())
    for folder in IMG_DIRS:
        try:
            names = sorted(os.listdir(folder))
        except OSError:
            continue
        for name in names:
            if not re.search(r"\.(jpg|jpeg|png|webp)(\.(jpg|jpeg|png|webp))?$", name, re.I):
                continue
            path = os.path.join(folder, name)
            if not os.path.isfile(path):
                continue
            stem = re.sub(r"(\.(jpg|jpeg|png|webp))+$", "", name, flags=re.I)
            norm_stem = re.sub(r"[^a-z0-9]+", "", stem.lower())
            if stem == want_id or norm_stem == want_name:
                return folder, name
    return None


def img_of(p):
    if not p:
        return None
    filename = p.get("image_filename")
    if filename and os.path.isfile(os.path.join(UPLOAD_DIR, filename)):
        return url_for("static", filename="uploads/" + filename)
    if find_image_file(p):
        return url_for("pic", pid=p["id"])
    return None


# โลโก้ร้าน PJGUNPLA (ฝังในไฟล์ ไม่ต้องวางไฟล์รูปเพิ่ม) — แอดมินอัปโหลดโลโก้ใหม่ทับได้ที่หน้า "ข้อมูลส่วนตัว"
BRAND_LOGO_B64 = """
GRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgY
GBgYGBgYGBj/wgARCAIAAgADASIAAhEBAxEB/8QAHAAAAQQDAQAAAAAAAAAAAAAAAAEFBgcDBAgC/8QAGwEBAAIDAQEAAAAAAAAA
AAAAAAMFAQIEBgf/2gAMAwEAAhADEAAAAaGA21AAAAAABFEBQBFAABFAABFBBUBQBFAEUAAABFAAEFAAAAAAAEFBFAAAEUAAAAAB
AVFAAAAABFAABFA3dLenHPJXCzuDb6+QJdQRQADJjtrOEl+35yjkZn0s025W1bzpffTUPXnXIqDKgAAIqAoigAAACKCKAAIoAAAA
ACAoACKiiKigAAAAAAAITy2eanWs6rJrK7Zpxzcnul2Qz0lPG3LK9+gqI/ZURfqi1m/Ml+UPx9Oq5YU216RqPoDjTt5LT1a73biq
lDXicco82z58obapdy7Y9R2kXYdPB1xALLqAAAIoAAAAAAAAACKAAiooiiCgAAAAAAAHt8l1xVReTacWta+QuEFvHzV7JHqppF4+
9fovL3PClJRNalvuDCjDIY/aYdffdI+y6qQfMvd88oXL0HJazppafySG1vTNK1rhgsOd7ltbr62isGNJJ7mqrtLGiFRZtCoVVkoA
AAAAAAgoigigioAACooAAAAAAADxLFoTVxj/AKfz71D2rxVWIFk1Nnbkqe+YIpNOBzWeYRi1PdZ1/RaEHcYJUWTTIYnv3l69Ozd6
itJzJoPJaHyO2zV5JrDhgUGncE9BXAEmuTwk50zBiRsvbzOssrXL38Uvh8xdrDirIc2zzN+ohHIoIKIoAgoIKCCggACgAAAAACBL
urnwSrHAfR0O2zh5n0AE5ilYelqp6NxlKOvLX1zrO3iO4SVorWJ74SD7Mczu7rq7XF6R92Ua4LyVPsssPr8ByZsdNcvYzdPLnXHJ
PTF52NqW21bqZ9lfSUb7GM848N6eqY49MndESCPnPLaEM1Z96bz9WEmjPmfQKipzzigAAAAAIAAAoAAAAASKeHakGWuPS0BrDx5y
+0cTsybanT1C2Bzz7FuPNc65syvIDWGT9Fdz3pJp+tjPrvpazlgY0Xxrx4ndGbZ9tXjofmHDJzdwxWuLqMnH/YfJvRBsKi+78ip5
jfNM4u1cni/UX9Q9zO3mbfn0zYfQ1pv6dib67sO8zX1PnanV5ZfL+gUQilUAAAABFQAUEAAUAyZxv2FhifrPNt2h5m1Jbanvdg1n
weQl3m70sqfw7K5+Y+meWyL7WpqRT5seJMNnErnjOjjseGaTavvW8yRe/UriukntdPc2jbuiqT2JYer+ebNa8601ttMe9FSbOgFD
bhJ5ZjNa9A6meu6sdB9La1P2MVlM0h9RWR2BxaJ5jmkAt1gv6atkVPOXoqKAAAAioKAIAKIoTWO2J6CkZoFsbHF1ukgyQa7qtfXF
8p6I6w5P7L03i8XhU7zi7OXunqsZoPSx5tJMUrcHjm7dWJPO9tHHtma1PrJIHnG2sTeB7exjLA2yGLzQufvRcJIb80ZxWG8NJ6C5
jLZexZPRFryHHuxSR+F2fQGcPdjURMqTunbpqMfB00eOsk9DPhw4IdbeYeopbFY9PJrAUluAAACKgAAACo8yxy5jlNX+ioywGXXi
k12cKS2BZXNGzdec1X/NHSkrSsa3t7CQNN+YNF22YOyYWGwtPJ1SkYlzo0YtOy29Iz5qsrOvLEqvPFJFRleX7SsmGyw4Pd3VwXFS
djQ1ik5dPMsum+44pfrtFs6t7JWds+dc4obcKZ1p1/8AEW81awOTRCQ2HqvNa25Ndaqr3SfVjZeRgepu6Uu6iLrsAACAACooliQi
zvQ0kQjRlrO97jQRyGbNMOrnwOCHrPOkogMT87dda1izM9RadaGs0c01QObiz8/ba2Tx74+rymZGIq45tPWZGiRO0kMOzSbUaw+l
+jue54r6nSaXXwVTD4nfMmjA9w+Zb43+fegOV9cz24K+tLOGqL29QmM3NKOH7VzH0XUe5Y8U3Imw8sHL6mVvcCiXPBmk0P2r/wAl
LIPbNWWXBhVFobkAEFBABRAl++4RD1PnWIDzHoR125Je1HjIHpKMY8UbobcA85eFuVHdecWcM1hR789ReVwvbHUqtu/VW5GpO36S
wx7bxYTr3DJlmtXx68taulcKklhX2hWllUzNBWfS+KpM4bbDi0o6YtLnHoHn+De57GYHvbLhHN5NM832JKYvifFX1pRPaFwjjm0a
y2FS1q1TiNQybxzxkxSX03n64VDy3olAAEAFE2tWQ9EE8qexK4uav3Kdre6oRTzc1fqM4GfzV4AUVwABMGNtli6biVczDG0jqPRb
Nc2rfFaw6rub9XB6g3aHCLTXO/tU8tPUD9Rno5mewWq4u+uhtJ2JTe2Np6rCy54pZjgbZJpZOpXL9HvdG+0ucUvuAWLCmGmwanvD
OHOJyyEwyxjSsGGlBEmjW2uaXo5+t83Xdq1hOuSeAYH9gordQIJxFQFQCbQqxLes0Ik+aGcTBUweqoMkQw6flr8AqLMDY21xSPdi
1tXYsQVFkevJjMrjT7q7a9GxOapSeioaUb1e9OsstChdHXtveBbNhx8DfSvUfHnTx21MYHt2VY9UFuY49td11tuTTy2S3CRmXR5M
Z6Fe6ks3Y/wmTQrTatOkuWbn21sCN0+88ttYlYtdj9FVWDdryu4q/ao3+loo87xN48l6J7hNkVvLGoFLbCACooWhV9uegpK62G7J
x9cliGLzpuAcHYA8SxastzRP0VLh0A83eAGm4AGxr7J1rp7+jS+g0WKW6uk0InGSQ7RN2/79bRYOT+seSO+ucsOPJZ1iacivTXbl
/wBdfVfFJSLxoa0ulwx9nnvRDTyTSO8fRK3Wn9jGce81ZdJn+Qs+vw+s8W9C3S08XF90Pd+QSCOrB5m+NldWpsbWqi16v9BSa6ov
mfQCKCKgerhp+4PSUNS4MmPz92Aa7B6lfXzakiWMelosTMHlfQgEMoHs8K9mTf0E5uVdZZU87PFYe8Su+0bU5r620QPGdfHP1/pJ
pyh7tmorin3LCq+yOiB2sirJvHJl5g7D5Fgk2Lapaye3lc2x9hVf2ybUxyTzlxWDH0dF/SUtL7Gvi3xIJJGnfs5dtt2YZd1Or68S
uhuHGE2DBLessOAziG7xtAi+Y9CIAKii2/T1u+koapxbOtQXRnzy+x4sG8kf9FSJHTJ5H0mMdd6GeObcj1THsMe4YMfj3pnJYFdZ
Y5L+mvJ25zdfVXuhpVDNbJDcuEq142w4zYzZTcAlimMR007uF09sj1LG52FU2xvr1BzTj0I9mvwvjeN1wq+9MLBOItp1/Zecspiz
a3r2q/tZ0s+PkPz2dz7vq31hbsK6YG6WtW76Si0ohmw+eu7FicqilxUsqh5j0IAIqKFp1ZY9/Swn3n983RJPaMHpaMjaSjyHptP1
sNnNPua2LHrnMqeWfXhMrGP349HjzmxiZPCno848M/nEuWVMYZUA85PAY9nDkD1i9mbfafOTlnaHbbGhmVZI3XJpbNtXecW2abW9
K+cLfrO+fY9pz5pubi+KP6YZwxwCxWazhPYXMcO79D5tAvS+e0FRfMeiABFRQnEHk9pWq1SWEzxyCOqV3c4vvnVjn0PGRItsOTyM
ePXrGJk8Bk8ZPJ7x5fOMrj9ezyvn0YfOwZxj9r5ZMfjOwvj2jPoRTwvrwJ4TIxk8eMorwz7Wz08arB1c8r9x9x7eTe1dpdtbekvM
mhU2PabFy7Zmm1avT1XXRD0lzxcVGx7z6sLGrS9pVEXzd+IoAAOTaskdk1tZ1eeio9QNjzd/Km3YbdmH3586be/KqeMeXCx68+fR
mRAyopjPj3j9MKAyCAYF8Zx7zJ6EBcZQEFxZcWcefXlD3k8eT1m8KOev6WTGl4y+Noxw0vEsb+8QF2Z6mgsrmHH0cuRPtPnqTSvc
Gk/2fBsQaTRnBQKmyEUAAAQnDdpyj1fnK+dmlw8v6Lb13RmZyp496ZMWVDD6yYc4w5PWsZ82puHs8rjPhF8MZgGUw+sWcJ78bB6A
xn0IBjyYjJgyYM4PWK0Ypq68W7paSVb7lUV6OU28Ox0QecDjsSaRvJIdnr5Yv4lm3PDYbTXXrk67reufPUkcekPtOzljOnM1554l
gnkC4+lUUr+0EUABbKrSVXlQybDu38nUmv4wcHbnTztSR4Df2OnnZvEm2OiCJ6s287aw1yfdbONPZwvs8UOw7OWjt8Ph1ydMEfJL
sTwxPYlBvpGCShHthzwZxhXHrjl7YsDM7cK4eY5HHyxTCSNsxTV01zVuC7HWGXnfXvihIJceHtre55+FXbS1JY3jXbyTTYkLV2rz
T8vOXTiab8FyfA43FZGtAKvvANNxUUMmMzh83XNl9HROeWHOvJ0vSq+kb1LMfIpKN1OmHzl6OQde7qRgnJhD7h1zldL8gWu3J0uh
91WHFX2tdzvJHzjrdXu/PPxjsWbfkE3JbF3Pw9Hu3WHXfX5A65645pxmyXuZmM8WR3pnmnfXq6w9Ta025h6b5j6gzhUiHIx3DscN
dxi85X9SRfsNmVK4c5gSagSAuq7MEbj2dHegr9OW47atV3NXDBUqLIVFZRQAAyTqAudnX4uoaBsaCboAGrh7HVOS2XOOzlr+wMZj
fFvRXOu2p1DzD3AOfPvQXLGM3LYJF8ZcWXk2c5xcbRCNwi3WXN/SJEeN+iudc42+5eUerMZ16HnHgtM0IzjMx5l6L0c4kEWcqoNS
+qvmA319avgidixuKmyc2dbZPnM/QnIrDGetjONXpWmupmdypbMXGaptzChE+euq+RO3kxN8hj2uVEOTpURQEUJNGZ7aV0b6y5f7
Fr+3PT1r4oZeMJB1b42xsbjRAMZqCvs2HbWa9e8/XHjbPQ8q2y0qas/m8lF88Z3Oxb8KlNNsyWw23fOdK2v3xnGG321yxmkrmo++
T1yd0lyPnHZmxUFv4yUB0FzwdA5vDMczMHgzqAZSzqjny49cyHBGtVmcQLBWJb0wqvQNeEw5M6y7qjimx8Z6P5QfobnD3D5nDLat
FRaizRQAENuV6zPdVVxW81OlLbeIywc65x0k00GFsLr9CYV23Wp5Z0933UhFr94zu3OLj14024zP/VWNhbfMmtGc46/dOQ3Y6p9c
gtx2LSFQBZtq8w5ttLVqBwyzxJaVaZpY5pBtzNNFvM28baw4mCEQJiucQ/3K8WEeyO+JnRy7sp7uSHZBt4+l3yR/FpvKfUR8sTFI
cE8ggc84Bw9iKAIu/vpL8GtalnwWknqO1NnSFeZcWdQXPvrPXetNmaGWtTfs9MLazTAkjh5MFIfmlOFhl2NnBllzNuuzIckTx4TE
hysTBYaZS/BFzTaQ4WQhldMOiRS7GHyQygGuwAAAABtZppa1vmNeGOaIUKK4AAAAAAAAEVFCXxCc29ZFr7ol5ik2YvItCWPJuxfU
JhhiqabSSTVtkljnUJl2/aV9djk2+Y9AARyAAAAAAAAAAAAAAAAAAAAAbG2uu/O+S/ptuGauvx9KClRZgAAMADIAAAAAIpvyiEJY
cL4z4zm6FAgmAAAAAHplJorKaIhJ/Q0cd17LY+eeIG3qUluAa7AAAAKgAAACoAAAABlzjF7kEiuKyPSJoi3XyvkcChuADnnAAAAA
AAAAAAAAAAAAAAAAAAAAADNI4sdfNZOlBHe6qs7PLHjOK1J+2cnTEx+1OHsbFz4eadANdhFy51wm9t9ELMSdx7eWEuswbe3lxu0T
Z8JTHNUqLIA4usAAAAAAAAAAAAAABFRQAAAAAAAAAAAAAAAABUDfcY+dfNLt2CHbyWHlrdOiCyytDbFlYa7XXM71IeQTSNubTi61
QOPpAGQAAAAAAAAAAAAAAAAAAEBRFAEFAAAAAEUAAAARQAAAAAAAAAQUAAQUQFAAAAAAAAAAAAABFAAAAAAA/8QANhAAAQQCAAUC
BAUDBAIDAAAAAwECBAUABhAREhMUFSEHIDAxIiMyQEElM1AWJDQ1F3AmQkP/2gAIAQEAAQUC/wDSCxTJH+kMbykptGmz2k+HMLDf
DmQmSNGvw5Ijniyf8fFlyIR476S6ybqtiDHNc13z65WpFrKsZXW1xu7ay6D8RIa5A3GlnyfiJETvrGkNxWuT/IVOyHhq5Kq7iTdK
VyS4MuCZEVVHXSyYOnxtZEbkSvba3kozSlq3MgVBFJJN2lyqXouN5jd7UREa8X3x0aO/H1cR2Ep1wkCWLPsuR4kmWRaAkUR3w0/x
EGdLgyay9BOe4ozBk6hDMsuPb1WRH2NoX/T07Eb6G8aOXNzO2v1XmmIrVyMvTNuw+Vq+NKRuNny2Yy3OmMtgKopJ5hG6taTMZR6/
WBnbOVwSmKc3+Ga1z3x6lzsDHCBJywlyq2YonAkDKIcxcla7VznSK26hZYyIhwVskbrPYpvq+xYoQuwsKN4c83j6zJ0lSVxgljnj
xZMskLTLA2RdYpIS95BCstqjhVZ3lywGARhoceRh6sw8+y/4OLVkLgY4gNkWEcGHsJBsixTzZcSobRx1jkilrriPPVHuarJmT66v
smWMSTSOij5F4QWtfKmXopmotZsMt49ehvkJ2QDcZ7ssr6FX5YXE2yXgiqigszjwEwEjJEQMlJNeaP8A4EICyCRa8UfDygxmybE5
+Ooa8lTXWttGqY2wWNtLkorkWp2dzcGQZRI5WrfSmyKwZEGVPdEX8yD+GdShQQVKmK9zsm2MWAyy2SXMbxYxSPVFReEezKPBGGdk
qtGbCCeIn72HAfJwYhhHLtEbjnOe7hpdQllfmKwID3i2O3wqiwSZV6ATpkahXjA8U2mlxLiPLBbF/DgJHbxjERFIpX0jnvEYwo4b
Pa1XNYhins2ypdV3nH74GL6oFYgpCFAUC4MjxPiWTDYeOKQOXCJFd+7g1vXhHjAKZPJJ+SJVyZUPTq9IGqPRHtlaKjruBXw66Lwn
18exj2tS8JyqXyuAOfj8+nK6z6KuNrh7jLDWpNVbUk8cSTucJk/UeAgkM+PEHHwjSIQscV7Ca9H4euRcVFa7Idk4OflmFOrnR/3V
fXZIkDjCkyiyicdepB2K253WWI1oh4Yw44E+0u/qYWSt+hjU2+2T8l7HbTSFknO4RUemcsfIaY9NRiHGydCDYQrhrqWRR/1HTFTp
dGiPOoxsEPhHlPq59lWDtAS5UlHcYk0kV4ijOGwru1+4rYGSZI4oTnJINgQPM5/R15XR4tfQwaPz6KmlLJ1vLnaoEFllstpZO5Pf
nba1qCxycm9KonujoxhudKnONnT71l7Z1JaXaYVomW1NCtjBY0TCw2LfInJOMqYMSa3bdotzTDtwlEQB+MWUSKYJhyA2Vf2V/a1s
HvOkHHGBIOSSfIsBxsmnYiZQQ0nbLMc+5uTAb6dRSQxtYvNmLMR7CHxrM5ImNRHP/BjG9eP5Nzt8kRnNVbya5qJis9/xifrG288a
qOcn6p4Tim8FVESTYK7jr1v50e6phXACiIA+Na5710m58ftWNNLY8ZwWELxS/s4MRZUj8sIZkt0s7Wue6LXIzJ8vtN4a/KDDmaWD
vX65sYHx9iYFSnIVFxXZz4O5uXn7qN3X7PRO2jSc1F+HoaxFxwvxvao1024dKgFMOPHox+qRIT1dGKZgWSJRJC8QHLGkVVgOyg3V
MK4AUJQn1rX0hDRETL+7hVMT0MZQd0E0cmO+NI/YjG4pY0dsaPaTe8TIMXxxS5KRgucrnZQ6/LvZf+lqodFqjS1mzORVZeJIdMjt
c2Ov3VyIiL04wo+7Ej+ozB0nU+07Y5ye2P54SteLVGjUjmvVq9fJ6iYq1kgtbZW5EtJseKOFvZDthzSFeV/CLRTZCR6GsZkeq197
pdayCsc4pEebXMlmgTUmuE3uG2yWs/Z4MubAnXJlmCnxElxlRUX9hUxOgVnL8cGVsXmpjMAExnnNw0uOgNNvtqDVP0k5bC+/m/Mw
2EkjdnU5V5K1RQJnjJWzDtm1BwpW3VpWtnNACLArJNkSMKp9Rub6mlQZc2CW1MIawMVyuG3qLmoQZIotp0p8SJzuu0yNGNLkQapk
QsbXjkxKKtRsnXIzmGFPqyAmrXT0dyU0dxistRDoGuUr47U9Q2VypTQJflxreJ0u+vAjeVLI9gQnM48iJGWSdVYIUuS6SbjQM7eq
7p+Ldfh5y8dWNel9p8eRFcAwSxwkkzw1TQ7NPrbBs68hSaadBfcSY0mtBPitkPHITZpJYhaWeVwdcl5IrhRobI0F7FVepHcsYB5Z
VIQbqO3K1fiUq9ShEQ54sUcCNXxvHCxXsRskiZYW0auq7HY7WW9vUYVBPKPPxNy+gJOrIyowzgCKXZS92PEkrFkuaw8c4XR5P1q6
N40O4k8yNar3xgNixp0zyH8fDe2JRuR+sbunb3D4fSo6LwulV276sDu7FOF2ty6WrhYUQ2Bhx44tjmtqqjW6UMenLDAH4kzKl5jy
Gyo9w5LyJQz0gzKV3R0q78Opg8u3XtsypowXxrCllwL2lopjTRtZkphw20VkcrDR/wCZ0KPYwourTPWBa6AbrzXVjBprNZrJJ1jC
kowdiv6p4kLT5VRLwsWbRiAA7xPN9Stj9+dIMkeM5yvfVR8sJvcXgiK50SCgslJ1QtQL3tM32qlmma+v/wAp4Xi9rddQCQW1WsFs
2Kyzto2JsdYmO2ajRqtJe3AkVBXIGg2xWo7CxQHbJgxpWbSAfolpD8GVDgTrKRSUVnUytlO+PqWnXYTRPiAEKVVcJBw/LLGYkhqL
PiOKeFJDNiq5GtYhnKg2PTxY+XmuclLYtlVvNVyObutGnXlZW1sSJa3o4EZEJPLKAsaX9SrB2YNzI5kENxTTZSCFwGJ5SRorI7cV
OaalceJGGYon2JK7/UfDb4Louya+9ZWwfZ3JFztDzsByVcRIgUsBMjTIca5rWlva1jdkhJi7LR9MXuXNxePYXZdSr/T9Xzf53RW6
PB797vL0NKZ+mOnVI2iYszatdNbTJg4MUceYGxiwRbhFR9VbV81vDb6ZFiJjHuY8UgaAm2rKavkSDS5NMf8ADcA64/04ofImOc0Y
ikUphF7KcARySHhCwA+EuYgUVVV1Zs7vFlmGkUBUPEubUdNVyLiJtGq66bqtF/UnF0ISvWvadsGAyAHFGxcWIHqs5jIFVAqyyth9
kSYccaDc3K3Ntp1b4NBOJ6n8SsGdsSERr1fpgemCmCeLsb1GDEngGpjxpG30Ia3eKqXnMMmNdVrqu2ySd0OK97ykyOZQSnIwoSjU
RvpUgfe4L0QuMWG4+MY0bOEyb2/kJAiyNe1U6n1TaweRp+mcm2eunJF28n9zHkaIT9hrO0uwk7wruOrmPaQfHbJZENruvLW8N2sU
h67U61a2EmfLFUUOsienCwf06Z1uTNRjkZX4GQ1i7HqorSKSG9C0+3yacFtZatbhg2c+sPM2YVzBiopy7PTJWadxqjd2Dch6ZP0o
IuzX2xe5Y8IsDn8kydy+XTismUmsdcOccKSIlfVWtLfbAJYW3wJ4rSo4GjsfhJUQWeFAk5HjWsJeHsiQZLfI13bHXU5ffB2STt5U
xCZt9qyzlVrWLwu15aN+F2Ug+1ryqveIBhnHvQUNRshIDwQKAtkw+lWLkfrsoLo9VBiy4yS49rc7M241Xh0O7VQXtzrMPdrvoxx9
6W5yMY9yvI1rnuiwmi+SZO6vm1uxbU7FPM6PZnvCTTN2GZXiu7P1e6orAmvIjmEHnLJUEJFDEYB3HZp72RtnKOKHS6lIVPstm6tp
IU5lSlns1hYtjxQxGwSMHhryOzIuxN6JWqQrAMN/VC4bdyJfbS5BT9eF2qLLEt15UodvPHAEKu+HvAInGMWO308b1GVFaRhh9qR9
CnH1WFmTt1mRo7AC4KqIkuapfm7KRhKqudV3sqsw/gXTZgSClL7ZFrxytXqbqTrs8RRmAUw48Zl+IxhvYUPCw2UAjajEkTLZ2mNk
TGojUeNNgvtgsWT7bHSWjYQryY+QJiNmMyGWQpoKObFwCdUg0dJ+93hElbVA5JAw1NZGNXNl1kPU5Lpky/qlprzIcbxw5IH2pVYT
uVtuPosPoUbPybx/5QW9cng97RslS3SF+RrXPewIoISEcUnBF5OmDYSO9uQ06Km/qxyxQbaxoJNnsC20QDk7lDKEuv2O3VcLFmXO
wLX1gYMavsfFn+oQWY27NaV+zyw0lHwFL6UlK568s5e+ulRlnGf0lyD/AMzXlQk2EVrrKvX/AG0+xiVsSLs0WQXdbLxKcMVw9F2l
6O2eujc14WLmOm0pPe6Zzj/QqW9NXdO5z69vOdhTMCORJfIf8gQvOQYgwgHO45fkr5IvClAIAY2dMMjEIKZXikMcB8EgntYUIbCx
NXawEGQoH5qtRAhRj5FeymFGn7mFo5UqROmIicuTMYGK9waMxsLS2kZFbyd1uESDsUcrgSwSm9ZUqRKkL4fx38sp9gixqyZPNbW9
RBjsvrywdb3keP8A77k6xtERETJkjxwZVv6LKwZ11v0ITemus3dVrWJ+bIksjsKV5ifJHivkOYwUYEqSsgnzd83jFajRYQSd+ZVx
5GD1uv7oImeO1mMYjGk/t18R0p0tfU5KVBXI6oktTw5nNPvwjWtjFyLYgtayXQwpDjxnxjMIaM6r3KbCXaNjgWmvsKrHNXuvbzRZ
atdW1o3TJ88yCdFEgo2OcjGSDKc+Ad0Snt6h/QEnIMxeqwBJ8cLnK53yRYSmxEaxkyX33fOAalky/wDk49v5f6mQ2opefFfxYORI
8RERqIqtyFJN6hXXUJgjQqi4DY6B7zIsqvm5Rl5TE9su4vUQsSS0KY8Ko3Bv7b46Nck96qzT46kv7UMmDq3Cxk9TsAB0guDXqGdv
TK+ZPumG95PyxYHCbL7q/PGiyJkmj1yPWAe7qNgffCh6HeM7mie2fxz5OudckVgmva9vNFwbugjlfgyPE+DZGLXbJCFbUbXc8im8
aa72fKB34MaYVRP8OU09IB9fLorOK1g8X8szWSXkiWk+BKl2Fhby8mSOwDGtVz4oGxwkTpNDXqr7BOVn8zf1/wAk/vcWtV7osJA8
J0zq+ZGuXBQkanRDfMpn04IC8+eCb1Y3mMqojm8uLuH832qQ3ibFd4/d6ciyRHC7q6ad/wCV7YcPjzMgTwEic8IcdfNAUR2V8jsS
4vciT9mpmNCf3ko5UUdvI6Y4q+a4vlQXSDKc+QI3bZknl5ld/wBXaf8Aa/Mn6kwv9/gILzEjxmR25NmfKGOU6+AHqlOdHA8qvXqw
JigND22WPIl/VysjYdnNsd/ULgnujV6iO+0mVGhx7zYX2qo93WSS1zO28bw2c0C0NrAfN+6bOLx9r5574I8mM08kkp4TljliTBym
iMpoASouSaOnmrP0GSFZcCZANEJ2Zcj/AHdZkGN3SZOk9kWVn/V2v/afOxebJCcpmR4z5DhCYEeTZnLgwbyKyvkOxtY1MSNEHhSm
5LzRe6rwJ+pUz7YnLgCXKiOibdODgdxr+tm1UL8JsVKo37NRtQ220w0mbjNLkiQeUbOaqi/dXJ6eKW9qEjxnNjtnQ8nepTT9srE6
kyOZwSOaF6OhouOCcK0l2gZkRzQHZ0K1kwYnlEGSDaNbDWnj9Jqs9VLk2rJA4+OOJoCkcUuVv/V2v/Z/PHd1Q5ydNlDjId7URrcm
TeWe/MUYDMdIXEkERrulfk5clX759sVuIvP6S59sT9XP2avJ/wB163cmF7YfLJiCDKGWKUKRDIufynNFeIRUA2TAkVNuCzisVxWh
AFw5gimhVzXV95N7tZP87vjPrOvWGW2q21Q3K/2rbJedp89c7qrLVvKzrF/OyZN5cIcXoHI7PLOlM5qxcX3RruDvsn2xMVMRcVOe
e6Zzzqzqz3XETFXliYv2b9sX2XP5c5eae2IVscflm6pEfrZGkd8PPkvDmYEmnuQWoYpGv4WkFtjXXUYkvXq29VuJ75EkF8bYIgYW
xxk6YU1eqx+enfzg3LfzoC8p0ybwhB70qYTkmcs6s+6foVcdiLzTGfbF4KmIvPFTnnTnJcRvBV5YnuuLxd9sTG+688/VwiP5skDd
HOnSYCc+KqeJKpboNlFbsFW6w/C5i1MbyrKsWBaVNkQZa13VEvX9/Z2p0tI7qL89M/ka3Z1QfsvCuH0RZX/K4OTE+y+6NXg39WJ+
rgnDl7/Kq88T2TP54/wvsNPZq+68Av6GjXvAXqCZJj0Vkoa4ioqZ1Hr5rSSjyYl1PrzQd7kZs1jW24lTqTW7JsmGJVlWx39EX6EA
nbsZLO7D4vVQQjP7qc/fj1Y7OfNPsb+U/Vw/+3zKvPGp7/N/Dvuq/hanJM588/iJ95w0XFRFzpxHPHg5i8uYZA9ZEMGxeHXW4J3w
/gEydqV9Bai4CceA+qZzmWb+iv8AoIvJRvQgpQ+zMwDO5JlP6zLipzz3TOfBURU+2N9nP++M+3B2J7/KrufBE5J8n85/+jv7n6nq
vLE9+LSoMYvzkYN3JHNXgqIuc3I6uJ2bwRVE9j0ILNzpfCnkenRVM5Rrcn4/o1ZeuFbi5EyuRFnSlVs3nz+Tpzm5M5ouORWq79Kr
+Fn6ODvs35FXg37/ACr98X+65fxt/C18aQLOaJnNVzkudOATmeQz+oOiPTOZBqhEXFc3k16eRVXcSc4s6UltG2aUzD3FFZ18wPjT
QS4gIksyHl8lXEAZ30KwvbmzRd6DkLn58tEM3krc6k4889lRWYnun8Z9k4L9k+/By8Wp+H5XZ/Dv7nJVJUUyR0nB9aaJNOr33trA
spP5q4gJbsZEnoqwJxs9PluRKfniVEdM8CvbjIkHojhtIxvCnuz0py56THzw65if0oeeXXMxtkFxbCR2IvztVWuERCgmB7MyuZ1T
Ue4bl5Z985Z78FTPdMX8SORUVjXOf40h2Mr5i56cZBr9uDl4p7rxRj1xI0h2JBlLnpsh2NrCJnpHN0KKKCeTN74nrXdflVg89UiN
xbkeLcOxbc+LZy1xZ8xcWSd2fjIqp0uFYmCBbOWuLOlrinM7IWvXVlHZouwOxvw9uehfZayP+GXIWRJ+hVG5stWNcGvIETXFZncb
id12JFmuxK6c7EqDrjajPTorM6KoWeZWsxbeO3FusW5kLkx7m1fS9+JDlLja+Xy9KOuJULiVA0zwIQ86KtmeRVsz1OE3FuBpi3Ls
W3kri2cxcWdLdinO7AxZcrGa7eFydWT6x0TSLuZFZ8OrJcZ8Nlxnw5gJjPh/RNy70SJ6dHjEPZCqq0LVQIAyjulTeNdBLZWkSKKF
C4XcZIWyWDu3XfOxjiEbUy1xtO/G0oc9Orx5/SBZ6jXjx1yLHXJMdbS1xZ8x2OMZ3Go1ufdBF8OrFc/8eAAEXb8lbeNi3LMW5Ji2
0tcWymLjpcl2DiWMprNavi5KinhS81/Uz3sMfw3AmbNSRKezjaLRMAzU9eHl7WOqL7NKieLqGbg9bPehjaIXBxgs4wGts/i3m1S/
D1H5NApuzDyFYgnGzfo3Z2on51B9Cum+QOa+bHP1HM8VJbnwWnbEXBfD67fgvhudcF8Oa9MFomvjwWra+HNu1FsZnD4eAI+9zcZn
h6gIRDHgfDsxYw/h1Vpg9E19mD1PXh4OmqRZv5h+sVUTwqRVRrbCUs22zUoniahi/wBa+LPDfKjy6cY3FLFA2LBVURuuItx8Rs2i
a6Bqj5couQo7plmidLZ0hIlb8Oo6vPnxFldFXxpaslxdiEMEfYrVKfX/AIcyVU+fEeNzhVq92vVOS/Ox7hkY4NnBch4MzVtmHdxf
mv5iV+tcNBhePrOfEabzPq+uxamuw9rWRnk2vXh4TeteHhfiHUtwBl2T4h5s8vwtUyMB0qaIbRBnSUh1nw8jONa8HsaQdfQOh/Ez
Nkl+Fqvw5ie2bFSvva1nw5hplVp1RVT+4PN1njBqWmCZD1HyB5vsvv7Rx0ys9Mp/Ifm21V7dT9V1+2p7nvFzbBOl6fUP5SJzO3Yf
QgPIyfddPb+HUDqLllMbX1Bd12MmF2O9NmmpK/0nnxFndFdjWue+uiNg1OTP6/8AE7NjnLX6xDgy7OcPRdgfg/h3bLjvh68Eb4eQ
0Lc58RZnRW5pcXydu7w0zd5yC1LSQth6p5KYO+Y/a/JditE6Z3yZvs1zaPVQLE1DqdnS/FaqY48ZmWuz1tXGnT5tvYhAkaI1Op9x
L86/RFXEjSFTW6n1e9Vea/IYKSYkJVFZW7OUr6FMHqk2Ru9Ya3X+maznxBmuHTiqrM+RdRv5R4sdkSDm6TfM27NTh+bt3W1Ms544
VPoEXuXPksz4hzv6Z8Po/I6nJ0+QTNsnuBqGkgWNqyveubvK7+0ZoMbph5vh3PmgjpEhN/Ua2N/quPIFLh8N1K6XtTRNAFqc32lp
KmW6uc7jrMXy9sVeaovJUCBudSpm42roOu6xVek0ObJtc6PdLtewrjNmvUO5Uc9F5OvgeFtdqnXD+hG/2VHrkD1PZ+6PPIFinHz8
nPJXPIIubDtrKhhHkMXNAichZu0vx9b06L42qZusvv7VFtbOFH0t1jIZm/SvaFGSFVp7LO0nzrdugwkyBAjVldyVcaqXPxVVea3M
rwtbzRbPuR8anN9SvrHxM55byfD1/wCTSHxI9o69pGY7Ztebjtu15uO3Wgbku9hWO4P36uVTb+Px1VVdwHu1yKMu7365OnybKd/y
KD54wu/LujdIdCg9ETHvGIRNn18eE3WhZhN+gJk/epkiNRageatvqQbKQPQq1Mhw41fBzdpLpWyCA2LGx8aKQrUazFVVWRIBFiXN
y2y2auso1vAzpcudt+PKEKbFt6yE0yVXV81+2a63No2WBZVGV04tbaO+IBMNvlkQVXbS6iQ7cdidky+uJ8f5OS52yLnjyFzw5a56
fMXPTZeJVSs9IPiU5M9Gz0dmelRkz06CmeJWJjCQQh/n5qQHMk4vkWNbC9NpM3eb42vcdGgpJvOfPijXLmw7eyLjnOeTWtrF4z9p
14eP3SgZj98q0x/xAHlxeTbmRkC0n1ZX7PsBMfb2pccc7+KI5cSOdcSFLXErpi4lVKxKg2JTuz0ceelxEzw6xuduobncqG55lY3P
VIaZ6wLFucW4fi2x8DOmnKns2XZkcXzZa4smQud0i5zX6jf9hQ6nA8/aVXmubnN8raONDs46KtJv8/H7xeuwm17CTDW9rIb8iBM7
Egy1xKyYuJUycSnJiUyZ6XEbni1TM/o7c8qqZnqkNuLcsxbl2LbnxbSWuLYzFxZkpcU5lzqcv0gAJIKAA4wZ07vfsIQe/Ouje+iw
uzTIiqthfVdU0pHmNn3xAHdiQZi4lXMXEpzY2mz0qK3PFq2Zzp2Z5tazPVwJi3K4tufFtJa4thMXFlSVxXvX9tGiEkvGMUYE2ep/
2NKH8MgjpVgbZKSjrbLareywcOSXB1D1zx6uNnqsYWLdLnrB+caSKSOaCQRHuN1fv4tc4mOeKMCXMfJd+xL/ALOlFXyi4yrAJPLr
o2EtyuwkqQX5WEeIkSyYbJMQUlsmEaN+9EEh3xoAwZJmij4Y5Dk/YwkYswtrGZhbSSTHPc9foxbEoMEcUgcmrG/CgKB/7hrXPdHq
1XPyY4ZVmrv8Ex7xvj22cxHEeqY7DRjAX9owbyODVOXBhDHZIsxswpinf/hBFIFwLbBlCdpq+MXC1Zm48RBL9ZGuco66S/BVYGZ+
UAZrUbcNJMdf8Qiqiis5I8HaAdjCCK0kKKTH1I8dVHTHV8tuKA7c5KnHkuIIq4kOU7G1klcZU4yvisz8oLSWUZmFtDvxz3Pd/jmT
ZQ8bbGTG2wVxtjEdiS4q53hLnUPOoed0SYsqOmLPhpjrUCY+3fj58p+KquX/ANs//8QAOREAAQMCBAMDCgYCAwEAAAAAAQACAwQR
BRIhMRATQSAiMhQVIzBCUWGBkaEzQFKxwfAkcUNQ4TT/2gAIAQMBAT8B/wCoawP23TmFujuy034OcG7n8zHU2GWTUI0zJBmjKrmV
cQ9C0Fciul1e/L/fgmMEbAwIDRFV1EKq2trLzPKz8N/8LLiEPx+6ojVy/iRp0IjF5XWRI9n8nVYrHD3WalcqrrtXaNVDGaNvdddQ
1LJtDupaRrlJRPbq1YLTciI+9VdJFNE67UGOcbAJlET4kIIoxdylrOkaraHyo5i43X+ZQ/Fv2/8AFS4lFPodD+QllZE3M86KSqnr
ncuEWb/d1S4ZHDq7U8Gi5DU9mVRVpZ3ZNkSHNuFSVWTuu2Q1FkQApqwN0Zqnvc83dwAvoN1HUMecux9yqsLjl1ZoVDWzUbuVONFH
I2RuZh09bU1LKdmZyjilxF+eTRv92UULIm5WDg0343CppDC+/RMeHjM1VFRHRxZnnZPmfL4tk3LbXhV17Yu63UoVMgk5t9VJTx4p
Dzo9HhUjJmttMVNAyZuV4RbNhr7jVpUE7J2Z2ernnbCzO5QwvxCTmyeH+6J746dmugULnSd92nw4bIHNshGg1EKmqXwOuFUTyVD8
8hRaQr3VSHmIiPfhBTPnNmqhiFH4FNCJW8yPg9ge3K7ZPZJh0uZurSopWytD2+pJtqU9zsQnyt8IU87KOIAfJUkT6p/Om24W1T03
QaK6AzaBPhytu7g6Itt8eEjcuqKOHGSdxOjUyNsYytRcAqao5Z+CqKfP328JGtkbleNEHNoJ8gPcd9vU4rUn8Bm5VNC2jhu75qNj
6+bO7wprQ0WCC6ohau0Chgyhxf09yLo3nvXUrDAMrtbpti30QuiZfaUo2KedEduF8xsEGgJ0d9lQ1P8AxvVRTZ+83dNwGSWIuidc
rE6Bzm5HCzwsKqs7OU7cduWQRsLz0WHRGeU1D1Vl1XL5PHsN1FE2JuRqqKlkAu5YfUOna4uXXhELBjkbg36LO1Mv4/omk3c1NhLX
XDlWNzHOEdUU7eyAHBpsbotuqWozjK/dYU/J3XdVj1HnnbIOoVWykw70pF3FNeHjMOvaxebQQjqoYjBCGN3VPA2FuUKrrWw90eJS
PdIczlhUT2guOxRJBHCnkuwt93C5XcKdYrL8VKLN4blHfsGoYx2Rx1Qd1CppxIwPasYriCIuoCrYefEW9Vg8+ZhiPTtRf5NaXdB/
HCsxHL3It0TfUqioL+kl4EXCGyaSEw5mqPLfvIsjPRSNDXWHCaYvNuiJstk03F104BZKeoGWU5XDqvJI6c92S4/vwVJXmnkIAuPs
nvLzmduibI/4td8D/P8A72amTlxOcsGj7jnqsrzJ3I9uFFh+X0kvFkmfw7J101Fois4bFXTuY3xi3CeSw0QR1KmQJtYIPc3fgdk3
xcM2mXhW1pfIMmwWLND42TBU8nNia/sYs60FveqX0VHf4INLjYKjoBF3378HODRcrmOrHZW6M/dAACw4dVEAYwCo4TFIA7VixKrE
jW6d5MhJ70v0Ve4OACYLImyJB3QNlum+5e5N3XmuUwGcHbor3KxOryjlN3UcZkcGtVVBakMfuH7LB5M0FvcexjJ7rQnxONKI272C
paNsA+PCWVsTcz1mkr35dmqNgjblb2ItGBA3TiGaNCLiVW9EXlNN90We5Wsi8tKaC5ua2i2UGVsgc5PeIaR7nbELa7k9xe4uKw2l
yN5jtyiWvuxYIbF7exjXsfP+E3YcKmqZALndDm1sn90UMLYm5W9inpPactkXZSnOJ4TQiUaqSnLN1ayYdU5ShYbOGOLSnwRyi9k9
pabK7strqoje5haw2VNh7+b6QaBVNQIGZlhcjnSPLuqw3u1cjf8Af79jG/Y+f8Jhu0Krrmw91u6YySpk+KggbC3K3jbgyVzPCUK2
4s4IVEbha6D2nquawblOqmjwp7y83PDLrfhZOflOoVNW8vToqnLIOaxbp40UXdOVVvOkk7zf9KkphAy3VUP/ANsnz/fsY030bXfF
GR3kYe3ewUMLp3ZWqCBsDcrfyL2BwTmkGybK5uyikDxwLLFXI4YZ3qqR3+/37GKszU5+Cw/01Jk/2FBA2FuVv5OWLMnROCY4sNwm
vuLhZvenaH4JzsrC73LBGeN3YlZzGFnvWCvsXRHgPyZBCLQd1GzIgnsuq6TJTOWFR5IAff2ZP8WuzdD/ADwHr4IHTOsFJTZXaHRP
LWndOqYhu4fVecKVos5yfilL0KOKxAaNKdWw/rXnSAe1f5KoqYqkZcrvkm1cjG2ZCbBUVS+obncLDsYvBnjzjoqKbmwhx34Omjb4
nJ2IU7d3o4vT9NV5zLvBE4ryurd4Yfun1NY17WvsMxTpmN8RTq+nbu8I4rTD2l52jPhaT8l5wkPhhK8prD4Yvur17v0hcqtO8g+i
bBVWy882RwzN43uPzQwin6hDDaceyhSQt2YPohG1uwUsLJRZ4uhSwjZg+iawDYKyxBzjlgb7SYwMaGt4n4IT1ckphLg0ryKod4pi
vNLXeNxPzTcJph7KbRQt2YEGhu3CyqKKOoIL03CqYeym0MDdmBNia3YKyHrsU7rWyfpPZr6bmN5jdHNVFOZog88L8ChxutUEUPUn
gONbHngcFRvzwtd8OxichbFkbu7RQxiNgaOnC3EflSsM0jdGfZPYd6esA6M/fjf1N1dGRo3KNVCN3j6o19OPbRxSm/UvOsXQE/Je
cb+GN30Xls3SErymqO0P3XNrD7A+qqK6pgNnWumCue3MSAuRVn/l+y8kqDvN9l5DL1mKpaTkEnNe/F7wxpceiwxhyGV27teJcBun
VkLd3hOxOnHtLzrEfCCfkvL3nwxOXlNUfDD91mrj0aFy607vAXktQfFN9l5vcfFK76rzXEfESfmhhdMPZ/dCgpx7AQpohs0fRBoG
w7NbXiHuM1cqKhN+dP4vUYm4lghbu4p1bBAMgP0XlVRL+FHb/a8knk/Fk+iGF0/UXVRhMUjfR6FU9S6jdyp2/wB/lRyNkbmYdPXO
cGi5U+IOlPKplR4eIe+/V3qZ6Fk788iip44vALdmWFkzcrwn0E9K7PTG4/v1UGLNPdmFimvDxdp9USBqVPikbNGalCmqKw5pjYKC
nZA2zB+SnpIp/GE7C5Yjmp3ry+pg0mZ/f2UeLQu8WibWQO2eEHtOx4FwG6dVQt3cE/FYG7arzjPNpAxDD6ifWd39/ZQUUUHhGv5d
9HC/xNTsIgO1wjgrOjl5mH6/shgrerk3CIBvcplFAzZv/Xf/xABAEQABAwIEAgUICQMDBQAAAAABAAIDBBEFEiExEBMgIjJBURQV
QmGBkaHwBiMkMDNAcbHBUtHhFlDxNUNTcpL/2gAIAQIBAT8B/wBoklMWrhcepRTMlF2G/QAuntsbcGsc7UD8zUYdmOeDquTcRmgd
y6hqwypoKg/XPIXlGHQ6RszH58U95lkMh0V7m6G6w7EDRl2l7oY7C/SSP+Vnwuo3Fvh/hYkcPp+xLr4Jla6oOWmZdMY7d5/J0eDS
z9Z/VC51Dh+jBd3z3rE3MxJ3XYAqzDZaTrDVqpsTli0uqbF45TkdoVO/M5MeWlPniiF3uspcZYPwxdGtqal2VnwVNhAHWnN/UsOx
DyIZWsFl9hxH1O9x/wAqswman6w1b+QhgfM7JGLlRUdPhzebObu+dlWYtLUdVujeDyWsL1FLn31VVg7ZRng0PgqSB7Zg14sQntvt
wqvxnWVJhD5OtNoFFDHE3LGLcHuydZ3Z8fBS0kkbc+7fEKjxiWHqydYfFT4fBXN5tMbFSxPidkeLH72kpH1L8jFJNBhcfLj1f87q
ad8zs8hueDxbRXVkAQpcsgud0RZNYXusFHSxQEuaLuPen5y4WXqVDhjp+u/RqdRxOiMGXqqGslwGp8mn1iOyrpKd7r04VPUSQOzx
lNdBiseV2jx8+5VNM+nfkf8Ad01O+oeI2KonjwyLkxdo/N1HFLUyWbqSqhjIjy26nvP9kB3rtIty7ovV1dOaHJoDdArg7oiyo3ME
zTLtwqauOnbd6xSTziMsm3d6lS1b6R/In2QN0yR0bszTqo5IsVhyP0eFNC6F5jfv9yASbBRtZhdPmd2yqWmkr5iXH9Sq6eOij8np
9zvwv1VGnangTbUpsmY2HBrweEfW0TUMWEVO0DVykldI7M86oMJWI0HPbcdoLD8QMJ5Uu37L1hRPfG4PYbFFjsSpzIR12/H7nBaQ
a1Mmw2VXO+uqLN9ilkZhlOI2do/N05xcczkV3JhtcLQbp8oJAag17dkwiU3CN79c2QEY2TPBM3QPW4BoYLlOc4pkpb2ljWHX+0RD
9Vh+Icr6t/ZQqwHDMsNruRLf0SsZo+W/nM2d+/ThiMzxG3vWKyimgbSx/I/yqEMooPKpO0dlPM+Z5e/dUlG+pdZuyxWlbTua1ngh
qOEnpBaELK5OOmVO9EozAjVqpnaWQ01TVHa104uQKezMLFNkIVdh/KkD4+yfgnNOUI1wp2ai6w+bEMYIhacsYT4zGcju7pYFALun
d3KecVFQZH7fwqmpdUPzH/hUOHOqOs7RqiibE3IwaLGpo3uDG7hNAIJ4TN1HQBsrjwUOruA0CZsnb8LrlOcMwCt4p7bGy8jE9s3Z
WHz+TTNcNv4WO0+WQTDv6U32TDwzvP8APCgwkv8ArJtvBAW0CxHFLfVQ+/g02KcLFPAKeLHoxR5WpourE6Jzcui7+DguuzVuyzuk
9FSQ5ggLaIAnZD7Zh1u9v8f46NJFzZms9ax6W72xqgwtsVpJdXftwxHFM31UO3jxki5Ys7dR2un77L8S471ZZeEMdzcp3gmnKFT2
1TgNyixruyrIdpO7A4evhh+HCOE8zdywR5jlfA75sqqLlTOj8OhgjM1TfwCq/r6/L6wE5waMzliGJmfqR9n9+DWl5yt3RibQNzP1
kO3qTnFxueG4TnEPJCDmya96EXrRe1ujFRXBJUhugLpoI2Kc0k3KHV1TtdQr7pw6qEzc2UrLYLB6HOec/YbKWVsTC92wVJU3rRL4
n91jsWWozeI6GAN673KKZrawyv2uVW176k22bwhgfM7IwLJFhkebd5+fcpZHSuL379CTtFbLV3aKsqLvQjb3p7bdkISeKBvsmxte
1PLWOyk6q19U4nLZAZniy1NmqNgjaGjuWL1vMdym7BAOZaT50X0gbcRv/XofR/0/Z/Kf2jwpKJ9S6zdkeTh0On/KnnfO/O/iRZTV
PcFugLoDhDMYzcKKoD9lmBUrdEzdQO7ljFNzGh4F0Kian7B9ihkbI0PGxWl1SyRtkDpBeyrMUYIfqjqfgqOldUyZQsaiayKMN7li
3Woo3fp+3Q+j/pj9P5Ugs4hUGGuqOs7Rqlkio4vAKpqX1D87llKy23Wbg+Nr9wjSf0lGB4N7IscO5ct52CbTOPaTGhgsECs1xZWI
V02MvGhVZh3NF7WKoM0DzTyexHRRu1U/WGdYdyIoeo4HxVdVmpkzd3csR/6fH7P26H0fd9a5vqTIm+XljxpcqoqGUzMzlUVD6p+Z
yJtor/eg2QPimSZTdqa4OFwnwMfuFNEWGxWxTZLhZWu24Yv1aOJn6ft0MGkyVTfWsS+z13M/QqpqX1D871s38i02KimyfomTtKkY
HixT47Gzlk/pKZq31oMzyBo719IX9hn69CGTlSNeO5Y/HcMmHBx/JDayDmuKa9zdipZM/wCqcLKKSx1WHRcyrb6tVjUuepI8NOjF
9sw7L3t/j/Cbunb/AH8koYNU2e421TA5w0CZSzHZh9yOGVjjdrFHg9Z3j4puCzuOrgmUFRf8MrzPUO9C3tVJSTUhLs7faU+gie/M
+cXPhqsQpGUrxG11z0MCqeXMYz6SrqcQ1JaNkUyCR/ZaSm4ZVO2YU3BKo7gD2rzSG/iTNC8jom9uf3D/AJUdLQvY97LnKE2GR/Za
Sm4dUu2jKbg1WfR+IXmWUdtzR7V5siHbnb+68koW9qb4K2Gt/qK5+HjaIn2o1lLe4px7dV54LexG0exHHKnuNvYnYvVO9NGtndu8
+9Olc7cqGeSE5ozZOrJ3bvPvT5HHcq6wtjRnqH+gpJHSOL3bniLX1RpqGKEVAaXD53XnClb2IB7V56e38NjR7E7Gap3pJ9fUO3ef
ei8u3RV1TYhJStLY+9Oxmqd6f7J2I1Dt3n3p0z3blAooHgDwKsj08G673w/1A9HDavlP5btWu0IWIU7aeYxtPC3AIocLLRFBHoW6
Fulh8nLqWO9ar4+XUPb6+hhEQdPzHbN1VRKZZC89/DVW/K24C97rGOtK2UekAegz7PQE97z8ONvuxG52wTaOc7MPuQwyqPoFDBqs
+h8QvM0w3IHtXmu3alb715vgG84XklGN5/gVyaAf9w+5UuG0lQC5ma3sUhw+NxaASvKaEbQ/FeW0o2g+K84w90AVZXGpDRlAtxjY
ZHBg71i7xzBC3Zgtxa0u2CbQzu2Yfcm4RVO9BeZph2iB7V5tYO3M1eSUbe1P8Fkw5vpOK5uHjZhPtXltKOzB8V5zaOzC33LzxMOy
APYjjFWfT+ARxKpPplGqmO7z70XuO56OH4Y6o679GLEMSGXyen7P3GEMAkdO7ZgTcPqahxkItfx0XkdLD+NLf/1/uvLqaL8GL/61
+CdjNUdnW9gVLjU0b7ynMFU0rK9vOpn6+HzspYnxOyvFj981pccrVTYWyBvOqz7FX4o6f6uPRv3NNiMlNGWRd/epqmWb8R1+jBUS
QOzRmyjxKnrG8uqFj8+5VOCPb1oDmCexzDlcLfdAEmwVNg0smsnVCdWUtAMtOMzvnv8A7KoqpKh2aQ/kqatmp/wymYxBOMtUxeba
Op1p32+fepcDqG9mxT6CoZuwosc3ccA0nZMo537MKjwWpfvovNVNBrUSfwjilNTaUzPn91U4hPUds6fl466oj7LymY5Ut3sUPpBJ
3sC/1Af/AB/H/CP0gf3MT8dqDtYKTEKmTtPP+3f/xABNEAABAgMDBwcKBAMGBQQDAAABAgMABBESITEFEBMiQVFxIzJSYYGRoRQg
MDNCYnKxwdFDgpLhJEBTFTRQsvDxBjVjZKJwc4PCJVST/9oACAEBAAY/Av8A0Q04Raa6abwOO70aW20Fa1GgSkVJgPzzglWeiNZZ
+0cnlKYT8SAY/h8qNK+NspjUZaf/APac+8Kl5lpTTqcUKFCP8Q00s6UK+fGNHNNCRmz7bNyV9mEFctSbbH9PnD8sFKgQRiD6BWWH
xRx2rUsNw9pf0hpLRUlHOWUmlwh2RbkQ+GrlL0lm+OXydMI+BYVDcuh5xt1w2UpdbpU8Ykp5KNZdWldl4+sXsOfpi8Ecf8QSzN2n
WRgr2kfeA5MMtTSDg6m5Y7YLmSZsOj+k9crvjRTcu4yr3hjFACTHq7I9+6OVe/SI5hV8RhGTmUpaYb133AOakYwA0iwy2LDaOimJ
rKj3NSknsELmHTruKK1duZhfRWk+Ihxzaw6lzxp9YSoKF43xfGsyg9kXJUj4THJPfqEXtEjem+KHNYlmHHlbkJrGlypNsyaejz1n
gBFiUZXT+o8dY9guH+EBcqsgnFOIV2RoVfw80Pw1beEaGbZQ82dihWC/kmZXKOdHnJj+PktI1/XYvEKRkuRLtnFR2RXKOWGWf+mx
yh8KCLMm864zNcm5pEipVinCAnFWES+S0K1niEngLz40jdGIgHdE810mFEd1c2q4ocDFz6jxvjXQhXhGuhafGNHk+SemFbwLoCsp
PsSiOiBaVGnfTprP4kyrV7oLORpay0n8QIoOxMFx5xS1nFSjX/B7KElR3CKzCrI6IxijTYT17Y5VfKDAo5wgS89aebwDntD7wl6X
dCknBSTFHRXrEadkGWf/AKssbJ7RGuBlBge2yLLoHw7YX5I87pGqLsPaqkqHVDDy/VJRpTTwgK/CZTownr2xSNdltXFMPuMMBt1t
FsFJPbdEy+TzJYn/AMYbfyU/bfDY0su5dfS+yYUy+2ptxNxSoUIixKsOPK3IFYBm3W5ZO7nqirjZmXB/VNfDCKNhDLad1wEFEl/E
Of1DzR9402UluPbtw7IAYWmg2DZGujW6QuMVa5RPjFD/AIJbe5NHiYstIp9Ys1tr6KYpasJ3JhErKtlx1w0SkRRptTk0RRyasG73
UdXXBmsnOBlWK2j6tfHdGi9VMDFon5b4qk0MUcHaI/ipdDu5zBQ7YcEm9aZs1AdF47YSDftz6NWC0KR4RK5NZtvzikobeZaSSQEm
/wDy+MVTo8mI3k23I8on1vZQf6cyqvhGjaQkJHsoFBFMBuEFFdM//TRs4mKPOWW9jSOb++eoNDFHOUT14xqK1uicY5ROt0hjFoa6
N4/wGw0mv0i0ddzpHZFXFX7E7TFkcmjcM/lcyj+NfF9fw09GAuYtKUu5tpHOWeqC5MMeTtdBNLuMBSSQd4gMZSNobHhiOMBxpaVo
OCkm4xUGHgpNlaLgobYqYrC4QtVyUm87omVJu5daT+qLr4vPZFZhyhPNQL1K4CCiX/hmdwOsrt8wITicIocc9l7lE79sW2lVEFbN
EL8DFhxJSf562rVb374sNpCUiLEteenBUokk7TnDzqasS3KK61bB/rdC3nDRKBUx5W8qyhFUt+7DiFt6VS0KAQhVsu128OswleVp
myP6LN57VRXJrQacG81rCvJho1e3Lr5ivtC8Wn0i9lePZvhtge0bR7M1k835RpVmiFX/ABcISmllNbkiHFKJILi1eNPpBeecS2gY
qVBbyYmyP6yxf2CDOMLT5Um9brqqri0EJDUwNImzgDtH+t/mXRekJykyK2VYTCfvCi3VlxNykHYY5RPbszW21FJgNvUQvfsMWHE9
u0RfrI2K/nA9MDV2I3xbWQlIiwnVa3b+PmPzlA3LMiq3l4cBvMMqIo5Mcsrtw8IKVi0k3EGHH0v6PJ/rCEc/gIEvJsJbTt3q4nbn
0Tyb/ZXtTBZWNZPNUm4jhBTMLtLCaJNKVGdFd0Wt18Ny8izp5izrKNyEcTBcyk84uv4mAT8CY8nmlVlyFLS+kc5IFT29UKnJEOtq
Y1ltqVaDrdaHgYM21rKYo8k+7tz2Wx+0V5y+lCJhg0eaNU9fVCcoSFGp0XKHSPRV94U04iy4m5baxhFpi49ExQ4jMG36qb37RGxa
FeMF1rWa/wAv80H5hPwoMW3DwG+LSzdsTu8x2dnnC3IS3rCMVnoiJTJzCAwwt1LTTCMEiEtIuSgWQMynXeaIrBD04gqHst6x8IIl
pUr63FU+Ucihlvg3X5wFOzBuw1Uj6RacWVER72akeStupRXnOHZwhpx0DR01Gxt45lSz4uOB2pO8Q9kxMkhhSqFboUTpE4im4Qll
d9ptTJgpOIuip1Ub4sIFBn8qTUsLueQP80Jm5RxKZsJ5NzY6NxhUutBZUm5adtfM6SDimLbZqkwX2Bqe0no/zAmXx8KfrFtd52J3
wXHDf8s11yRio4COTrZ3nbmbyK8QlapZTz9bhaP2iYyvNoJRZpLIrSl/rPtEjMOrtLW2kKO84Zi2xZmHh+gdsFKn1BvoJ1U90ayi
YqYqrujCKmKpxEBSyE2bzWLDVUt+JzDyeYVY2oN6T2Qlp2yxMHZXVVwP0zSxmW6qZVaB6txgNtiiRE6heDbyhT8xinmFugWvdAyf
MK5NR5Mn2Tui0iiJxI1V9P3TCmXkFDiTQpOzzLSLxtTvgONmoMadkcntHR/ltO6OTGA6UF1zu3wXHD2bs1tyqW/Ex5Kxc2nGm3NJ
yyhqly0rgLz8oDCCf4yYsV3I2+AhUo0midHYSOy6LMy4EJlJpSVE7BW0P80KbaKmZXo+0vj9o0zpIR7Kc9pZuzW+7N17c9Y6oqkw
mQyk5dgl1WKeo9XXClDDDNMZWF8u5Ousq6r656k0EWGLh0s/k76v4hsY9Mb4tooicQNVfT6jCmXkFC0mhSdmYIQkqUTQAbYS415O
8oi9tLlFDqvik1Kus1xSsUtRaTRSFCLSPVKw6ur+Upggc4xU0QhI7otYIHNTFlIJJ2CLb9FK6OwRoWzrnHqzzL7iwlzyZSGetSrv
vDz6r0yzNBxV+wzTKGnbCLQVQ82tPnAVMGp9lsR17OrNTNQYbYCUgqOAAhLisKx1mOpPjCCkXA6xgE9sUB6ouvuqI0iIEhMqGlbT
Vs9JP7QuYeVZQ2krUeoRPZNcu8strFfZcBqIsL5yDZMWln943I6PmIfZVZWg1BgPo1Vi5aOiY0jdETiBqq6fUYUy6gocSaFJgT04
n+JPMQfwx980tKZRlPLEzFbaOimFZR/4VmRNMYrk1nXTw/13wuXWlSVYLaWKKTBaX2Hf/JJbQKqMBpPad5jQNnk049ZzWlesVj1R
XFZ5ogqUak5rLXJsJ9Y8cB9zCsmtSyb77a71KV1mJ3JFg6JTYeqvnCl1PGCEqKSdo2RNTLz9rXOKabaQVV13PaOxOe++sDSAqTtC
TSNHp2Ga4BRp3R5FI1ccwemNiRuEGVZPJs8mPrm93bBmVJoVG1fGiXdU0gjcYQvGhip5ioS4n8FdodYiTyJLkluYAffUNjWPjE66
aBNppbaOty76GJ1FKnTKoO0xacVU5wtyzLNna7ieAxjljMTB42BFlMk0FbnCT9YE5kiVS2tHrGUYPJ++6ETDC7SFCoMNZQZQ35ax
em2Ll9R++yHVWVN6OiFNL5yVbawExMKF7bPIo7MfGsJeknlNO7xt4xkPKTzLbc4/bS4pF1oCKD1ib0n6RQ4/yPlKxrK5vUI0SDyi
/AZvKFi72fvBcX/vBcXifDPLGl7pU4e/9oXK0V5RS5CfCpien38dEE14qrmEvbSKrqpW6ChAqMOwYRSLdUmhpTbAK25RKecdKceM
W3ZCRmE0oNGuzThBWJSYQnsWO8RoZZ602btGq8D7Q0y3ruucq6s4/wCsYsspojauAqammmpGXuQCb3jtPCBKMPrUkqAUUtm5O2Gn
ZcOBsUtVTujyhlVqiyFcNkCCjuhKkrsqNyvigzs0pDin0hKV1vCU3AUiUqfZZ/zmJlW91R8cwZYTVR7h1mEhhHlEyfxLP+UbOMW5
p+xXEIvPfABYCzvXrRyLbYPUmkWSXEDYQboU65TyV88pQerV0vvFQY8uklBE23qkHmuDoq++yJvKdChcughTS+che4+EUFVrO6+s
DqrGQ76HRLX/AOUVPPTcqPKkC43L47/5AJPMF6oU4q5KRCnV4mKewOcYqaJSkRXBI5o8zJyf+3T8ofr0Ef5Yn/jT8oorCFuZLYbb
e5wRhfC0OtqQpCqLBGBhthvnKiXlii0lSLdDfXGGWS4lqVVdbSmpRxhpmUnn1JLQXaS4b4emULcnGZYJt2hRYrjQ9UJWttAWoVS6
BTti0qy7Zu5QVjyNqRa19Xk6ivVGlUlhFcdbCLVlh5O4PWfpC9LkWabNLnm3dIkQgyU7RxSbLjT10UOIisO+T4gWwN8S6E1SptIQ
42oUUhW0EQhSlABhCFEnqBVFTtvhDLSbS1mgEaBvWJvcc6Z+0Wl+sV4R6xRO+L9aHJx2+zcEbVK2CAhU6EWx6ltGoPrGuooWRs+0
JybOnqYc3+7FUGhh1yXJQ7QWwPxAL6KhtSbrxGkdFHf6ice3fGTUpTqss6Iq2E1gObMFDeIKTrIWIUyrZ4+nFRrq1lQJVJuTerjA
SkVJuEWO1Riwj1Y8fMU85duEZPI//XR8oWSnntIPhE5KE2XlEOJG8Z8qskcm5qKPRuFD3wmo5iDWMlOnmqttV4iLwI5aVYX8SBBa
ZZQ22b7CBQQlphCUFVzYHsjbAMyzV1esqsMywbstnCm8iG2G3iwzip/FQ6hu4w42ZuaQhLiklQXrAA8YYynMOKfl3BrBXPSNl8eV
kJtDBQFDXdCSComl9fpm0ePNJ+EQp5YAuvV1QvK+UtK7pypVkqoAPZ8IXkwi0uuocLY2GFKTMyiXCmlTrWRCXXMqIJxoGAR84UpL
DM4APwjYV+k/QwFoc0mwmlL9tRs4ZlS0wmqTgRik7xCW3WmnEtcx4uWQsdacbobFUuD2raOdvhTkvaUzj7zfXCpaYUPKmud746UB
ad9CN4h5LXMC6jq20zPjaijo7MfA5g3LZOWpOxx3VTHlmXcpIBTcGpZN56qmKsM6JvYmtT2n0oqNRGsYW8dkFajUm8wZhQ6kwWGj
qbTvz2UipMaR29fyhwe7EkdqUlHcYZylLy6nWktWHCi+zfEhuLyPnnyrQC0qzSuy4Xw+28myosW/kfrAFpSFoVbQtGKTvizOZPE0
P6soq8/kMcv5TLnc8woRUTwV1JQon5Q3PvyympKX9S24NZw9I9UCuOMZJyivmFeiUdx2RrCLL7Lbo/6iawnyhvSWcAo1EWQymtsI
ZSNq4bljS0Ea1NsFqRlXHlDGyMIamwlBNmwS1eKbQpJoe0RPuINDorPfd9YTk5zVKbkfaJSdwmEPWEqG6lfpANL13mLTVo+6NsBL
hTbphWPLJEaOapfa5jw3K+io8pZPOxTW9PUYKjgItWtGnEXa0WitxVfei9hB4isDKGSKMzDetZSI0jidG40Tpmz7JpBUrnK1jFDz
h4xZXgqqT8oafYlm0rKecoWlV7Yq8o2jzGwb1QJ6cUHCoaiBzUCFNHDZw9KFHnL1jCZYezrKhLacVGkeRy5uAoo/TPYQKmK4r2qz
Uh3Ijq9G8XLTRO2uzjFUq7Ilp6WZDTqZtFuzgb786coH1M2kItdFYhLriLDyZai6ihqDQ/MZrwDHMTHq090N2ralum4NotRpHFAC
lbWAjRqVVC9ZKknDriw6yjKLQwWDYc+xik0xOSp/6rJp3iP+Ytk7qGvyhvKC21okZX1AcFC4vauJpw3obNnuhi0mjr3LL7cPCkXx
LZOQb3l6RXwj9/lCpg8xoRkrJo9twrPy+8C6kJ74mVpVqtHRJ/L+9YMuzlGYaaQmqiFV+cNshoUQmyk+13wJ2SUJgIOsy/f2g4xo
5+Uell7xrpixLzjThxCbV/dnOUZVBCx61KfaTFYCk4iC+dbc394QySHZsitjcTtMKfmFla1bTCpZWzWTCXwL0XHh6RDWwm/hBWq5
KRWFOKxUawpSOebgd2eicNqosoHE789hF7nyi0TU74MplBVVUoiYP/2+8KAdRbF4v3Q0+MHEBfeIM64yt0BQTZR1xlJlqUcQpprS
DSUN43RkxwqqXZVaO6n280rTq13QWpiypG6mMBho8knmp3Zr0iK2fGHZlXsp1RvMS+TJi9x1zSvncMTFAKCHHnK2UjZC5tbdlugQ
2nopEB1aaOPaxhy+rcmiwOI/cnNNTi8GmyqCtWsVXmJmY2rWEdw/fMhtTiASMCaViWbaTQrSXFDwhLYWlCjgVGkJcKVzUpStleuP
uIDc5WSd9+9HfFUqS42sYpNQYU0ByKzVH2zNhFLda3wpxxRUpRqVHbmQ6NhgpN6VCFNqxSaejcfPwiA0MXD4eZaVqt798BCBQDOW
2jr7Tu8yRyo3LtUcb0boCcFpurEraOs1VlX5TT7RPJGKU6TuNYdk1HVfbUjvH7RItvOKsIeLVCbhXVg5lOLNEpFSYC2XtOTglEay
NGNy0EDvj2TwXUwFoNQcD5knISrZemXFWwgX4YePyhc9PL0uUHhrEYIG4ZvJUHlpo6MAdHb9u2Gj5E43L2qqccFkU7YdmTzWG9Ub
zs8Yem3jVx7WJ7c2VFHcU/IZnppYol1Qs9mYsvNhxk3kEVECayfqTKBqprqrG7qjRuIKFdceR5QaVMNDmKGMKeTLOys10gjHujSS
U0tneBgeIhMvlFgMvDB9vDu2QlITaUTSym+p6ollLoqYVMVdUOtJu4DzAk4t6sJeHtih4+jbTtpUwU7ECznDj4u2I8wtMHirzZ7J
T19g6ZI6jcfpGUMmOb0zCOsG4/KHZdXNcQUHtESz05LKDaFgF5vWT+0TqW9Wy/bT1V1oYn2vbGuOiraM9RqHeILTy2vzxqSrSutH
7QUyimnGj7Ewb08CM95pGU/+MHk2kIqxJpVt/wBfePI1yOjcsldtCqpzLmEhK2m6sMk9WKu+KFRiWyPKOhaAbb6kGoru7IN3NpZ6
s04rpOU/8xHRiTQf6YPffCaYUMJt2tU1FDSJNycQ655StR1MRfX7RJ5RZat+V1tJULNoAY9SuuFvys20EWrKQ/UK8O2NUySj8dPp
BQ+EtrGyhMIVlZX8K5VFpJIsK2fWFzORFOrSyvUds7OEeSTKUJmkupVyfNUL+7PpKataVjR7HBTthdMU6w9E230lQVHACsKWcVGs
BKRUnZFtzWX8vMLTJ1dqt/nMTD5ssrFhz4TEvP5JaS4UNqQbSrnkG+4xo35laF/0V6lItOTIUgf1b/3hydDWitACldwhl92q5CaA
0yf6Z6QhLrSwttQtJUnAjO0g11nB4X/SKoP08xvI8nfOzpsAD2UnbEt/w/KK5GVRr+8rbBnlpo7NXjqRs+8LDH95f5JoDftPYIZm
XpR9KBVKRTnGm+C0g+TMH2GzeeJijab9qjiYWpagkUxMEMpLp34CFS2UZRt2WXiEj6bYM3kKaSB/RWbvuO2EJLZbU3yakH2SM8jI
C8Ms+Kj+0Scmnmy8sO8/7Q1deb81nJ0rKLbpznnKGvCHMmZTk5VKnmy6wto1qpBvHcYyhN6BXlJtJrT1daAcLjXOG0/7QphAwF0J
cGKTWK+yoQtromnobfQTWHN6tXMKDWIvOepNBGjbub+fnaR8VWea394tKNTGi9dLbWF/MbjGkkzbV7TC/WD79kFla1EJ5to7M0q0
42KlhPbdCsmz1pclW7ejrH2hLzK0rbUKpUnAwt95VltAtKMNLMm+lNCbqKN/VCXEGqVCoOfyPJgTNzhu9xvrJidy7NOh51FW2lrw
K9/D7xppnKiVFa6uDpbwICEigFwEKmir+Eaqyx1j2l/63QfJrpVgaJkdW/tzIprKKQY5Q1ilvuvjWBEBci4pKsLYNIo4u25aKlq3
k35kDrhbqlG54NAdSR/vE3Q4u6EdmrDYGAGZax/xFNt1NQlKBQROf2ktUyZQlbEyvFQUnDvjKiJxbapVSUpWF3Do+MOydbSOe2fd
Oa/nqxzLRuMI3p1Yt9NNfQuubzSGm95JhCd5zlazQCLIub3eaEpFSY0zus5sgrXic9QaHfEvPoKiHk0XaVaosY/fNJJ/7dv/ACwF
m49LcYMquqmSalFfFMNy7NpLXOcqKWjuhJBrZvhlK12S3aQa9RgoaX5U5ubw74q+4ZWTP4bd1uOTYCTtMOJX6hxZr7vXFTNM/qj+
zZTS6Z3k/K7BCUo2mu+EZIlKJmH0UVZ/Db/fOEOCo37oFg1R1Zyy57Y1eMU35gTgkVhzKDmCUrmD2msNzjoqrS6RR4mCnomNPNvB
CcBvJ6oCdCsJUoBKgQqEyqDruax4D9/lAYHrZ6bSnsSKw+0k1SwEsD8qaR5QsfDn1dgoYda/NDbnRVT0KPeJMJT0UQOoVzW3D+8V
VcnYnzbCB+0FZ7Vb4tq7Bu82YyfMKCUuUW2o+ysfcQQ4mm7riVH/AG7f+WFIO2FNPp5vtDZCpd1YPtJO8RbOAvhSWEOFKjXHVEBy
aOlc3eyPvFtXNGEKGyka6gkbzGnmJyWShJ5tdZXZjGiybKWj/VfwHBP3hc1NOqddXioxeIvRF7xb4iKyc9LL6tLQwVPybh95Ot8o
wod0IdbNFJNQYCZpBZV0k3iKsPIXwjKTjDaluJZKUJSLybMZQmEqvU2JdPy+scIX5a7RTYw9pzdSBMTXN5qWxggbol36hDaF23CT
QUArBcJ5Mm0kdFIwH+t8ZCl1nVYZMyscdb5CHX1YLWXFHiYoBQZrueebmR7wKYdG4WvQsj3BDvVd4Q4rqpF96tiYtrPm3XI2qi7V
SMTG5AwHnli2S30YYSNjYGYLpcoWVRrNJUBsIgLWx2WjFG0WU741b1HbFkQr4T8oASQlIFpxw4ITvi3LlDMu0NGyhZ9n77Y9cjui
qVNq7aRZ8lcUfcFr5RQ3Hcc/IzbgHRUbQ8Y//ISLL6kqsqOHAiP4CbLC8dE/eO+FsOpo4jG+sWkqIiy6nTNnEKx74Zl5JSg4p226
gilKCKxXYIFMYfUlYwrTbiIs+04oI74y5PIOqwz5K31G5H3hKQL8TmK1GgEFw9g3Zm17lCFI3inoUJ3JEPH3zCwka6j3RaUak+bb
cuR84oKJSIso9WPH0CG0gkk7IoNl2aojCCh68jm9cXZyneKR/Z4XZZraUAOdx3xQYRcSOEMpXyjdq9K8ICVSglthLSboOml5eZSf
apf34wXMkzf/AML/ANFQqVnWS06NhzOMf1E1HEf6OZh9qlV8kqt1+yKvy7iE9KzUd8XRazV2RbBBjQoBO0xL1TzCXe4Q3JTaCiZn
J0rcHUL/AK59Ag3DnZrCe07syVbwDDidyj6Fw+8fODj44I++bRNnU2nf6BMvKsqddVglMUmiHJx4WVEYNjcIUrec1mBTAwNYeYOM
f2hLgusH1qdrZ+0VBi4wlQ2GBYvv3RbbWUK3pMMLdNVqVYN0PW2k6dpBW0sYil9O3M0/0FVggQ62OfSqfiF4hLrDqkWhsMfx0i04
f6iOTX3iFTWT31rSOc08Lx2iNIqTWtrHSta6e8RWFC0UkHERbbOlV7t57oBYIZewv1Yl358MjQoITo9pO3NdzzhmCUipMBO3aYWn
cTDJ9wQ98XnjjmX8R8wJSKkxbcvc+WYstHV9o7/OuSTGkmjZHRhBcDiGa6wbArTqizkMIsnnr9v80VrtzKB3Rfsi/wAymd2fkFol
SkWltLuQeG6Eut6rmNmKOAoVuMAtuJVdfTZGrjDrW4hUUVgbjD0ucW1lHcczSXHUpcCbJtdUXQ7LOJVYtW0kbjHJqCh1QAeYu4x5
IhVkI5RB3o3dh+kLyvIt0Sf7w2n2T0h1QpQwiqSQeqA3NoanG+jMJqexWMK8gfcye+Ba0bpttntgJyixYB5rqL0K7YLh7BuzaZY1
jh1ZnadIwzwhzs+XnjMv4jnsoH7RderarMWWj8SvN1E3b9kWDMa+6EIauTtgE1zB5l1bax7STQwETjKZgdNOqr7QAJkNLPsO6pgr
34RaGIim7PWFHZhmL808hpA2qjyZgFuUGw4ucerqi1W+LSkJKhcITMyiw2s7Nhj+Mato6SMRBHlSE2k4LNmKjCJumCyHO8ZtWAtp
a0iErdSKi6o2xpGjQ7RsMXaqxigwiaTrPypvHSTtHd4iA6ghbah2KBgMzcqnX9TMI1V/CTv44xpMmTSX0/03dVXfhGjnJZ1hXvjG
EO7jfDjLTlpCrxTCubSLGonxzWUnXV4Zmu35wrgPQJPVDo98/PNdcjaqLCBQZiy0eKs1EIKuEXgI4mOUe7owRX3zWLKHmqe5dF8a
NV4+UUi/NdF8VlphxvqBu7oHlEuw+N4qgwFLlplreLliP79Y+NCh9I1Mpy9/XFBlJr8oJjkfK3z7qbPzizJsiXHSUq2r7RpZl5bq
96zXzKbYsqFoRekIJ7IrJZQea4G6PKJtWmXSzaFMI1m1d2bE2TcoRrNpVX2k6scm52L+8BVFJpgsfeEomiE2tUr2GHJEHUHKM/Cd
nYfmIU06CW1Y02dYjyeceSl0YLNyXBvjRPNodbPsrFQYTOyjVJdRvTsQYROIAC26MzFNvQX/APXuh1uSYU6bOlsIxptgS77TkupP
suJpBdtApG6C4rE5mu35wrgPQNK9wQ8Peg2zqp2b4spFAMxZZN+1UUEVmnBa/p/eLKCEJ2BMUUq0Nyoqnu80ZuqKj0dPNqY5xiq1
FROAi6kWiiyreIqjXTGiUeHHNcY1kDim6EzEi/rJ9lWEE00b6PWNHZ+0Bu0EqF6FHDgeoxblrcqutFoQbgdxThDkvNS6ZltYoS1c
f0n7wuSnG3Ey7qC24FpsmwdvEQh0qo7KuWXCNqTt+RjRT7DM41ueTXxj+Cdcyc8fZVrIguutB5gfjNXjt3ZmeEOdny9A11CkKO8A
wtPVmLLJv2qzaRy4n5RySkjqGe/DPQ+bSK+mHm2cVbYqKU4Rp0AVx1dse+nHr64v250zcouw+j/y6jGoC28ka7Z2Rf6ymO/Mpi63
i2rcYE8E/wATJ8hMJ3o2HshEvODV5oc3ccyDaBRYCbJiZYl7mwbSR0aitIaT7gh4+96BSeiqGl7xSE9d0Fpk8VZhXmpvMaIcTmui
/N7sVio82uao9BXNTzSYrm6s1g7IEwzcNsBaOarZuiisfnnTPSSrLqcfegOt6j6Oe3u/aDKrm0NOpuUldwrxioopJ2w68LVl9Nh5
s3pUIfkncW1UCuknYYRJTCrSFXNq3HdBTuVE6R/VKfpAG6FK3mvoHW94rAX0VRdnt9MwfMu7opFkxZgjMc9M1R6Gvn2c6ldkFK+B
gtk3jbAt61OlF+rFQa5kzsmstq6vlFU1cccPNArUxRh55gjFKTd+mAicl23x0m9RXdDWUJRZS+2dC42sUJTsPYY3dcOFfrGxyg4b
YCz7bls/OHF7kn0LZ36sOI3p8xtCbjdAPtYGKHzKGKiArOc49ORCRFc92ZUJeGw2Tm1TSK3jhGsLUFFsX7DcYW29c8lFWz/rqizP
SbLyxiVJv74KpCadlldFeun7wToPKWq1tMG14Y5nVs/itKaWOO2CropgjpED0NRjCXB7QrDje43ZkI3mCno3Z9/mWVYb4pAiv8mY
EdQzX56JvMONqVzvnDiSUgt4gmLjnpsiTctUo4O6AtEBxOBzDK0sjkHzR0D2V7+2KQpzpGG2t2t6KxtQaQh4bdU5hXcYX5t2ahzA
wP5EZzHXCS+y43bvTbTSua6McyQIorBQuio8YofGL7oxhK9ghMq1pS6G6qJTdCpmWmXWwLqJVceyKTLKHRvGqYdkpyYS0l1Nkh00
8Ycl9Kh4NqoHGzUK64Qi2TQbBCnBhsi4RqsuH8voLJwXdC0jHnDM3TfSEuJwwPVF3nXRZVFPQ09JQCsCcnALYwSfY/eGVuTKZeTa
JIecoLXw/eCpxwzrg4rH2hoyEpoUoTQmyE2u6NVlZ7Iull90VS3Z7RA0qkXdcUVNjxjXmSeCY1luHwjWPe5FptltY74W5LOBi3cb
Ktka054mNaZUeyNZxfyjWUO1yPwvnGqlPY3AbbacJN2FIoDrruHoAoYiEuj2hWFp2YiAeiKwqmBxHob4uBPCNVlfdHqqcTBWpSEg
X+juSo9kXMr7o9XTiY9gdsazqIqXz2JjTAW17CvZBZefQEHFINItOrbWd6lWo1QjsRGqlfYmkXMrPbF0uO1UXNtiOckcEx69XZF8
wv8AVHtK8YoRQwlpCG6COckcEx69XZGs84fzQJiUkluNKwWVAA98XsMI+J0QVLmJRPUFE/SKQZlf5fvBX7OCeHoVMHZrCEuAi0nr
2Q4XVhJOfUZWeyLpdXbF9hPbGtMJHCNaYWeAjXWr8yqReWe1VY1bP5URqocPhGrL96o1W2x4xRR11UBiiW1nsj1C45gHFUXrbEaz
47ExrOr7o1lntXF6mu1VYu0fYmsaqVdiI1WVnti6XHaqLkNiOeBwTHr1dkXvOH80HQS773wIKo1MkzXa3SEJn5dTBWKpCiIbmEeT
oQ4kKFty+h7I5WflU8AoxymVv0s/vHKZQmVfCEiNZU0vi5+0aTIyVpfRfo1LrpO/Aw1KWSla3A3Q7L6QA3ISyabmhCl2EoSkVuEP
TK8XVlfefMZkWec6qldw2mGpVhNlttNlIzzsucEvGnDGAlq5J1ez0AQgaxwi+wniqNZ9I4CNZ1w9lI11fqXH4H+aNQfpRGqys8TS
NVhI4mLrCfyx69Q4XRrOrPFWdTkmuXok0VbcoR2Ry0/LI+EKVCnprKy7KE2lWGqfWElVbFqvZFyXD2RqsK7VRqsI7TFwbH5Y9fTg
BF8w4fzQFMy008DtShSo1ckzP5kU+cLlZlvRuo5ya4ZnJoTaWG0rsXotVjlcquq+FsCGZGTdddWpFpVum03QjTy7ji7ItVdOMXZL
ZPxVMPyd9gG02d6ThmYUec8S6e3DwGZMi37NhgcT/vCW081IoM+s6gcVZ3nUpFhp1Tl3uinzzTrgNFKRox+a7zV5YfTrvarVdidp
7fpmmm2DXyZ3RKPXTNpqXPNJV3XRXaE17vQ6Nw8qnxihmF2DzThATaccJ2XmOSyXNq/+Ix/y4o+NaR9Y5RyUa4rJ+Qjl8qNj4Gq/
WOWn5lfwgJjWZed+N0/SNXJUufiFr5wrKmSmqMi91lPs+8OrPMTAUoIbaoabSTd8jmmaGinqMjt/asJaZbUtajRKUipMJcn53QLP
4SE2qdscrOTa+FkfSNZl5z4nTF2S2T8VVfOOTyZKJ4NCJeRYQlIZbtUSKXq/2iVlMNG0lJ47YJVgImZs/iuKX45pNJFFLTpT+a/7
Zt7bb3g3+4zjKLSeVlud1o290JaRzlmyIZlkc1tAQOyCTgIM4q8Ba5j7fMZpt5CylZTYSRjU3Ryk0+v4nCYl5bEuuJR3mABExNKw
abK+4RP5QXjc3XxP0zSkmD6xy2eAH7+YzIoqAq9auinbCGWk2UIFlIGwQ9NV5XmND3jGUGFGpVZcv7Qc0lOAc1ZbPbf9IW0d5HfF
Ds9AFoNFDAxZVcdo6JgUUpDqDaStPzEaCYITOtjWT0x0h585NbQ2QnibhnMyRrTDhV2C4fXNKZPSeaC8r5D6w1MKRanHEArWr2a+
yMxRMZQlm1DEKcAMX5VYPw1V8o1Zh1z4GjHJys2vsA+sNvFshDrwVZOxCf8AbNOvA0UW7CeKrszMsjnOrCB2mEtIGqkWRExNqwab
K+4RO5QcvKU2K9ajU/LOptaQpKhQg7YayeoEttL06SdqBeM06+DraOynibvrE7PU6LSfmfpmRJia8nSHLajZtVjlcqPH4UAQicS8
686jm6RQoDvujniHWkrFuYIbSN998MKVcp8l0/T5RtgMjBhoJ7Tf9vM8ucR/ETWtf7KNn3jZDTcswjyVlNxLqRaUcTCpmZ0CWlNF
BsuVPVHPMTdby1ZdHYYcRvFYdHXX0Lei9o0I6oaFNeuPVE1lNaebyKPmfpmmZ1X4TZVH99S38DaY18qzXYunyhl2becdU6pSwXDU
gZpbJ6Te6vSK4D9zmCECqiaCJeTTg02EZtFzm9OG/wAiMfkc05MoVZWEWUHrNwgS8o3pX1VNKxrNMN/E79o5SblEfqP0hx+ZysgI
bSVGy1u7YmJ0i5luyOKv2GaVkQfWL0h4D/fMytXNYBdP08THPhbbar31hr6n5Q26oa8wsu9mA+Uc0xM5GoLaGkrR1nFQ7iIwECe0
Y8pSjRhXuk1+kYxLSlq95212J/cxKDBTtXj2m7wjnGOarui+7jGvNS6fidSIqh5ubfPMaaXXvOyNPMuFx1WqkbE9QEMyycGW0t9w
gCJyarct1RHDZFwJ4RUMOkfAYQ0sfw7fKPH3d3bG7q816WVg62pvvEICrr7JhC+kn0KnuiKDjC+inVESssRRdm2v4jfmZye1UqmF
1UB0U/vSORydNL4NGEtmQcZScXHbgmGZVvmNICB2ZnwDqsAMjsx8c0okjUbOlV+X96RzhE1N2hyTZV27Imcou4Mos195X+xjbEpJ
o/FWXCOpP+8TmUSmtkBlPbefkIqG42RNVVe7RkduPhWA+LlTDpX2C4fWOcYLFbpdtLfbifnmnZ0jnKSyn5n6ZpHJ7d5CS5TrUaD5
QxKJwZbS33CBDmWWTr6cuJ4Vw7oam2PVvJC052ZBu8ttpbA95V/1EIl0c1pIbHYKQKxMv+Uu2FuKKU2zQCt0ayieJjDNJNkaoc0i
uCb4rFRGpLMJ4NiLqDgILCXTppvkxfgn2j9ISHE0mJjlHercnMuTyVM6JtnUWQkG0vbj3R/zV7sA+0IWvKs0QFAkW8YtJwN4gHdE
60PZeKhwN8NujYfn6HSnnUt9pwiVYVei1pHOAvjniMYrZMczxi5IjZCpdhSXp3o+y18X2hT7hJUtRJVvOadn1DGjCT4n6ZkywOtM
u0/Km/50htwjWmFl3swHyzLZrqy6EtfU/OCxJTrzLZNopbNL4m56emJlxNA03pVEg7Tj2ZpGQTje8R4D6xLSY/BaSg8duaYnVZWs
h5wrpoakV7Y5TKcwr4WwIRJSiSG031Vio7zFBFQbTLb3ZZbH7RWJ6ZrQpaKU8TcPnmeyQ4q9HKs8PaH1zAR5Ub0aZb/YnD6RWJ2a
rehk04m4fPzZmbm5phmy1YTpVhN5P7RfleT7F1i/KrR+FCj9I/vy1fCyqLlzSuDP7wjKM408qSZpo2RSpAwr23xVOT5s8VJELTLZ
NWh0pIQtbtbJ30pFSak7c6GUplKISEglqpu7YudlxwZEKnJtQU6oAEhNI6wj5egba3m+G5cbdYxNZTUL1nQI4Yn6ZlvPOJbbQLSl
qwEX5UQr/wBtClfSNUzbvwtU+ZjksmzK/icCYUzIyqZMqu0tu0rs3QJzK9tlg6wb9tz7CGNDOIlJZluwhltmtN+2OVyhNr+FKUwi
UlG7DSO8neczUi2fUICPzKvP0hqVRzWUBsdgzaZyUlluHFamgSY1G0J+FIEXmFzMy8lppGK1R/aLbfJoKQ2he5O+BOypuPPQcUK3
HNzT3RzTFXn2WxvW4BC5DJKiljBb+Bc4bhE1Nz822wdHo27W2pv+Uf8AMCr4GVGEyUgp01cCllaLNwzMzzPPaVWm/qjUySyPidJh
SG5OUbtAi0LRI8YU/JlAcUixVSbV0f34J+FpI+kFicn3XWjig0p5uEXNr7o9Q5+mP7uuPUnvjmJ/VF+jH5ovcbi99PdF7/8A4xe+
vui95feIvdP6xF7g/wD6RokPICfirFPPW+dmqIWU332UxKyO1tGv8RvOZEok600u/wCFP708x2bcQFIlm6iorrG4fXzLkmFyWSVh
b2C5gXhHw7z1wVqUVKN5J2x5Dlh+wWxyUwraOiqL8ppV8Daj9IucmnPhZ+5jk5KcXxKUxyeSD+d/7CAuYIS0nmMo5qf368ynJCZU
ypQoabYvytMflNI5TKc2ri8qNd5xXFROe5Kj2Rcy5+mP7uuPVU4mPwx+aL3WxF7/AHJjWfX3RrPK/UI1nR2uRzm/1ExzW/0kxc0O
xuNVlX6RFzC++LmD+qLmE98XNtxo2w3+nCNZXExSWXZQNu+P7w53xe+5+qL3F98Yn0lcF2fExLhYq0zyy+z96RU5lspNUSyQyOO3
x8xxhGT9O44u2pZcs8BhHJZOlEfFaVGouWb+FkfWL8qOj4AE/IQUv5Sm3AcQXT5uq0s/li6XXHqwOKovU2O2L3k9gjWfV+mNd5X6
gI1nB2uR+Ge8xqtp7G41WVfpAjVYV3xcwO1UXNtiMUD8seu7gI/vDnfF7zn6ovUe/wBFYQOJ3RZT2qO2NE0eT2npfyDbeytTwhtg
fEYfn1DWmF2E/Cn9/lFAKwrTzban0i5hGsqvXTCFuuGq1m0o9ea6NVlw/lj+7q7Y5qRxVGs62I1nz2JjXeV3gRrODtcjBs9hMajX
c3GowvwEasv3qi5tsRzkDgmPXq7Ivfc/VF6lHt/lrrkbVRROqkYkxo2rm/8AN/IuPn4RClJ9pVE/SGJCUUZ1xhsIo1za7aq+0Fsv
+Tsn8JjV7ziY1GVcTdHKugfDfHKrCj7xr4RZZZVTq1Y1ZfvVHqm6RaQb9qdoi1LvrSehW4wUuKcqMQT/AIAFv6qejtMVVRCBFOa3
sT/JaIc8iz2mPV2BvXdFqZe/+ojkUBR90fWOTbSnjfHKPKPV5oW2opUNogIeohfgY1xrbFDGKqFpHSH87ZbTWLS9dfyinOX0YtuK
r9P5JJdUEoTrGscmC4e6NSjY6oqtRUev0VhzlEeIi02oKG0RaY1FbtkWXUFP8zZSCTuEWpg090R7LaBFiX1R0tv+BW0KKTvEWZkf
nTHsuIPbFWFWDuOEcoggb9n8rZbSVHqir6rPupjUSEjaYss8orfsi04uv+C2mllJikwj8yY5NaVxWzYO9McmpK/Axyjak8R6eiQS
eqL0hA96KuEuHuEey2nuijCbZ3nCOUXXq2f4TUGh6ooohwe9HKBTZ741FpWOqL2QD7t0cm6ocb41VoV4R6kngYvZcH5YvBz4Rc2s
9kXMK7YvsJ4mOUe/SI5lr4jHstjujVJWfdjkwGx3mLS1FR6/8P1Xldt8a7aFeEa7a0+MespxEXTCO+PWoP5o5yIxRHrEd8Xvo/VH
ra8BGqhavCNRlI4msets/DdFVEnj/wCrX//EACsQAQACAQIEBgIDAQEBAAAAAAEAESExQVFhcYEQkaGxwfAg0TDh8UBQcP/aAAgB
AQABPyH/AOIXRb2ecKautfx5K0EDgEUyMlPZad3lEfaPhUGXgZ6wLA1PODflSIpmv/QoHRfDWg4DROTKnBIoZ1auWOsHHnMa6yz5
XEYtQKTt/BmCMtdDyLHeBsK4y2McWiICAdsbQKdLqUXUvcqgUMqAmhSyHLAPDVp7sad+6I+WK/8AQWTCA+U7OUEwtdlaZvkzVuTS
umh71OBGSo6HR7Tk5gLht9cvZrOK9PmZrjeay2nFO3C/Q5sDwSbQNCaAyL4N+riF9bw4q2IGg9IG+AvCpCaYg8NWVUkXHJEpuOc9
p/NRz66weReVXqQy+KmEaBHg+HMnCr1rSGXfRv3rjDFnmnQ+Q6/+RtFyegd0Gm6xKtz79NYgxkR+hnA7svRrU9ZqwH9nw71NytOV
zuQPOWHPpo/RvDpEplBobC7Nd4s2SupgcjLPPe8KjNjmJBsN3iHcXoxdceuCj2mNSep2k8qCvuigH8rUpXNTGO+LTp97QnVZS9P9
xrxZStyND0zEsYzRehju+U3hyA/8c8w6BbKbvJ8209QILvBqq4o+nObFtZZ8zZ69ZkDvjmfZFzI0fucvIYCWlk3UGFCpYDmTaOM2
wLC1Wq+cLIA15q99WpAoywT0F5l35K2QSinhcIQw/N0+suVxTZqt1Lw+cSLtuRzJz/Q6deEVeG32DHrA2+yp5fdF05aAB7EIc0W3
93sjct0f83SLw6GN7JeIkJfPyjHl3iKAiajt/wCIGI8KvS2lHXG6vUxFwW5p1ZZ5Pl+bOJZpL8HOZ0dKi+thji1PSJbvwC3cyPHw
/N9eyXP8QjPov4hPRsHkDkmD97QemBrTxlqGjZd3jCGqcIhO3HeKNfWuc3QuFQuhh0MEauwW0eTFdbjDosMflNSQKfqbmr0veNcp
vAH1x8QKA0TWUvozzQmq+j/tNGmzEJcdD8nU/wDBvAW7t1MLOmGOgmsU0MwsV5vl6viMxC0ZTJ1bvltF6e1rgh8yrXYD80ZvmwWg
bEpGWPaIr6HfqZ6wVI3YdyX5DDe2NNK6Vs3BJWaPKMENjvLg4Ien9xmpkdoEFIF5puc+ZAm/5E4QcGkL7RuAbqzGiuew6ev4UUaQ
WreEQAgwjt4CiI5NyVt3kv7ldO9xOpOOJ19qjY52f+5Ys8/0fuB/oC2WlekvQ6cZqE2S18a2/ATH7oWLmqtyID5usxSzpd+cYAcU
kYw0tnARGCWr5hg7HeUAJvd9ZbBdfmU4uZMCW/TefA5kzpns/wDZnWItVxlNFK1+m8EYEbA583nAAEL5/FGt6MUEt00H+gur5RmJ
xFfsnAiCgi3zFyvPQfgCqCrgDeCoPVj2C8ul778YOC1P2k2lYUNjld/AaE7kY2DPpqZmuA9CWfJcJ6PB/wCxrmam9Tyin63oijb5
36bfgHUfAX24zpRNZu3etH0ecHqHUBJWISgsu5ad+ejBxPUZTjqLr41hU0NTl+owbX6JKmDOm8Rvr4GJQCzl55heSaA+cxueY50I
IGij9Od2EdA6GhG1T/EPy5c0A6bgyrBPF1j0N9vHO67u3VDO8XxwmVPn6lyZSttxoLXncOi+RLbdePgkvH8i7McHSUnhdLRGr9pD
g66glQXcNX+nP/qr1TXYc39Rv0jq+UwHDS0/BRqTczTqfJxjOHi1zrzeLDqAeCAo8HIos4uMaOsY1Wv8p3jhrYPot7y8ofstRQzM
pU8oKrCxaxK24GpKvHHEKANsRQKwfgcOJlJ3NgocUe3nKAAADAG0v/5h6Dme+TePsKomdTqpkzkraUY0t3DIeiR9dNupBV27x9Ia
GXr40jofTBzPusMZBF0uPjezyQnlzHEOX4Ynas76nBhIuJ/STrjj6jl7f9FvWX93xNcZgtXLMS0DQcDwZY5GmeczDAwanN4XGoLg
by7aPKBbgXlFBw3+Ec4quXVepLIt6o65B0d3aJD3LOzXvcfIR/U+KYVVVwg8YI+kEKDVuT0XIUt9hL9aI7GGIQL+7i/2OHhB5PO3
5s9fA3DnGb+MXTXKDN0gE2Hbd4AAADQPwLiBTtOv6mMfK2E9r79Zo182A/WmV69bSvwt1braD9zeqIdR4Mus+4936/5q3Lc279RC
MGAargTKEcA0HA8Gjgr4ZSU7ycPC5wb69pFmPUDk3LtKng0HQMB7RUgYf8BomjFYfr9HG5zaMfaAtBXKKWjMvoppUuq037QQpxoX
3jFbt2iuWLina7y9eYEIJxEP0h5nGzMmnV3QXf0N5pMGrxrX1uaU0HEO4ovqLXR8UZgyrtLh3d3vTh4aTUvrGvyjfzmgjjYAfcdp
Xp9tK8D9GCtToEuDcbw9AHswp3KnwOTosGPujfiMesVs+Li/5LNvLD26sX0YYEaq8DhH7gnHYDWVe8DV1OM2seRt/fjVvCPBegVG
8tlv+3zidTWZpKcy3E4BqdD5Kzi8CKXYjFNOiZsausb++WEQusS6oGA16TiRjXGNQ4w02pBZDmO/hDgiuo/WNEMXQgOsz3EDDgB3
5Qo6VnpFKKHez19nSHo4MAWzhJXxx9dmb0F2pi/NjfolZcWg+eP4IjrHtKVsFOf0u06JMIPpnbpKG8vyMxj/AJi+fpLDFXrFLHSo
0706ucaaOYq93Vjwtm+T5xQe9QDpymRSs8Bx/wCKyEaCZ9XX1CbjnI+1E1aDMwr7BwmjmD8vSJ0Vau/gszcp9k9jzlgUylQb/o02
mF0jWUdYy8oWQqCF7GLkRU5OhiJJAq6g/tnXcTCNYbvNGtK6wTrtG4PtHbA/uXlg9yrS3etILFBcGru85ccIkFaHKMmO41Gnt6w2
S+yjD1zS7EBVy3HLiRtbQfzz3O8dkEmm4d4E4ccheTXRgU8P2sBmN2e108QPyBeBycpWIDXHyy31hQM3o93KCMdzTclLp1jC6J/d
YJGppEfc3IAG0BWrHop0dZzzYzNjBw1oAHOj4HAaJyYx8itKIX93mMJ9E5xACBpHb/h2ZOD5neaIi1PO8KzGaWGRwaG64EYHgGw4
ePuOBMPQRDIbGvXVoB0zDoW9TedQ9oNCYYSXbTekUapBsGkjVd9iX4UITq1sOHOGtzEycNuHKbqQzV5C5zNrpfXeKVkRlTw/SJM8
UbgcsuHKWxjr6HSO1vdiuiZy33olekxy7RdZ27yvYw0NaEzw9onIj+4nNPusvduweuueqJxgJPBv3PaXd4Q4dWmOMNcZLPGIA6ev
fDXezLQbpsRo2gyU/RbPSAFtkL12PRhMwVrnzxFTsNN/pnFBQX+JqwiKBdpwf2iFzwkqizQdV0uG5AHtQg47zluNk3sM1Ut5m+aK
oKCA1bKMwcDpPz3lflNBts7v+ClXs/DvNftmvaamTpwNiXHeryOEQP2IEtW8Lg8+v4GBxfO3zDT2eymAxjQipd8F4ZoSOCjwDweD
MQWtnhPCYw1oeGMx/wArbzAPiMDDTxzN+ZDBLU9SYTFY2jYgHhxRvNNG74Qpw7Op5NejKBNp0aMEElqoKi7g19Iw1T0Tk0qUevJ6
ofLqyR2urKllFdaL8f7BDhnfSIOVi4sTmDZCbr4UdA+TMSq3FBPRdZW7xW5h92Y70gHkcmx3mdmnJw8IEPKvtHc689Y9SKW6Vo/c
FsHW3BgHQVylxhBlryVrFesjB4ufDygqgTjpAay50LoW9OR2gyhuxio0qhVWXR/rnL6bocltjhimmF+2QUYbLuM1xXh4Nn+fRV2z
gdp7sQ7DtLIzoN4NsX3LEt0fHPx/BsQ6PP3mU4r9JCCkt3qPiDYSnFZTXTwdJZhfmnxSOm2zyLRCLesrD5lQtVpZpBwpdLVRClKt
y64I4jEvAavUO8C/pzSXoeUoTsdC00x4aMI5T3f4iLJCWCnIvFM2+Ai5RcQmabjmkg4Mv8MpBXCShv0dZWYIVyOpVfiXqWvVmmde
Eca7bBqArcp0om8V2gXNjjT1GZ3DJdtdwt0lPIaerGUx4EKdyy/MgOab8ro1FzaSzG861FDZHRJOMRSpaxGzAp3BXWsyrH6Ru17O
Nsp7OechseUqIDQ9h8yqZu50qbIpuUfA+xdTNV1lbL88q9R5TVpgPm7aO9X2jomUdTh3OzH2wmfW3Hy/lvt3ceB5zPzXBxdiXSnZ
xYdfW8vx5zTj6e/h08TiMADeUdG2bf3iha2fLMG6tX3T2qU8DFZDRTWqdZRZkLD0eNOdmTZaTAGQdWA3nwVn0Bv05zBD7U5jSj0g
vX6P3BJe4caO0bPypt6O3Af3KyZZRsq6/Fv19IBVkpAegNfOaCKtoO0HXqs0o7drg2QVW5bmGkS9F1OhFPAq3PjRuuBWjBK3gvOf
NFO3a6Y/XD2gVKLihIe4ZgSlFlZA1rrVV3gtqtU29BzUYgrBwFpz+4czEODa5g1YwcMxiAyLBaNgBj7uB7QQBFls9CpbeT1/eiB0
aVDnjg7kKcZRF7HZg3Uj1WcFunk4w1g8htr3gd5Lwmc6MjwlsYflvY5zjJabbBxmnIbfFafy1oryTY8veXdx5h09PeeykEGVqV+u
/iStnpzm/F/geAKtEqGVs6TUWXbCzjfGXgmcvRmgvWUeKKxrmJmvDLUx2lqnqB68I6uush7jmJNQZX88LipWLp4GoVXnVfQ4QEQ5
CU8bdIYxFqBsEhbF/B/O/ggFP6i/UkC04J9NFeaOZLYdjaKo08OSq879Z0gVzwO0HS13j7Qp7PmoznbXf/aiWWm+VgjZUbHKVqrq
LUgXNjBhpyQYF1VWIpOLQgOXMZMbKx4XUc7g/ebzA3qbA9FOm2Y4c+FW9TBzW2b8fPjM9d3m4qVQoaarwH4cOMvVP7Mh4JbpvHCl
n2Dgcpap8DcmuN9x/fv/ACP9IFzU0B0JqfRR8IPlO718aw0dTQnd2NfE+rTy/vFylbVrLx7eedMHH6+N6zDJ9ZW1Z7TTRF2H5l7Z
uA81sfhU+Ibo7V6xX5Gvdu+U1+sWJcWXUvJOLjCo3eb1QuRfXerm9ZUzVrjpEWrpGoY9PYDvA4qga11vr3gAEGANpvPyG1vhHF5A
26Du2r1jX0MmtbfeUOgOxBn6tIYKgNX5IF+CZpktzcsGhwTpZGEPhwgZOEqrZHWmOzFrRVUvrNHwgTOTBQLcbp6dO5NFPAgOSSq4
h9jd+R/XhlNSaXVZuutS8nxbVxfDnJRxN/SaKL9RJqfxfx2hafvfiX40D0Zfj8Fi/wAx0fuBR0weI1Z+n1iqqqru+I1BARqOHGr6
w0uPrkHpFerGO17Bjvl1BBz0BEa9WDzYaS6MHCBBEQ3k+fCaZbaR3QEFTr7VCEnsN/FgFhh2TQrnlFKtQy1Z53N+uhEPMsKZftCg
KC8Vtt3aU7+wU96SyDPmrfyy946S8OUfn8kE1eOcqAEz1LC+ft4FhGhWXwZxPDrqa35KxKdkpYrJqduGpKmYzcDhbqSopbK1+Zgy
+adVfXMM4tOzfZdVHherFvGnK2jitqojgXTLoHoV5u/4WatrdNvvKV2x2B/X8d1lLunMptwh11fF8C1Jv1/UCigo8dwuh7cj9/ji
SHuNp6Iu8ucYZNrcdz5wXfUQPmZ4JIeQynujdrZzkD3iImmOzqd/iGPA9r3AoesqXOjRDPNxAByUjHRyIsCxsnEyL7wVM6xYqUgZ
V2JTEjCimL8veL/CZRw4jk15yyxNaCyKLpdfSRS2vYmAvKAcZclvVJXWrpuC5eJXzo/R0gZtXpHNU3fpzlQTRk46B8yxQbB6PHE2
jQRG1qdSkVHOjNDxjNQwcnGPE9fUVyI5PJOoDji16s43vpOXVGNaa2fZGAjwbcqtcS4PA3UoizzZ08b1bXupep9gZPmYMv07X0v+
LliD03mC5y6E1Uw+8YvphKWvZNv7+O06Exeg5fkvJR+Xr2ae0IfY0VoeWljpHha6F1yNHqLGmwL0BguI768FzAX2Zdn7fEIBpa1a
JLmRmY8i01Kt8Ut80qgp5Q8XrqtYdSuF6dLmPVBHcPVv1mI7STQ+WfJHIW/XBHuj1qEOStYKNaN8vODfxFlPnvQomtcNxAjJerRK
1Z9e7HvQcjV8V/aILmqEch9HzSkSt/GCWYesuZcGrDSo9HCiektHqRwW/YzboReV+6+AGHHN4gpEOMKoT1bIMLu5bRXNX3eOrq6v
BxmNIt6jM0Xwe0EjNjsxHt3+FdLRO5x+5g+we/8AV+GeAl+vTxRmDKu0uVdx3/r+NWykJqr3/SOEI2rNODtswPF16WOIzBWmzBzA
93omgwyjXgN/AbigAWXw3fK4xdpUVhCitp2CC8oL4wqw3pcFeebcY6y6mgOCm/WVcCPlLXYM12BRiDgEVzC+gvSDxMAwAaED/hF4
J1thTXhA9SkeCrnvW+UcjHOgcbaGWXuFwdCUZZ4QtVz4zLprpqnDn0jWzUCr1mtvBePmPc8CaRfnNKjTl4D3XOA8d7fAWIwGPDDF
UELwRpwaU9ZXsOZHTywH0gleFOrpXzMnaArQW8CFYd7l5eFf6YempM83X209KmMGA7jD/DS/ZPYv5lJ3VexXzOXbfiFHXLMtS04u
b+Lp9MExL2Bs8D9x+r9Dl4sTAbBqS4U+RYZtznA6ysWfRbCBFbihnaejCd0oR1tvtwmholgNOg161FgRsPDMMBZWJlNelRBod/Dr
pjbQ9lDher105TR1AEujhcvnVANFeBFYM8gvpDWUiSdvzbgrVRmuyiaOK66PPxegrAdYv5o3YYJcTYnNy/A/suBZ0x7zaC9SDip5
9eZ7Fh0U80X3g0d2PnZp8kN5u/mXGshFqVaOdjzr5pqRt5/IVF52fb0l63NgBpffxQ3tDqzWXAez8QyTNnon9fw2j/Rr4nJk9VZZ
eN8PnwxcGwa9Es5RoaH45InddOqJzms2vIRvgNOG/FG2jfx3AsHtL1RMtTod43Bg8gRSMCo7u1RqPiS95cHZj4gJaJT2j4/osXcd
pyZ0noxS9doSqGrjtBY9bdGAskws3QYTA3YB8h+XaNDK9/8Ao5Q2AvOGy9mGC+46elyzR8I8qcoDtYtRW6sPlMOD8Ak+pQiaznUI
8+WsyNOiSsHmQGljHFB+7ymCJwJyi7UpZv3B27SsETadG+XeL7FEByXyIhQEnkutqvOCxbbNbVfZ84X97uhqGzAUBt4DatkfMVW1
t4ygXj0C/iYezS7N/wAPUs+Z1CPKJ0wfV/UvmXofdIutuxsdPxumE5PiIAA7T3ZuX/RvP81Ust2yDy4T9THHhZ1qA+ZDDZi1XSLp
AN1oepcsoQdkoldBaERwR0f0tNkq6dq/uWBQOVBpu8U2ubLgdtMwBPN7pp3ApGpidcCeFyvDv9BgzdWlcxaNTHPaMMEp6Ic+ZDHP
olHJHcYOp2mfZmZyHvxr87mWGu6xq6NrryhLVK7auvOPUQcRkACr1qqqWOWXrmqEq70KPaK+CDmPhVadrMOJpwHhz+3rCe0bzEqs
Opj89mcnB6Tmn78zogpdBUTpzlfxrr9s3/rKOA9AIl8iY5+P8BfVlDbf0ms2CQEt2teTDU3GkxQq06H9wCVoMYgZucoLJueiIY9O
5d7uDY0gE6G0YvrCoJgTcFyd6j6L9gGvvF3UkCvZgyukGpl7B8nea5Xd44jonMmkWxxSd32jgRjlVuUpnzlnaKUw3vJYh0UI4hK1
8ZVaxQHUTlCNOkGqHRNtobvaQ44XrUcwXEb1AmpY8dznaN3h28CuE14CadSfVwJyvXr+eROc2Rcw95/LzmT68piuUtcL9PL+DQoQ
7XnyOcfdVhn1msv151jKxBnhxl819dJShaNjWkopCOLQsOAYfMHGtZv57byoSucNCPRiaqBgRjQsbYuDhThGXhlamtKX2IYVk7IL
dAKqEQ3labD6b+lzKVg4eJtPig/yBXeFYwaxdKlpyu/sO8080jRv2M6bR5StNC45fWKO6bAkjcu/UQJfGWSuDe3WAlSWlmV6eXhq
3Z5ecytusTIqgIIaXnjM5IL1n0cxKf1eZf5+he8PdPoOP4JRxgJVVbXDp5+HQsH0HL8uMxWC8yt89L5ev6mCC7pzrYvkxbUGXLer
J7cJeRxGEB6LRKt3sxcCxgvDeLTujrBy0TNjokWPdqkZbf56RtGpa+E2hmOdQiW0FVlVuRpdqa4sE9viF8F4jk6ymfu4Jda5OMEe
cVVuBnTSoXpW+Eh+CQ1hlqutxU0rL7Jbmux8GNrr9rKaem6QY9Fi7Vxb8NeMQ1FO0KgGiqSJA/GBeg85nSi6dmo13GXUa1dqJgkN
OA8NsHg7ITUgmsRX2vqw1zRej88U5kWSCh+l+Ja+7u3VN+vU+6eHluHsfjSeceiFCnuoQHS9BV31mXAFVdh0jwYmhSKIGBP9tu9J
wdAfWcPZgKsEwQ6zEnyEEbZ8Tx99Iu0sILwm+xbq+QbvIlsO24W48H+kFW+eUBdkLIAs9X3Nv6llPfAPIxNFzy0uzjL3xaJpKQME
7T73DCyNXNOJcWgNE0/UqUdp1k3n1nMTDR4Mf6FmZOnEgYNkGtXqehh+8TyN7JEutPk7ajbKhxMrNcvatT0ja6sFZ0Oj2l5aaDg4
ZhAXKunR67d5SYcM36GnF4bHrHJx8F9nFPt+H8HMQM5ReC24voQJ7sevhuj0LbkeFkVyXNDrveRNSHka94DhRvEWgbRW9YMBTL3j
wuqgqydhxnMWcSNGVzCUBODDFH/1mJUh39jLPScunDzA36QQsrhNVpzhrKPKaFPGT7URtfnQeaPaBvG9/EPWdj3104do8SXQPeaJ
cp9djHDL+p1Cvf8AuWfhA+yEcoDnox6RDCZxijS6rjHBM4sWFEvZR0XU/cOI4szE44+SLrXya9EVrFabDshSHgPCXg32hgHJDZdk
+V0g6ZHRUo0TZHNypBLDwkuhe5s8qjAf5D2zMXLjVRp2gVJiFZa/Nyneo76vIVQ3p4cYXgMsKAEpuu+UV3J5cvDH6NUf39vz2nOT
2J12vnmP9NFjWBwMADw6URbciAgCroExo6quSF4z1dRZcdck0AnFN+XheaiWVDRaMBd4OcUSfC/OXWpUsdHwtlst8b7yy5TA5TO/
eCKXhi3GpkiqorxZWAMODFDKJXQiziThUw1mHAxxi+Gp2mnS3XtwdH3mQiYcdGK0x0jAEvMfqJLFa1Q6iaZ7QUaO7L4nGBcj1ULr
xtJP1GSDRLi0ZdQLKYoRtB1bK8oQ15ZNDLcpvlCvra603YiHWCFS2i7Rc7NNY9/3Ny+DUcmvshBS6/VnSNPR/B9+aZ9owr4lfFF8
n+/CpwEW3I8F0+bNJ1bTECDU9edxzMHDpMB3JzIIWcTw9GO7RLKY6b7TbS/DrNlUvBkl+L5Tq9Jbj6Q4jANr6wBBjOsemCrcfB2p
cu6xlbywUhGt2eA8DZdP9uF0mCdLtfWY0TRhfOVEgpmgdh6hFxabeNMO5LUJSjvJOsYFBmdvs6MRZqTW3N1Y6QEitD7CvzNzaMVi
wXkse1VKFhQ7C8i6nL72J1znlj+DmC+uZXR1fK/3NWaX0TynL2PChi4VZuwqKDPtDgVKOIQXNlekuNNJt3pn5qTUOfhjR2nOLcKE
AZitswbaAa58KFy97wNp4hfTNo8LLo5hmC5vQcY6RX6HpNRow2H9MqVZZGr4f3GC7Hfg4w8Ey6caDezfmRcze9r4nFf1MAUR2mB4
ggbQA2MvLYtWZXZlnbzQM94r1msx112ny4TLGt65mrKy9v6wNhAeU5n/AKv4OSKez/coIyb2cfqC2JHl43DM+gfWX5OK8vG3JrC6
ud1BYsMq4W36garqRVxGYQ14+ByeD9DMNJXioFsRQ+AauzxdIy+7MUirGm80m08uhzmvr1IFWLgYg2jlKfOC63zySpIcRl7jEdw9
HNG48I8Fy59uWqywFMh5liMdwifoPpMlLe8zwHIa7zGWrUGzxlQQDrewmZqBv5jHN8en8OYqFbvOO6V11PwcKgF9NYemg/shXxKZ
saZXRphrmTEO8cHOGqZv4uOZ+S7y9ylluHiaeG/hrzUN8zKPRmsausWtYJ1o4zAQieRRLAfRIMKXMfQOSPU6jmALnMMKhjF9M2l5
yey5pz/aKotoLvBn1iezD+qHmynWq7zHH9EvNxMI6k01+Ugo6hjs6N5uP3OK/wAz8fwoekbJpGBPBTyTk8MBaMwpQ4wga4dFAvJ4
PhQmZe40hXveauOOyazxfHSRUH8dJt+E14/Hw2OM0HKEg+uWX1UoDHhXKB0S03FWx3RKcpxU4eGrGeMbHlcY6qpVvRNJ5XGoyepP
1YXLw6WJb4HuvjHXFXLy1pOhLDOhXfB/Fmb7I5PmVuwe4aeHCIxG90UfSYLNPGhKSLNdcpcp9ZVo1gFcmzHfNeGGh+Hpr8L8HgL/
ACuk8FUdqIuojNUrEp5XKNekNqlmsUlwMDc0vRrdobbZwhoBOUaZjbEJcbLslChq+aoc3xZYTYso0L0O/nKww1/z5UUYyvM0WOTp
Mj6ER7BOJLUzNbrvFXb0X4ENQPQuelAo4adfzrWw+fUlUrJ3TwY472Jl6HWUtboJhw+LTXE3GZdq7R3HmK5NmPDjLol+GvHR8dl4
0fk2wbM9iUKEtAZWVjBem5n6qPrIYRxg1Zjq2iRVsUR2A98tVmZivGNh8wMfQHPcjOWlxQhQr6L0+RMUhyVFX0jrBfVj4TazLrgA
/tFvZwG660ijOdGmq6an3ZUW3yjGNltZ+fh0nlDQBF/6Mzd/gUGksec0pQiiSm9tmBcN3aE1RK2aMyYvvGtRKGlni3TDLS2UJ+kv
VM5uAu2LhTt+WahVySJ1SrKx5zeDZKcGviKCXt4HWeg4p+kaCe0ERU92T67AWU+0HWUHGUXHOHGNo043OEfsLtKHyL/EdbuhHvOJ
Pup6RvtS/M0/pyaifYTXr1cGoL8rh0WGESkhtg6oq+s07pSa2fYT1IFH28lIDTqmf+6tLiKFF2NgNwyakIPrUTsbxkfTB/CdL8He
W8fVUtUWjAF8IPAr2jdgWaXoKZpa6K95pjqH4jXlxYB6dkBWvoxrLEDvmub8TDdMD5TN9LymK7GwGHXSKzqytaeTmmdwqMz6Mhnd
8X4n1g9YFk9AQyOwifTl5zijq/CaZnQJ68QJ9UPSe2evzNI6ImsH2E9chS7VrTi3tCL6tPfH1iQFDXRmcbzMCywU+8M8iYtfT90/
c5eTPTbz2i0E+SJ4X2G0cKilSmwSU59Q2faElSdBQZiEK3vmPz+Be4n2jBbKKz8oeDpBKStc7T0Y5+2YbU/gueLQurmhvsbS755M
EX00Rq/Q5fEP1znFfbgvSiFevLPYVb3j2e2x6/5HOuevhi3fdw0Wov8ASTlMz6UFALdVFdgQsW5Q7lek+Zvj0CN0HVZ6RNvdmt9k
QLySNJDwh7yocvf9FMfJChyL26+FeLWxOhaycSfQjOKwhf7OqgFBwZVo7ARpnAm8K+9eLFyZA89+nUm8rZXdZXoPBprTX4tv3whH
0MuQUeKlN6UB4Ok06yTDivom09SUVfFfx0ATll9QeXN4bngTCAteadvCtGpnOz9iYesPcv4DDcDRBnl4x4rlFyOGN4XKqgKvaLap
vWeaTSxcZLNicxhUc1G9wlH94tmUX2lwSuxHG9xlSGU3lfUba6aeFbA+sYo+Z4aRV3PPojJscYcAmp/aNcqmr6TyslFV/W21T6fT
mnmc/pzKbUfK5ch5wjixDo+VxqgC1eEZ7ROjh6V4ZtS6q+EbQFfttXz6njm7z0Mr8mfOBZYQ4q0QgK6KCviMnQWrwhB2vy2+zbwv
PN2guQ91j30C3YDbtTVwELQAUReKyLmMy9upbqvhtdRy+rX0/hcAVbZ1fBzSGvP0ICggzFixvpeWXtETgvWVtHqeGrI25Cnq4Wyu
xER9ZU/wPvbYRyHBteISmpSlImiTlndj7Fm3T8O/i4Kzxv8AMM5eGJcS/a083hpcmeb+jzSiL7s0XyT38MMDR52ueow9hPtKedQZ
+394uVLq6F09vX4ZdA8o+/h60Q1HzKHAw5BRG4NRdSEFR2b/AGDn4tyJpwcJGFu2YK+dHU8MfFvlOKX4Krp4QBYG0oganGfQU+Kz
JV3tiAzGj5ZmMymRRr2PWGCi6tlr0CfaS7WkuGT7/gURVgrnZ9/hBtvLHIeiZBd4wefGVzhg3YcDmeACKc57a3osyTtuo/3KVMNf
fP8ACdarJo7ojQqSbj/U0RAOm7/S7+FRNEjuhg7tEtA5I3uM2Lu36qMS0ZZaC3pffw1OQB0z6beDCAgN1wShXRW6GXzvw0dt+wf6
Q0xE6UocmcPO+0bOTCC1lVZR9kf2gd8uGKxJl7gW6xYxKvM/Z5+GsU48mj19HgYy7v2or0EdUJ6fj36vVEZ2qtcva9Uu086IEctb
PkEdnwdaCvlwjz9Ux6fKNyy30v0eUNFlq4v9QRTXzIOXf3TLk64e8N+yHGNj/gjfEtHqy/UQOAXG2JRlQK5BOYaEKhuWeKvQE9Hx
cTjmVP0S097EfJR5zQAGw0Dh4YradPDVSR3CZVl/a950JO4/w2GY7w/r3mFN+ja+tzOG+vXlddvDBYWbdT3eSZez3q+0c+tUCcXN
w0fIUV4Z5+uOXqPl4Zhk3cBZB1XnwGsn9nyqZsNFzOfTzIjoPtKWk6JFHr6Ifm06vY8yaBDijFtK9o301Uxr+CBAbq3/AKqNQfvK
8v3YPs5eGqcw5H7ovjMzog39oeqVQ0Sug+twCS0Xl5QlL670OjREWvlUO3UbO3jgjLOLaHpKGB8IQNF56QV09A0IF8Kj19TGUcHl
4HdnZB+pEV6rcQ9QjfkX+IYPaxA3UR2P9HdNBpXamvSM9VmbwXygZR9zcDg9jNbDofaNIo4QHJUcJdfSS5z5XHK0C+ZX3h7IXsP8
/hAw0n7B7SgdNx66+uDvEYob3oTVg8aidl3h2XL2DsIkdlV8zif9RxTm3G338V5X5TEcBHHIjh0fcafvPebSn8E9a9z0TXXrGpV4
zsRpetOLtDgod/CjNLn6/rgDq8gL9Sx0qXW0qaEbrS60GNJ95H4rGFW2LbrzmCQMuCHwXQmfhF9UR1qtyobKJzlHtK+7yPeu58L5
0XMsDrb3vjOWTrKeoS/tZjl+ASG9sMqr5eqfa06EFiE0b6lrPYDveKTbgapFms5PKNUa3/qRgrAgQxuK1jJyLU5Xw2mWUKwCi3o8
AVlz4MWijBDq+of9fwPtvlt/SFgN6ORp95TQrS8mXzp28HYRRoeLB88bewRa9kLQ+3FcBmSjYMzsBc5bBNhrnt63Fy+spoy0su1d
Mr7Qb6Cc5kj5BbRqm6znCMpT3gb5PJPh/MPBfRIpu4qQui/qUS9M9YGZr0hyOLyJYKbqOlhxbe8y3Wmc98DuTXSGmfopgyfUqMCv
LQvWJz2PhcP9rylE3QKuQgDgDvNDb9LEYf0uKGgzxfTwyyhuaDuuSWR6/cbYiWOlLAqy9Us/Yn1BxfQmmT0V6I0Cps0Pws4ks0T2
hqh0cNMvdDSd0qGwuoPmD7XURGr6OUE0fm/E+EXBbvb+8B+JJ+pifLxR9y5fJt2O5rEBBsMX+dHtPfdfvOPj0pG9Y94VHR+r5l8M
L9Ud5/A0YuiX+jl2ila28fC5qg7RD2b0v6g2jihV7U6qylLqJQPUNntNabhLeyUexPvJXNhMO5wfoxXOvM8MRTWEHMRJo16HtJ96
x1jN/bzWNXmoa6z0aEzX93TRu6VNkdDE69yE+gWx2n9ecC9gSfLITeiO7SDYJ08JY/BBRH4gn7F/WJ0PVsVo/N+YOsnV0Di5mHU0
Zcd5YZi1M8/SOok1J90dUuri+rdXwo4H8XOC33+4gZFHTzPOCPqLc1cTyjWDL81dvw0DrnUFUGzPnEX3p8hPtnuqD4HhCBwlVNTp
fjfOFulvSeksp72Svea30xF+5n4idP1WB9hSfIcG8f128ON0vrvPg2AHuSRPvxi/ln5midFG4Doviav2KTU51UdQOsY4H8IjqjQc
53l6zmZnVh9HL/gsQvylmWtaY/Q+YNb3N73motSXAi4hFt2w5jjLS88Qm3wBVBek9NBTTR7Ca70Z8RvolsGvqe8+a4N+/pt4Unbr
0PmI4D7j9o/55mndCTWS6Ams/unqOJmOH/LtDavxxZh1lI9ViCzvu/8AT/howd5vV+JQYuaaK0i8oB6q1cxt1QrnGgn0MzJ0HYp6
zPl8BaUcF2teSOUQ4ATan35RYte4zNE5qQp+OuHocGG0mkrJrrn/AL6hOqaP0S6GBA9gmrIPU5v/AA9MxVbK1rufMpH6RprMph19
SJ6Ib/OmOJ455pJc1HkfjpBAhw5MfrUo1Y5JEXgDT78P+2+d7ux1ZWVcVMdEJenDp14TNk2Nuj/iy3IHRjT1j2D7hTzZfHRtvmzn
fx3/ABVlnBXyGbXQTU6ktWPO/wBS4A2dno/9IFb0C2UVDx892H6ZEtxeL1dOEVVVt4/+CIGdEgIVXge5+oYF7QYs96f7E6Gxyu//
AC8rnCVRR1HzjGranyy3H0P9y8J7Gx0P/F6NG36zR+13JeiNw+SLI7d9NJlyeEK5/OJyn0Lle8ZLPlKDgI+xFz0vQS4b0P8AZliY
bHA7f+SDUGiqZReYDzlecwFPSdHcV+kU60yekb5GSPdqY9iEz3zEdMup4iaJ7T0HHP1xe8+fr7QbydP2TPLfW9Ju/KiYfkZjzZYH
Eh7k52cV/wDnCjY08SYhBwxesxnPC49MSo1Z9eT9bcNP2yXbnclH7iOoLt8LbbfVM9mohPnLRj1DgYvgeKv/ANejhK5ExwJjgf8A
yD//2gAMAwEAAgADAAAAEAABDAJIEAEAENIECAAEAMAAAAMIACAAADEAAAIAIBZgCAFVWkv7AALCAACEAIAAAOAKKEEAABLpLeQv
+2G3X/3eAAIAAAAACAKJAAAAAA3EeUEGcpMZ0xp8bAAAABCELPKCAAAA4d+3oyRKFJS2Qn0o4tTBCBBBBPAAAAPC60DnbyLp8fz2
ISc8Bv8A1SAAADzwAAALUYpG+sHRR44HBx587B+Y28wAABThzgQA/sZX787s0hWMMmBKelvAeF6ggBQDwhkFpv2v6Rdm1MpBquoE
F0qqBJsCABTzyjq0MkDNzVJolNuT2Py3hp8cUh9QgATyiTsIN+uwgMedVTuJrlRJNlA+SOJGgDDwzpiwZGDqbqw9ruJpBIgugwAh
O4AOwATj4lSUsRyvd7Z8cQDuqTO27/8A2vIxh/AUskbm5EZimsfThS3mE5otRkQuEc/B3cAcozhqAD5ic880pXgZD3+YiihFLkTA
dkoQsCYE+2kc4qOlLmOg2Rg3HYo9oOTZjWIco8pZfncmbCHBsEzX8mcHfZ5yXKFz0PgAoSZjcPTk5x1l7Z1VJ51DPDkFPPG85XoA
oTYzcc5xRxWCOd8BgcQZF0NMzZxBhvIQESPAXEkt4pGXm6hRKK501pQcus3CC0AQAEyQAKS9MpO7ixhyCWNXxBT8STs29wMQIA5v
s4dXaN43hvjDrfIrBOJHWTx+0ie8oEKmthf4Twgn002O6Ak4kRhtTE8nDT/ogAFyEwoKpFWqO4+WYGXhq2XspWwA2J2MIIGffNB3
woYda24+idCSuDM3SIaN2P1ogE8utsnuStW20Npwz9QRE2Vb7ib0xHTAgTGyO1L8uCftE2L9Pv8AVrPMPIxYAAAAAKEDvYNlvVYP
PPPPPPPPPPPPdWcCLTCACCNbgCAAGIw9vPPNPPLPPKOHkgBHPHPCOAABHKECOAPLEvcLgG//AKSrMAAwyBziBQCgBTwAABhigABj
LU/vOKMAABTygBDAAAAwhSABCjDAiACCAAQAQwCCABDAAAiACAD/xAAqEQEAAgADBwUBAQEBAQAAAAABABEhMUFRYXGBobHBEJHR
4fAgMPFAUP/aAAgBAwEBPxD/AORhDrYdeD8xuiv4Wi4AtJRFgIvawRxP/RgB3CZJzLQB19sDryhk04108mMBdZu11YoAMosGGFut
pedbzZHFBfPsuGXUcTuxlOAG266Y9UlGg2azLijfi/8AjuuR5HF+OkMU3cjkZvF95Rl4suRp7w/I2PiYnUIzgxmKszi7/wAwAFUa
aLvjMeKJYq6zuqiZVG2FQnuPb7jmZXP5dBxlJwtyeD/x/wDA6rCOlanDe8HWVfG3I4HnPhAuBaVcvCCOxz8RwC9qW9u8DnhDbmuk
s+3fVY6l4HaYP26S2NvoWO2w1a2RW8HNYP3yl5494mnE9mCVPUG51N3bKHri1/1QPwNVllqf1b21/wCQlUD0AWRNYoZxQrODjjsf
tSHUsYJpAo2qGhKq1bB5iDAa6YuGFbKeHPKLYMsfCnH4gI4bd/tIT2647/2/i2sOm04v7jGV46m8l5+idzsdj9kMJh1HY/5pnwOr
sI1wR+p5ZeKhkeAhVVHLc2u92aG+LVG2BetIir3wDFgQatlCbM6coivPQNgaExAgBHUqmH7pGVVw1dCY4rXPfB2Z+6xEaYuC1mQj
5wbHeaP2RmbH/ECpQQ/gdrbxdP8AsKHcP3X7l+7GRo8DYdXbjAuYBcpgMoYJicZcMx0gu2O7b/y8duEvC44dQe9uEETGMg5ayzVT
MAObrh8wiNBMwYVC4s/mGNXvKTCPLi2w1cC8dWV8PHCZ/wCBg3xWzQ59uMSrTmt+zwfcV4A6Ggb9vvsgA6D0sXI7ILgYuBFuSqq5
MeGMpYF64PWhljKZHYa4fbhBip64P/A1q+LhF4EKpxHTHOklBSY4YNmH73ljuCgRl9ImVEDZMrxuHxLH/RBBDpld7H56RXpSOfDn
8RGXY7z6y9v7y8Rf7jNK1w4vweIdSsdb/rQ28LhsaD9bM9i5Gr9b5mh3lsKI4W9Ny68s6Ol84mVbbMcarGuEx8UguvAy8nnC2qFv
DDMlkRGwzALrVWPJFiDL00QhQRIpCHi12zEDB1NvzBA2IP8AnthLw0Y3E+kgjfWFar2hN7BZz/ptVxPg5vaDThOrq7h6TNauK6rt
Ybm7Gzj8RStrA3qituGvDvCDT0ZZwxe7XnrFaGG3hQt4fveFDufu5BOXTfkjbfG3jkdeh6ORHAgQKiJiZQoMReOyVJmEwEvDrBs3
cdy417V7y2scxxPnLnNROXg/D3P6xril8sB1p9Asl6nZw2u+IlLWYcMNDy/HvKqXBFYYzDBIWTLDqThsa894oSyGEQ2wZEIYywLH
sRyXDCPSAiFYHErgdTJ6Fpi25K4AKvWOMovHM6fZhcftaxXfAzMwiYdn4dn81bmDXHTrKE6te2PnpLbA1ur9d+kC8CYQMdDZvd+7
Tjl6GlxDXa7vn2hRul6zuFZeL3Ndn9pEBcOGltpVnOVGp14XC5sPCImgPTjADhBssjpb5ibGOAjW44Zy1mLZvTX4+5+wRLO3Wb8A
99ev8X+0Dz4mC12fe08QgdrKnF6T73+3ogegghaGbrucPGeyGgoPRagpbELipbC9HMF2TPvZoHSjHLh7QqyjY14vghnKC/ETFAgi
hCFEWlSxiiW+6PLEYjOrOs45T9slmuLPcbOfbjAqtYIzf2PEunqHJx8v8V7er7B8wkcQdrl2zeb4P2Posaj9lMJYOf3tdmyDCoPU
IeQlKnE2MdRF7CoZSyg22Rbgx80moorAzC+Uoy2qDkvCMtwGKZkjmId/aCBMjwTPBcZh1sNx99pjHjWJubiq7nuP8PGA0W70zGrI
1frfMDX4H7mwGeB13vqYwEszyig4RrTJmawxZSYfrkg8xKqQiXFQSMnQ95aA4kcPMl1ODOtL4QEFjG/nT2YymsbnYHmN1nobX9nE
YtAvv9z9BkP4FWhcNoQnM6Tj8StXazXT9sh/nO1/hUbuiP7iPj7mUbjhGQBC3RDaxPSWRiSpBpKlhg7Y1lyjex8SoSzJ3bLmAxg2
vKXTTmR4mDIfsLYR1sV3/U037T+Ltgp7n1DI1mva/M1aauzez36OrAlf3f8AB6MSKBiJZzP2EtBnrMElAHLyTKOMwSybq+Q/i3mw
9a7LEWn8YdElfOLqwz/xr/BMIVUzJjleiSmjTTUWviguaF9olLrR3Xx/ApaE9yLnQx8Pj0H+TD+0g5eUytLCDgxWYwxZGBq4HP6u
WJml8eP5NGV75YH2cf7H+LNAOrs/bITA7yxEI4zI1yfMuALux7XAOK8B8hL8nkB3hQwHBvtDC35nmoYDA3gMe8OkBq1gcSMcaUa3
tfHv/FPndr911j5UYPE155wSZaHFCZMcse1wrTeAfNR7CK7XNiuI+oW2EFYu9zTCZWnFCdgTfa5t5wH4nZV9o568cPDNKnEfJDTe
59zSjgHuEE2K0CuzAf5HJgsx4r4qZeeavdnjAmWRwIArDHGePD4mTBKQTALpdgZ+/wBaw8qAo9bU6odwbs+F3e38w7aFdk7Tuu+k
2y4r8zxQJggrhAtlJa21ljRNo+K/M8EB7zCiOAEQEFxPRMfQi1BuMcvQmUG5YPReX6oN4n8BeZgeGNP7D3hf0vjC/Sno/SzKCdJc
ZL9GSay4xYYHqN4xYSptevCtfbHxODz3MHqfxqkAc8/jnMtIBGUlxzmAl4xcIOEX0S31X+FfQy9FqYS2DtlUpjc5Ifud/wAbiF83
49vRa9GefqN+lxZZKR2IDgHOeID5majv2htrk/Ev6RG0X5vl3eteIaQ4mGSLjbswwd2ha88Yas+lNnHOa4HAzVHIfMs7HDzAKSrd
7r+fXKTCvKaylXDTy8/RmPsOM8kCZv7RfE7Iv+JrdxK+ZspxP1NLxivZnbkX3JrzkDzNQOFPmd830m3vP5TKeYX3mVrk+Jk4fyHm
Gmzjv3Q+eWIOm937DTjl/eWYjkZvblA9lAAxOGmGHvNiW110z7zVobDXXP3IfF1tV8JKqKsnR4/MyM9Gi/fR17QcBWz/AGSPQaso
4q6/Gzi/cav7Bw37/wDE+igUA0fPUgdH3e+f844x+y2Rg3Ya8zLu3R/iLT5OsKETaY/5AqUTp/Ze+vL3hzcv4PLjxmDNv1eL/wCI
DX25Pv8AOE9rBwfh51Nejbl1LjVnEWdL7TvIa7zKR5+mYKnmcTODwHzUWe5z+A5xQpmzPoYOVzGuMcX65V/58bG+FPuUztYfkZqH
2H4m+fnGal9j7mcuI/ATLfnj3uABR/8AN//EACoRAQACAAQFBAMBAQEBAAAAAAEAESExQVFhcYGRsaHB0fAQIOEwQPFQ/9oACAEC
AQE/EP8A5HXq5jmbcS+RKJxw/REBEqMtgKpDYiI0/wDQV9ycn4eJ2i/EHR+H7jK4zoUB3x9DrF/Yl+vsIAuJwDINCIdQlIwFVNay
6O8BtV08qjgAbwfCBVd4F+uHoMuo43APL7wubdjAPd6vT/jruq5vI931jkV7YvXIcQ7TqCDPmur0jzzQ05nv4lOLGzifJKsqYbj1
mUZQ6jGAtm/bOE0vE4Hy+kuk46YPXOubUYLjZl1dfucWyOEp7nippVf9NvU8pac2Mzme+J/wF7h9t2IdFoc+DXm+kvk4Rm832MOc
WiGIuhw3ZTRAKxMngYuWuMfMauh5beIpBBg8MWZqMsZZLEq8ZjtwtX48wkEeebr+FAVWBphbJeHjldACWYmIfzrUrfYXJ15Pcjc2
qZC7Jo8fOcV0jR++v+oceboG79xlSbO/Pg2P/Y3sH2jY/Cu0FVQTgEWsahIGHWIqZVnOY1IWsc9oUm1hk0GONl42YZPTOBSxX+6P
Lhx7RKCxSe/PjE92fOg7feHIvUHNyHkaehw1gug+jwTUlLKnU4m+4/jE506Oibn+YkYvoarwgXF1vd7H1qQ4pfdZdOjkXtwG+rwl
1rQiotzuALz7RHAioaIRTAaYYSFcLq74/wB4DiwKylysdAzfu8dBAaPVerHOUydv4+kAWZQhWGSRjR6B3ODqfxh4UPtnB/xNBaxy
d+q6HI1/8mAAz9j2DQ5ShVZzUOLu+hlWEWpmVL4oRNjKlHQ/GtQVdBmMQF9JQsdplHNcCsC+Nad42uLWY+Ees2OPD449Z9jXx4gl
WWREAZJCYD1hoq657cdriVg/4OcBqt9Xp55QUNl0OG/XN26THg9Z1XA07bsfpa4r+N44I3ImLklaxZdsBtjwxPepWOkzN9sYhkmm
JM5r1NYrvyga0SxJxgaSkdsxtZkiyegg8/PeNR7WXD+eIHCiY/cfH2eni4RlvcP6z53++fYq/vTOYcNmPJ8s+u8VDeCda/ua6Fb1
FStfaOEr3QzdD5eEyfMzu22+JkPwmg1D+ygF4nzcNMYIDnm+x0jKptDXgyjSAv1WuRHkZwYKSxaiXLW5ZAfI7eJgumVcIQO2y3bc
nTtCA41MZ2LCvdlYFYvA232uv4nKlU9P20QYDyvQ8sSHG9aZBxT1bmUMMA0GgR85jq8D5gSgI+l33sXpzw6TU5X4rasX/wBlYyja
WiRhWnH77zf9X8iLuFHv94zOZqGpC8kGzGBbHOGMIjTDJHZS4sput3I6Z84GEhgnFh6Z9Jo5z8z5PD+2HMBDrifSz8VA1o1PPY4Z
vDUCBQTGrjrs4HHjppjldyvXKWJACtorjFhuMHCOMpmsdYroigglTSN3rP8ABGJLCq1mO8ChgT152xjHBO8rxki6mMWJeuTvg6/r
Z+SL5a+kobQvvh7esN3AGnyfGm8Wi2LdeLdwOHHXln+HDBemxx2XbPeIcXH7hGOhFdoXqfyFmogCX+MEUCZBm+ILJzwlu2YmsYow
YbF5GMwA6+8JS2IY5SpGFTwHT3ePKfYRVPn0nHo1y09P0pN4+3vMZo7AofeP0oM2JOH6v44d9iHQtZBB9WQZnE7u3HLK4ge1zfxW
LtMJhGZdrz4y+7obs15d32JiLjh7wxTjGleylAPcgVTSUgKD4B3hISHo3esMC/dX2lGXkO/I88ogdBcV4rCrs95gbSeph4D9LtoB
3f5GhoL5r1mmxke7u+PwTtL6cXhC1bD+bDXftFItflaI750FVjLrUYExgWhnBGC2AMaUYCDiUuSYyn00Y1cUcGMahHEMRiUmb5WA
XgKmN+/xf55vhMLqLweNL7WQjeDvSfocHBWnH8VYoZuh8vCO4MfVfehHDYvYNjh+VFsa+/C1KFawTKOX4GC2OcMgwG+0SUIIqj30
MOkcxCtWVbU5XwqJtgXCl66x1rQlIZcNe5LppXHcp445ZQ3lZrsfO0DqhIHT+TEf0v8AR4yOAixY99eXzLdVGQav3N6sZ9E0DYg2
kpigFIFRVgmdDG+5PFiZgu0wFkdvAfjDfdwSh7zPVKJjK3laMxBxHzEX1eOx3Dz3gXhErWZKHSkwfaHGJVq8e2YGkY6OA4b83+aT
X/d/0o3VuyfMfZsl3T2mTcMjfgfcI9fkaB97zKIpz/1XER3hjbZpDLYMx7G3mijRisAVeT7MqXgZSNMx5n7H+lScgnpZ6hLUDC+Z
lfqMdJyNA4R7n/DjExuqmF33/DyzzzaCxxoMaqEbWQO7UAT0t4Dw/o+YkPZuDjUcL9T3gXhMejL/AIkUhhWZnMRlRFMERWRaskBR
lidMvWpRmRPc+r+uPzlXXEd8EyIaX+92zbTOFwBBSkXFfV8S14OOHmogsTmPZZUA8LV8RaxOZXmo4ynQ9rilFSsTDxE663gzLpTG
pVW4VWxz17fpYPAYczLuX6TOUNnJxro4RLhPQoF8TzKw81BL5wPa57+L81N+cyHsxxvAvGjIcWemQL4nngV5qZvXn8k8pf4hkxy/
omSV5P4Zv+2fEfWwjwsGL01XuIfTzokeUHIPe5mT6AeCe/t8zNp5txQlJVm0zb9XzMxHmy8bFYLDdbrtXTPSOzaW/moaNYxn8cna
iVjh/wCl+5S/I+ZkOS/1Nu8g+J7rx4mJtecVEE4SuAtapbhNucj4T3pjxMYd5qxFjqJrLmBGbIWgqGEM/wALUcWJTEIaLr/5cRGn
9Gr/AFYws4+TpLzAZdcaeX4v+DHpM0zZQzZUZ6hwmNgYSmAn4JbcCtZRNkCmWRxalSt5y4HRwfM5vuziej+mgnX0y+ekzd0vf4gM
tS0MolsrCUDExxlEINH4IFsIzIgH4XGWSrhKRKyiAEJkbrn/AJX6cg7o+vchKX8OUqcCVUsZ0gbymUyt49jPImYvq+JkPWw81M4p
z+SedX8M2n9cJ7Tl+831ylqn5U8kZCjVodMJXV9bKeWU1A83NM9W+0q8nH2jJLcK2aw9Pzn2oDrDZfBzrH2HlLgUTBmeUxPv3xMm
ZzQ8sPX38BmnfJv4m4OT/s1HJAeQnktTwzRvVvkmjvO3xPGb+mYZg5fBM76TXipn/wCr5mczzf1QyzXflw3fo3InBTXgcN3Xln+5
g4h6uAea4yrCSrgY43jj2JulsL+HepkjXdfw7MwIhse4Mx8HMws4nxk8M5zyCWr2rV6PrEDg0f8AY+CrkGcoiA+r3eB65Q2jh6vP
Y4d+H+B5Aq1FvCtMOTH7bmcO2R+th688zWHB6Dp0c/DdhnLGF9HJ9OUVqRolP+RobXaV/Xc+2nXtEu8HPv7MHKY+Wxocj7x/4l8k
2cTt8UwT1oWfJ0VjnC2u/Rr1TEavBp9a8zwWL8XMMY5n4wcLPZs+WZRDxfi4F7LD5L0qDN93y9W11qYTyRgf3rf/ADZTDSG12dmy
eUh8JNZOSnzOAhoY6r8TI/IPlZhtDhh4qKrb/wDN/8QAKRABAAIBAwMEAwEBAQEBAAAAAQARITFBUWFxgRCRobEgwfDRMOHxQP/a
AAgBAQABPxDz+JNp3qazOMzzH8HXEzv6b+ua1jp/zf8AjvKxGH5bfgeuPwr03jj00nS5pc2m80/DL6Gs3mvqehfrfadPXb03g/hc
76zebTUm/wCG/wCNem0wR/7Z9Lzfo+mZr6b+pVw/dtdyxl0D0XEwcelzPqy5t6Ayg4TaAZVdiF38oN7H36wG9NxcUwf+vfSzPs67
I6X5aI1pCCWPIiOiIn47/jv+PX8uvo+lem/ozt66Ho16nrvN/wDfU9R+pY737cvcEiWTMku5qDvs7KC7xShj+xmK3MmfwrI95p+O
dJVtb8RFFNFIEfGq9VuRWUJq4RCLu7Fxz6C0sBirIXcdKi45UGeA49OASVWgK4LTKSkVu5ZY5aIvYraBOJ1tPolSf4X7EEdEfXp6
7egPE2hK9OPz29e3/Ht/w39N/THpdRQOFoLaxwcmzZ2msHA77Ij/AFIMADbD8Cew7outCk+o03qmCWLA5PghbNbX9nwg4Uc1f47Q
sB+9h4KIVgxXUN5YP+XMP4Nx6I5ql6rKwS/mrkHh8IxJOKq35mX06JVKj0ntXlHiXcaAZCvg+EWFLAsUKJfMagLcLPmXd07oPuUy
/sG6UeLEsuBtXyfUQGWwPsZ+IxA9QpPDAXQYTXGnyAFDqpAv7fbUul7kN6hwjhD1FIeluLh6aej+O343n0fSvw3/AA3v8d5qTaaT
bv6uQ4LAz/6mpskx67V6hae5XdrMDsGr3Kl64esYKM2DvZtfkdI4mHdo5IfBIZwCHJ0VB7qKN29jhwHu5X+EIC3IoELXa+hjLcBl
6Pli0XkpdbuijywCcRhMryREWWwWamdl9h/UoQAbW/u5hkEC5sIjax/AMQKDhH4Tew5HwlPiG3LsAe1PxDCTFB1VLo7sBGqYQcZV
fd9pQQZdrFscK3eYhsd7G07K9EXJ+SXpbodND8N/S+ZU7+m3pibTaEuP476eu/rvNsel4/I0m8xiLWTwTknLxO+jwuXsSUg8hZZX
wLezbTFdEdKlXpcHzSrSPDmAXdk3kNHkcm5BBRJSNNew+JY+BM0cHmsF5heAUq93fHsiusupN/gCI0EsHXWHitDgZH1svYl/WHAI
8xqux5A2iCElQLZUSszc+eq/mOCvU3ogIvRWkMfug2AynNo94iIqTZ4SnBj2NkWzUerZMkENrT5KBQ6qSmrith7oXv4zNtRzLpSP
dLM+aWt2gHrXmZ2+QtdNF7V1MYqxwp0A1XRTrcAklYE9qe0tGH/uJh8jBTSzVQfDw9o9BqBSuE2mnrv6Xj8NfTrf/Df/AIbTt+VL
34ImiZHgdFo6uekq93A+6Mv1DU8BEi9k7Zek43i5scaj8HSG8SFlsqugFqsAKy1oYJUrqSOVqsI5qvoR+CqUd2hsRqjjtZrU3hsO
36/+wHhf+j/HtArTVzwB2lrpEnmIX7CUynA2gPIy9uZU8rmCO+OF83/kJINXhyVgYKSaxZiBdLNEWI9hn7hx62UgDGCUGgMAbCBD
jpXiwAewwitrGjfd1YaPcK9eQO3PRKCZkHEU1XVPSvVEw2tB2TSLDCxapOm/yPeFCV24LsfpcSUgV8kbnRuDjSzpH4u5Z29NvR9L
m3pt+G35/HrUrp63N/mX6adpvKgXl8FzsfbtBUDzqD4u7ntMF5X7FGx1aI42mNI++9iidoZf8gX6K0GBwsLzWjKiefF/BxLS1gvd
xH0toyrpdUuXtWkCD54BkRMj1Jop+groaf8AYapQOVwnINZf2sNaPc0YK0GlmSyzQEpTXBGBLbGtt63gRjCDIkoNu36UWEPBjSgh
a7q0GrChrDS0G27XWolGDzNj+34hdNTYoeIK8WrfgMvdo6xHC3N9JexQ2uLvL3m+npcGfsBBcW6HWiI3VCpRhE2ek3zEICWJSPRh
hTYs0PfTsc9YA0OBheNQYJYWRKXqGrqY5JseH9TkdE6k3m/5+PW5rNpp+O81nadISvR9W9O5p4S/+DrCZNbXbKOrysSdoUvtXV1c
cXHLtbCOq+otraJjn5LE4pvAvcY4W1146scVS15YS3Voa0jWJfC0QAs5Q6itbxBT1FMnQD2GhnjAO07bnv8A5LUFXns+5tj5haIz
IJoJpf4NQlNqfk7d9y9oLdqH3Ud1cnTkidVg1WAKHGMrB1cS4j9mxQsuU3WexiCkDUpdBgLerD6a93gLXiDZeBLdVx0WvRMrdpa6
oW0qiqRG90hNERNL9UMRsDb8BrWorVwERtz4KFi8FStWGqwi2q0paU5yHJ7SyxtewH6OZvNJ8b6nCaJ0ZbCNRTdL1dHHDtFJyXpF
5W3bR3lEcVXD0P8Awdp59dv+/mb+vf130jUEYdYhO3D0avbUYMBdUdANXgJle2A+dH/g6/haXflidWyhoWWhBToWGgDsB81E+1Ds
ikSYscpYV08FXfAUEKhc2NH2/wDIXYDEvmVEVIqXvlxzoYj2t1QdE1Hph4vTXBqBc4N7NPaWumk3IFko0XSzTtmApo7eM/qM1Mpt
6e+S9/GpFsmtuTdFs0Qb3do/hg+8AbDInexcoA/nqj+CASrLDgg8Ai1OD2T8c0fS5EsvgOVtAAylB05Ds+WdL/h+SCyuqbxFsLMk
y/daiMKYR3mqFwo2uHhtlTP6OzjtLJsIRpNsQMUkYAHDP8Y1NuIL49Nuf3iZQJbe75+Dfn8On57/AJnpv6k39BN1iZ4Hzx5PEcNb
YztP2dCVFJROPpy8rl+PwWZzvas/Zwt1KDNg/vMAaKDGUU6+RdsjQYPYJdzaVtyXtW96TYRVuhNzgyN4Sx5CAH+BV8b+EcGzLn7v
6jmEpYDlMGLL1jDqVxTrVBMDi97qdIUV1Ye61+4ImgAOhiFkpuzsIcN50OY8Si8AFYxXVGt9kBfAAABoAaEahh+UxtOgtw4CliIL
FyvjTvhaiwsI3HTK/wCbcQ4aQfUp+RlURaQz0nfvoddJkllRlXK7vX0rFSxtQl4ug9TzadBjWIGQRo2YfTgqHiuuxGEvI6b8srNe
tWzJhO7/AODvB3KqzI77B5H6jl55A8uTp+mnrt+O82/CvWpjb0+vTtO8pYHBvsH088RWlhQ7Q4OXaaYWdtg2PvVm0Haro4Mqu2xm
M2bZHrza9jYrVl9F6G8zacCO94CusBdoroXR6gg3Ro4CyNkTNMNHmeqt+YgXeKtek15vSHGmN8VV+qROJ4Chxb7nDZdOiceBgheN
cG5maVtHXzMgR0AgUAXTdHrFQPqaECCoNVnOa6zKMcPu/RvvxMFsGRGVl+cQeF5K6pThK38DQdjwYtunEdP8DGIoaqLRb2Wz8/Qw
dXG7DoU9iMQF4A03gQ2oFAcBtKgSsRbSNcab/wBM9oQMprxZS6PpxApt23dF52fJo4j3ZU9dRP6zJj8CGER1fpDZ/UJmagdUWz03
7MHz0lbnX8ONK/79/n1fXaZJMRYHd6X3cbM7qmR6db6MwQz7SPofbn0LZGdn6B19oZfFLSLu3B1d3t6AkJjpms6WHmFjOyBCHT5T
FkevoVB2oSjzjy10GqoULVwEJQ1ZrisbOwabtmQObsLNMNPOkFltnoOVmSJYF3hzgCvyHwe83lsiNA8yjdezqw1hnB8E+iEBF8gY
+mdVQTxLut94Ziqc1pTvCbAtai8rJ2XqStc8tWylnSBZ0WMlYjRTdNQ6WHiKu6RKd41vzuJdLeDYIiORNE5hDMDZ0DlZs2quv03X
XtFttbVgqsaTcmlY23DwdWI5Y3NC36VNyf8Ar2WRo1qcmon70Skx6K000qoBqqgEqnoUr7UMTS0F0hE0ibN3wNkX2jDxFCwOAc6i
Q+4Vmd5T6dzqM29dvTzNvw39KjNptL6zf0FYp47YP/wLdozTM8UFof2ZkDlj5nq38G0YWGUKihw4OR9nwdZeUshZf9jTgzxO3plQ
NoVHToaorStYRFJfpn0eaEOXqCMLdFVS7QBvrRLL+KCxal528sQk5SKIxY6aHl72IvfaNWtuhEVMXlXtKIDtd1tLTR55TiLhmWZW
wDWPIGkQKa2OCgpi8QLcWI1oVi3jH3K1kVcDRjslhddtcofJFTSgzhx+4GwoF70J7kEhE1rINe6MWcCaj99ppLcEBznnJpyh0JE3
BPY+oIBaKUrU3TV0Go3sChbrYeNPEbm0wynA3Y4dZbsd1u+Dab+hCiV3gbJuJYmiKS8ojSCvG+4uMajH2D6FLo/HGpPJBJfagfZP
qtbKu5rReHQapwOeLWq06yxijVoo+CX+YbQDFSwAtZKUQMJnZuEwUwZWsYIA66yLdbZtb7OtTJ2xZQ+g/ZsieveaypWcel49N/TX
X8NJvGah9c7vAarwSq0tHltf0DYCWdnJ2D+9A5beICKFNAFq9IFTrF+0f317SuMkjd3XR86ROansp1fQNQM+25r3TIMGqDWrrgME
Qx0u0ChbAmrc60sJxoGTYmrdx/D0dEBHskdYKWmWQqDQdo76TlRpb12utS+Aay6oAxcoeCK6wuti60o4l0N3H4Qo/wDjhjoXYMIM
LYQNmzq2rDWZcpzj9FkphbcUPi0FuDpbXgOZeZolAbEW7YeyUWnV5jDToKDCa6Cvq+IADfUnI/TErMWnJi5fRG7uOpEqMOYU46Dm
/EWycrQ6nnLzZjToruYN2QXQeZfBcV1e25Ou2xFhDpalouMGNWIkODYHA2PUqYi3KBPcQOsf5H/9hr7iYrqeGtD7dICiTRxbwYbC
s2ZshhSMQnImwREdESJjqQbyuAzizQ5MREknCAmb0UDBYu8PR4ydjLEhgOrC0A6t+02jJ2HKjuwSIySQmpHLdqCtWDFSl9mjFu6e
KeGmI3UBSjCPW/x2lTvNvXb8tCNUGf2voHMcbpgmdF6FyHl2lbE1Jijau/hodbdibF3HsOo/GssWJQ6DQdD/AN9KzV6xIgx/SrCX
NzXtQy+VrVkQMBSDQWTdtg2ICk0RjqVSUFLQzdum7XWEzdu0SuV3XS1hFFuBUDwdCAPbFRQ5G2IVmCq4rGbdeYXrcAAAtPXtVYxl
dgKJd0+hW4uaOya9Qg4FlbQt5HZirZwW8OGM5Tqb1gNGFOi36vrrHsJc74A1I6zADF0OCUANt2YUO7aIykCTAAVuA27OYRXmFWbV
C29fpFYKqMX0iuBRU6U28hDNHFYDim1edn4UnEvjI1UFm+XMpYVwqvB8xr7LPIv+/TIUyQL1HB7r8qEb0gZHeuMD7PGECIhLXm8O
t+5LSH6vXN8utEok1rL3A9ymAm5pZ2RsPRJWWHoqFDA+AVmoKcJSFiOj1E94IJRZB2OrvFlOLJRvhAAKXLUGCWDBl8oqXKoFtbY3
CsvUUU+XSJsEFSnB1xCzCoOLdicfYSFU5gP4GHqHPrtn129H0ubfhtEbtcOLjuWO1xSSoBWDADlwB2ia6+mmkHQKIaIUG22Dq6e7
tM/BjoIoA+AlJrNDo5dW/t63RfGZs9eWD+YJWAItoq6Gjo0NlQ2RVS0BwhrB5ppJzbpDIaAoiaRkSnJalW6xx0iu2ta8ErvQx/u7
IQDyKGv1B8KOwUsUDR0DKVMpygZesEKGqt9SYl5KEg23CoAii6i817OQgwqiNiZ1jNLURe6F6AUcQzTtNssMHRpsYcXLcz6n4wQA
wBZRUFakZQ97A+ZZLIbv4vIw23TDQlEoDQWhbwqICBnQqeQqrnJLkNJqIYDw0UQvZzjyRcB0Q1rZVqi6gLGAMvVuOd2wDdQjxW5H
nJ+5u4ogOuxuuwLLNMZAHbcNZvasuHcsNbRqGGrpd9iKgu7WbnGMOkEhbpj4P+wbg0zGbO6irkBNINcVj7Lcryrs4lQeyvQaKicE
fDAaK2iwM3OQGS6l7COSq1KrQbB0oltCEaNJp5FZ2UhKQKuonzmNTUrHpNQcGqcIchrDkRbVOACXuZb0Th7jnyanUiQ1JVg1ifCd
Zd616cLke5TK6el5/Hf129N53lRxGzWx8L5Wa9UMOxk7G+6cR7pOpJwEwC4vaKMt8Gh0JnyJseb04PMxGALB+GlOaQXxw6a88Rhx
MDkR8jCP4AvTB8/GUpcZs/XKRThvZoeFbbzGrudwWqNV4PisbDpFtm/KkrJKywKR8qYmHM6DbpLOuVZllqxq961mLdsjFlAVot6Q
d/t6SxHA2Q0G+0YzKKBIqmbEa6e8Lg2QCwtUWKDWqXGWESouinkMrHGAZY4v4UYGrcA2DeGW3joqUVkIwVOmbAQzChoO85Uuyi62
ZexeoabYVaKtBvvMeLbLJRYrFlPgmvkhRWywA1DqQC06R+a6AgqigZbQwStxXISQoCw3nANpYvxQl0IKjK3Fm7FAH2qmlu4i0wN/
KwrB3S1VBaQjqcweBABt2A6EhpDDBrV1cci5UBbttDb0RRsWNUAdw4tiZWwVSEQhUjmFehWDa9cQlgKLCFmqRU3qVuWyontgrTKe
cU2W9HAjsPIgejzthjyFhFJQrqlhwRXdC+xz+4KxS2+he6kwIF6XvFWJXLeavFG6y1m6nTJxRDl0MqhK94YGjcau6A4CX/y8+mKY
hJhD83wGASC99/HkU+YtBVOqNrEWxVsNNv1o1dmm6Wzp+XpN/RXPU9q4IATW6/b56ttuYA90B1/8IJSE+E4hi/x11HuuAhTdQVWy
IFiUY2RqaBEsZT4buGuxvRaHNQ+61bCAJ3A1tAcHsyVzYqO4WRpjQL8mrl9wRVekIFBu47k8MYBxhWcAtcBEWtfbUoJa60a3Bsgq
Lsv/AJUyrtzQiQ8XKr03o7P6YFXw4baUhZnfZBnomvizaEEExU8UNQyRvkuLEuXkSuAmsG0pui9Bxbna5aULhzBcUxVWZtRllfqq
wrrVHWFOEZjSBO42e8shGTiKLedIAOFeWaKwVKvFHY1o6xKhrV0EWYu9UpS8BU4VlrYuW/0MaQBkJgB0XLDWi5nWsE1Yy0bs1hNW
s6BHZJBYNFR1WiS+bmD4Q7O1o+IowglK5VN53HC7MLjABksaNZ5jzrgtfV11t4eRlBT3YbTxdeJTgBhCqQA9aofDvDFAhuidjpVo
CsGFQw2NCYpiX+oALuux30GgLiO2w5e5LXkub1t0vGbV6xe2O4zf0PwdfTX8Dvt5jJSvuRoFwA6lg9soB3ED8nwW+JVgZvIBSHl3
dU5lSo2/O4BydiUpR6Q06Gx8u/HoG+UuyU/ccox4GJ7CIv3AcBsanVVN7HR9mEtiPB7UiwWQdcsQa2UidYHimhQUPoDgv2RYnMWA
ELoR44lbgGpigOn9pajcAhCnizum9iUHUqOgo+rbIC4bemFNADZrMF5TqObtk5IHbaOB0qF63tMTaFJXYmOsDuRR1PGpMyUMYmmY
PFt64Yi0jQXgFOczxCjqbdSxLuzhsrFbHgVXBKCDCWzi9AsVEA56JbDxF1Qpul29n2x2RU0G2w9pSebY7Z+6ilVD1QuHrZ5hjMNC
wAyDmsbdI3sW4JQ4b7reVYanoiFSqUJZsjZvNkaGJ1Cl2DLrdhWbXDvvpzNAEdxxKvvDFJhoKwbEpwgNkYAGspcJtXSXN9Y7PR5H
RJdhElawvyaNbmhctu3zlGs0UAU0xRmX6ebY2DQNAYIt0trnc0XZp8szoWENW18U9349pt6b/hQNprNhlew+8raX2QC6PBUfdejV
ungo8RPFXm+h1YDgt4jnLa8+mdyYv/3ekO5rnVXK/rQhLiNnZdR5eeB7yxjILTzcvnlzg4U8jQBYxQYNKAdcSqluFTFANyCyFqNS
QWACvdCMQVO7BdkVRsMbxYlIrVuqusN/htMAhnUUMYloDpuLagui9Wt8xtHKQgUhZgYuI+amWRVUVcqDB9YNxmz4C3uVC2o22U94
Pl7p6qN1Qe8GCnJR2LmkvVUMAANQAoDoFEtHM4fKGLcrqFCqBcI+tZXUXRai3oYCNIbLQuofeKJ2Hdiip7yUbbEeQRFapp5QiQIJ
5VLPdYuqMCcp8/GMAsv4GXEmyyW7UZhSgtUClDZdsvR2IW0oNLt1lQlCuedjvjXSPoi1noAX41cxaTZOzdCPMQ6AZS6HpT2FI6sq
BVshK6WGgKcYi1WM3cqOr6WLUSW7geUyk55p3b2bg1V1ap18lPn/AIYqV6cBpnwp8ItU1TfD7jSb6yprK8o/4en/AOLhowr7XV6y
rlTYmYZOk5+neO2BVLVd19NcKhL5vflOGKa11XvMpTA2lse95jKtLzIvVALYv2pbSfzMz2gNYKg4LC4oVVUPBJcZ4haFrR0lOGor
L00L2UvSDIrcRvFZn2h7VOGAb8ggZaM2Bl5reOjEjW0t7jHR4wC6K8XGsrGjhNuUOWqMWxbYuIgrdIahBnJAZHWMAKGi0xQYVRpN
jEd6nuYsyDoYzb3ewiu28ShOxKI+XvHAbbTIj8hhoqwXjJIVXGkAGMUsDQJdUvJ1gYlkljtJI7VVLKIXY6u2zk0g7rCqTUITr+Fe
eQO9k0ZeqehKGi5lrLWLyQ8gh7crR9y+sLEFFUOXbSzUECiIUS0TapbrsOd5SegJBadaAOXc9RHV8qa737WQFd3g93yj2/F/FaLd
p+9xffYeI9xGX8dWvHprLleAHq4n/wBcQCMBQBQHSEDaGrDNPyXnn2czLm/we3fKo9p5BBbK+GFSts1NlTNoYq6GYwN6IGZZbC6T
WY+xEZEnZPtEM6VLcDiJauit43CWLtUdw5YZA2FX3lHDbEWgwC1N5eThkC+QCdmMYSZ/FgZC8EdLXWEWmGa5nuQghK1AZV6BmXNA
AhFy6g0FPdmj104Y1S9AZySaJvYIJaLWK6brE54YJW4G54NYSY4gAirDkqspakrBsgqoB7VREZLCOi1ObGoDWo5pbUxZ6utnLBkj
aJbnbKKNqVrlZLKF4bMtjDBVmlYLJQME6cQs7IwMqFqgMqpoEpZfApNZFRs1zoEJgyMixfIjh8Bk7KiOEsj32yUVy7YADkGyUQCp
iIwCMjqitHa4MGmCAYmKlpRvDsb+gA0Nbbi17H1MI7QfwbPM2Knm4Pd+Tf0x6IWWeTL+AwGjoSC/oi83ZPKX9xWUUW1lbNbqdrnq
9uZc6RQSoBlWMFjgbyTbq37a/gRIzOFqlcMoGnoqgnCrJyCxTqbWjUqifWhuguF+wmPASd3oaT0FgZQlqRa+l0NbcyuDAaqUTfGE
3MakD5mKAtBqMFVy7AEcN7wG7xaqaKdrwRiFdglOo1ip0lpe0W25bPfX2TEdD2l8jEfZnqMji5OOqiG/Xpezo8ZfUQgM0ODIcuca
MEqqgdtSXY1FtQgAPRRYR/wGZTjmyAgux0KIwD0qVJqvfSZs+BOTu4Owd4KvABFWjUN5uwbXiXPsWTdzk6CdBDBFqDaFENECiJ1I
G95edrAVzDOQ1LAPNU+ZcqFPRFfw1mQZyDdCiwtsy8D5skKMGAd8wdt7xzVXLFxqVeauCWZQ6AWiwQwKY4azRgmYbGW1MBqu3+RG
swdXWPVR94zNeWF/+QDggGyX+MPFvv4OH2r03/G8V6GUsN3A/DFydD5HPwjZxFS9mSlLRwHENZUPxNvQDdYvp+0e7x0b78fiIAFV
oAyysz7ygfrPlh4NzwZlhYX9iO1HfVZIKtyuBQyHab7ZlFiWSrbAsgDpw9pk5QuU8aLhQHL5EdmmICSqm7Q720t7TOow1XG9x/k3
mgbjM1r1eDdQ3lCss4go5TIU0tZmmPRgQj7M6E1lwBbexF1z0uW4ter3k0cPUJqDQ1MAYEBiCqpl1BQo0WFurXLA+WfRKA2AAl48
l1tSbnBqT0uA9Tdsc0currSNodVWGGOlXRxH1v0jKTaAA6GhL7T/ALbHvHoJeCMOoaeLgjoUA7OuvKK5ZjD/ALuYhgW0BoBBlZbL
HYbfqY7pgLQcirIwGly2Ko8HCXl3ArCz9TRurrNcxEvY8KhoaBrOcSqjhNeFbQJWmFRTnsaXbxgru6chBWgT6o+MXltvBbkQAtXg
lKSAuvQe2/XxCFqyPe/QkQ7tPIfsjSxe/wCLQ9/+ImMvulj5M2LBdAHype+Q46Xb8DLtUIQwZX9Lq9IxBS7cv+aNCb+m3osaKHay
wrynYQ93nYadbrq0NBsOA9N5ZKkqLsiZE5mE91V73aWMuldolJgwPSoI7o70V4ullL1LyAUm9G9StyytM96ayVToLyWUij6zgorm
mHozVqVBwf8AEsJWTAU7O5LcJiRfhMPFvSKafVqaWYXS1cFMCrZtZqWXW13elTiFwkOhsGBOO0Inn9QyZcNFlbSCHLncEYoZE7HK
F5TLcHxN9JrhiWBglkYB5A894o1+pmOeuxTKCMEvrmlzDcMq6C6OojwQKlF/l/nmOBBRA+uwFX8s7vuyKX+VQKBN6jK80X8RO1rw
g/dy6kmo0r5isvBrLrMNCkMarU0WCHRE5BBrqeEhODPeXkdQY7x5DAirJHOma+06A1dHx0Otu3oNTNMrNK3jwIMYTgh/eTKcCd19
/L02/Fm8CupW81fEUs2Y3Cx8VLJLPP1T0LtjZycDf9TMIW55Xl6/htBu7MYOV/XLDJwWbYNi9D3j4o4Djg78u/474QjfQrdFdIZP
cG0uSwIhOB4/woOYtlLrhl1VR6fonDw4YJXYZpcWHRE2dYGko3YX/wAgjeiuW5em9VqItmjWt3ZXVo6QVV8xXz3+pWWAwbFowx7K
arBQlINAWtoq7AabmswNfHgMC+sbQCMEqXQAAAAAAAAUQVasuWImmh1xi4PcQ8wTWxdgdHXfchIBbRV83Z9yDVwoKHdZI1GU24s+
SOryZs3IqHa2HWoaCeq8PJLdOcOAAyt4DOJdNSVKCcjdw5LXpCrVCpvWvqLJGwUbw7plw2cMAvI0NccqtOuugBgVeExrRpzVzCKy
FSJR1D1RBcO6Dh2ihjM4+aqTy3XvxAeCCoBoHoiNn4ju+h91ETkbU2ryy9aKOt0fImtgHcL6D6Hpv64hzxMPVTDuf6jZVg3gfdwl
JoXlMWwA2zL1eOr2jknwGB4Gx67TxK2NEDB0G79by2FiMvKbv/wl+LNE/i3xp+W8E7I4yyN/pVzC6rnFJ+ottESQWIsULX2T2h/Y
iF1rOTsMUMVXKcgiK6QxgLsUDpz2I3KR0+MobBKPB0cvLEOiOQgXyN4DQ1QDLKW0oHbiDJJ5TaXo+1e5FC/YIfZ+5W9RbDTmrMQG
OCK1vY5Jt1jbWlNHiI6W/iGYPFSu2EJVAFqpGtS7QssgO40w0F4tO8qaukuBAwBETUZYtAhVHYyeGOwOEXgVSKtcBDRDWjoIGF4K
uqo0SpiunEa7UB32Ko6YisUqhqo4m1SqmyCrssxZNK8i0Rodipa85RsCI6lvmWKDLqoa9tPEIOBB+wQfFNVo6Hfd6vpnuhF6Uv4u
CxdH7h+4p9YdzE39N/Tf0bq6Mpsx7CSZGv6CP1NJqExFl5bdIm6Le1fxqNrQx2uOrfbmG8LoYL6JpWOaPJ6cHnX8dPXNFHByFdiy
vBAFuO+D/wBmbSOxqsmrS0e1yypBk0JzL1BMRvlOGLNN4mp4Cg6Ets1MExWyHor3JH7lu7BZuFeQtRprVwQIKItneUXxDRICaVql
EmsDmW90hCw00BXe7wZXgTP+qHELuREvI1Tmis6HehIujRRNDWvZEhhTLorPM/dfsgeB5mh6wpay7WB2Epw0Eg1qW+5IgqBkN09Y
QL9KGkUqi+pWC3IFbGAT3JtKNB56g4PdL8QALk9GfFv3yzKo9qkEVwmoTFtFGx6c5AmNvs3de3pjqBeWcnd0CK3dMnZIZzec7h/c
2u+/+p3/AANluD5gBPFEd7Kv8YFQDLpU8QgfP8deIA1ADsBHZB6Defp868f8FGLXWQtg3SBuwD0VbYiXdAbuhiLIbrey4mFgiO4J
hfswElWGNf8AkMnZFXFGkUNiiaL0jt4Ql9w94gfyeurU1Tk3msKZTK3CpO8cas1oamiA3wjCdBNyzAojihXImIge8IPySnNEtZSr
VaVmr3jeOix4HW4Wi0dSZWFN9yMvcN5LR8oeZQdaB03Hkp8xNcre6cHf3CMAGsLJlaGmzJMn9xDq0i7GCTBaAaUa1N30VZxAnMUb
sssUKTIJj2qYrIXzCsuwJafCNRUEaTCBWaX8SyqIayqzwVRgViXmtPyAVoKUxjCiONILIZz+Xj91FQiptVtXmHrFrystZcOe10ND
/wBlqf4qJli1L2p+oB5hftP2/Df07zP+DCaB/MxWn8X/AAWtFPasPNrgZ/c6vbmVeCWrEZLVu3yd+2rO8NPXR7pZxbQs3hjIJMnh
GnZntMCDObsWdw87RcYh27al0QGzeClyBry7/dQlNlcTWaWXDesQcjQOjr4qGAN/8SIctkrE5SyjVtdiBAsrZEIPatRNxuUxtbIU
DKw4ynaGWtQyTy0UrDh6QQClIVcF4foAWJkzcwA05dz/ANl1OIU0sU/CBAiLG+L4LHot9zgPqLxH0O/+xKhINYhFrL11sqHT0Res
W8ZJvk0tGtVCNlyg0S7Bd5bjhxBCqV2jvT6LT0WOMIJCSDzau/ngs0a33QbjiauDQ1KG1ZdFne47R7W6gTJBiNSoehXvu0CXNQiI
IzWGKBbszOq9VXL1hfS75CGypqtHQ/b1X0oKeNsvv3fg7sTeI017BLHMvvC9hQWf+l+R5iy2jfMuTqSxTQ/n6Ym5GkwHK2JTjRoW
XocdHvDWcXZd92+3wbzt+GbIOz8m70Mw+Fg0l9rceYS5NAMCgOu69YQK1TB3ZO2e+0ZsTy5mp4fy6WanRslechQp5FW+IdoqDMuD
5Ij6lgAm7DvtAdtVoH8VE7YqzrW3+eJU8x9gd9m0Jo4OwSkdk1hxZJ5XSFiLRRBnAmhqZXrwCwY3N335hSohG9bXPQCu8yT4EKGx
x5YxZTMv1rqI5WOjXeH9CFmKBpF10WFJQm6XZ0YgwDRoisSpQwWRHRoeIJXbUi71fuJaVOuhsDTS5AawyKugXwHc66m032B5AXyH
mo1jutevWTshOwpoZUpNFHzCml3MgK6XxuMFlWDaRpSJwPyzc2AfJ7b1TEzw4XbxGui+0pVmS0WyNCw21pDFNKGEdR4mpDERg9Ds
avgm0UKyhDnTe/Y99oGblxcAgcvP51aFNi4IL+zBmLdF8vS82RSFh0G79bwQQZVyvK3ZTF5tV8m55fBL2nIRx6d60hg9+HyJVLvE
+afqWLSL6y6+ItGcUkcX+jEtittt31veLAymiDh4p0iDyU9ZS3d2HUjgLd39yWUh02iLQNQs9peGVjl97n7RHCA3vyL7IZ2aUMda
F7oXl24j3p8y2SLrzBbEThByRdi+87nCB4UIZVcHdAKR4hDn6nI8HQ9AEGNBlOdXT/iXSpSjP6jW0IHcB+UPOQrhOOjozVm2wdvO
j4lB+ZV3hW8wOA8CS4BZLZq5ZKnqA95mKlaekW6bhdc6Gk7U4YGCAttpbB8m5LYPU/cB7hMwdShyWHzK671aC4OhUeWdNIFiEUrb
hhtQSUFFWDBMyMAZEHaFQBuQNa/aLRtosnFdEuc0I9yWz3fBZArVsVdFnDDmfIWagFUWWUjGOvEDeEdu7kClMQyKY4crYNrbaS8T
Czs2HVZZ6vUaDYdAhMRyKFnTD4+nxOvr2iWjkh89/jNpsXwP2jZLDHsui9jGd4NvqegOhKneU/zTnl20joUoFqugEqjkp8Eb9Pdj
Ss9E91KtlUWVgXzr8xMW/YJ3a10fdmL0L7QORzw7wLAVFsyxPSF3ulzKQFxq1OGXshvjCdpnpXbl5InVDmrPcgTE9m4PMsKtlDQy
zRZbesUDYOWA2P094QrVlDQP3DQlAmq8sIdos7aTE+3JmnmJHbalrEVAoFAIMSckdheL1jbpcm/NxlYGijWtmE7k3IAox9f2Izg7
mtbd/BTlhjBmNZ6nTbv3jJi63q+/M1ofEP3rLyRnXAsJV4oGHoNEGGGq3DRXuU2dnDmlYzAWgUHYewTIqoDcQ9AOsJYANJK7Akuz
GSJ3uCI6BnYFI4Sumw5liYs3RRrPCLLiGx6gPHdBTvmfW1Y4HYdj2i2TyrZmk7yd3oTnH7mmuf8AD6G02/AxLWtqryH1Ur4x9+RY
zpsGk56i/knPLttNN8QHc8mRj5TWs7WTJ9OY8tz3ZiRB7kWZl+z2gDqNmn/kwmp2hUDnUeGWdPT3lhhyaQZ85RC5QF0GImpo7S1p
0yhKdndzDyyHJLlru/8Atz/2gy3H+947Q8f+pXug50i1tnOUvLl2OYhbJ5WVPlidcfT04F0YqHI7sQGyZd5SGp0gzGNjSuy9CsQS
jn3w8ZtizkIHIq36jniBZ0Yy6YOuh4O7LOZKcNh5++8MukoMTQzPZ3JaIYp7cIBoYzrWeZ0vJdOSVPSUK0a3dNMwAN0FcOh0Td4D
cehAZxrG+ijqut5XsQj0VdNCjcMBTujljAYK84m7b81bPUDXR5graE1QPo2OgR0DJXuh/cExspfx09dvxuhtFXQA+bjD6meoJ8Qp
8Du92PklOu5X91+3wQwYgcBDsQcHlr5iJsHw7H79oq6aR2YuXvloy9pnLkaT5gASjC7/APJRNd8wGV/6hCddE6xBDnETa1PQVajV
2giU0nMRsQrd9yUEXC6KfMwIvO0GvN8TEC0445ljomhADeUc6tsKqtOJpGR3VxVDKUsfoh7k+WDdWqzfEY2bk3cssKoN2q8t23vf
vCzFxTK1E7mO/MLgbEXvFvhycK3jkyeRjg/2bPiZES2o8t7NexbRMJqZ1LlCZO1K7Owe6zqS9b4rsDXS0SzPaGbnBH6Jh8QAxauL
VDnON2mNCHrjjpJ3NtuoNob8WwzUboxwaNMAWZQVwAHzcvHTrkqJsUeyRX6iX1/LJ/f5kuB0p1ofiMwCh6KvmDhVoqklcTeazkb8
R82hLoiF2U/9jrMVmAX/ANEyjg8iAYeBlRC1i3zDmuTLzKgKAH6Zk1KGaKPxEIglTM5PiBKqGdyKNjeIIRjNKCfEwlIb8zeG3dkN
fRDRiRvBKsXUH7gdwcsR00yz6hWBglwLVODkaqmHjRp2Oj/bkTgpaqtRE5KY3XV1idyuc9bgYvN/uH+S9S6Wj4hiMvUY7gWQIXUM
C3Y8hD1RErFQAozpFdPhKxqfdEIwqMPcqtu0GIXkzzZcp0mr1UCvcilJZA8jL6z9Crr/AIjZtB+XyI2XQ5N72D5SBQDsV6E39K9N
My6LP2TR81GPLpPR+wJdl+a9Gw5eJTa1G1L+X3HHVYGiag+cR0wpvGOSXip6PPeNwvhNHqR1fhWPDzMPUjQ45IkGwa8/+xV4mOiy
WHsRyZibxdIKm05qZHvLvSWXmUCsBvG1sNCZlp9oRQFIEBxLzB0SyNgOSn7hLaN/Yhvqbocu0zavMoAtUEpIg1mxLBaSy3gHm2KD
LgNbM2+TyQnG8vIjFLOP4OJnjdd7kMg12vX4qn2JWAFmFwpyRyUyj+kNK678rHY5kNO6yhtVHrWDEfC0uXgVBCovJh6NKgNeXeE9
iaFSDSJs9JXuvRoV90hPbear/D2B8QQTQXqXb4/Jv6MaVBMbI2fJKU0p5Lr7lZFNf5GieiC2BJ0G34GNTGQXrdN/rxF5TSGeRpgx
HYcJMUvJgZRVykd8O51IrmvDRvG0Pt6x0fUUjyhXnL6bVDTmzBtMpMy/aOuJdZaJcpo+Y9JQG+rNWapWJWYtAvDFnEvpwPxMuMs8
XMEOn3mD12EyQt+P/UAABBd5Wwra6F9eYVHVWWdTZ2wzerxCumnbG9kpAOphlszp9DD7wNa6hzgkYwXwKVY6sHcPgvG4PRI9ihed
Vuuo4jk3NxNo2gCSl5MdKb7eCAkWZKvSEerw5r7X2haCJ6r6B9/xz+G8MrSa/wBGo8TUEK+T4KePRzpfflV9LCMoQciM/coT2pe0
SNOk4ZmH6jNab4EFzdDoxqGy/wBLD80lhXmrfEyPVL95vUuZ2OY7dsjcZiOHE6G3eYkUuDMPQzHiVPmSFVmUT0H7lTGwTA6xPSqc
R1as6na5g+oYGseUovUbrzKVX9AlOsZoLXsZlhpGvoXDXuV7R1xQKffSdkKLPEwljnUl3boiZ3larCCo0181KBRhMOQs3gxmJumu
mpmuoFk1gTpnI+X7EUBddXyXmgEsyIhxxo1yREodcNm0ERDV9rOVG6wfBhYtVFm275jFWfJ9IiFrpZ/UCoUGkdvxa59MSjeiv/qe
Y+KCN9WvJZ5hpZDO9uuyhlxtlDQO/nHtzFrR6f5GPBMXEp2qBud3+y0ABuMprVuJ+mWJFazvDNNuKw3YSgtiiZAkNMzHwQnbOGN3
cdLltp3Y4i4uVDu5Zc3g4lxdrmBbrL4O0dA3imzwah0AMqu0sApVVVr6UPHdosvkxoEP1LLCqiFz+0YFRLKIC9OdBRclI0uctCOW
fqfomC7xD7qBGf5s1i0SWSWB6Ql/gS9eSPtSw1nIoNmnS+klVYKXSpqWouLDYoUVBpUGNOIByJTbfFQaLnX9oRGYmqpPxAN4cR8C
TfXnKn7lLVH9WhCGNESvnSKrBKDn9CNHVIaY9SX6p6H4wbPqVu0Q4dzw2Rlb5Zg8NniWDaw/w3faUJNacVdevUyRNrpqGo6Q6S94
az0BxMCrHxKb1PaJdp0MRMNxrxK4UTRNYdLTFouAtfWF+kEFvm7D5qZHwdfMIKEXKC3Ql2KtILhCFNy5Ruy1eIs1nCm82CYC3E1a
HtHzzm+iFZhyv7VLA1fzZgZKnVn6IwCtv/50re3n+4aV2Gy6iqkYtui61lZowuu1I2nJed4urQAcBQFrQFAGCHZL1fkwJXQjPlIE
/grrFOJ3n6E+WH7cHWR/LNz2lR9JAHrYD4uXFLZP+4sYcnHCORiEzA8FVXAu2WIN/LNzRc4/RI9qm3+mJWxXiUIqCJYVYyjsPNTv
WGozhkBdFEt01jlAlJqJqQshDRIf5V4ZcjUTYaPdyvf13m/pt65xjycmh4afLMhKHIAC7aafLDEs97QK0ByxHucUVlXi5dsLp+uJ
WpbuX3ErqPxvYywdG/x5luiAe6sOUvWkfYIJapra/a2OFtsJ8mDsf0p4NQ71/wA4SeG2r5SaUPhFFIcUJM5A6u/Up9fuf3SVhS8V
a9lj2W65fxDUp8jP3Fk7Kf7l5ac/5Mc5Scq9iFilz+xhDh3E/KTHdq/9xml6u/QilAd/8w1j/wCWbny/PpCY68/jmAZTvAF0oaYe
THQZ71ir3eDAqai01qA5UXKBKY0jUrWy1HT3CIsbn6LB4xuuU94ki/vQvgpaaxbjhTuClo1Yil7Qi6DIltjpUrs0QoCrXO8RcRSa
BTg4GLUJVbf4CW21UWai9DTtAu0UZCoXlcq7qs2nwZjqWww6P8cDq5vJIHeqfPM3/HvCDAuKLOLUIyUu+T4DDdDt97qQY01sr3Ri
HKTVH4CR3Qu6irSo0BPu1BK4+i9i4g9++pCLUy7z5MdAHA+girntk/FzLebnKGlGJRyO95LELAumqaeGDKZ1GD3DFfDNfMl7QdoF
G4uCsCGqgExs259iCf2xwMa/nPapa0PW+xHKXo/UyyBOtgfE54gIVYAjk5mAPo/Yofk1I2AFaXQdcXBxURAtCA1QAKu9xseYPn/p
RvtGxGnVLszepKcODpi4IGWJX3aq07787491S3uhb6sLYsFLeln8B3iFWgvUlYihoC+cSMEzI7YwewTWKBv7MAvSBWrgMus1MQWj
eo+q+SKDv2692BQIlsE+9TDyvEwYNDBN/TxK6RhDOEeMI+iNMuktvVrns3B71wxBpJ6DVvge/Bi8l9k/AzfX8rzEgFEbEaqOhao4
r29Tf33jH+RQ5FDDf33hAsZo8AtXsQjV5B9gBEi/7dPDb4lTuFWPCHzLB/4ob9SPqj1C35fmOKq6F7lMsTmhdkKVZOo7/AfQ1Hqv
vNQEKOiADhpmhDYiBGlaJgNrtE9AZWKUNW12GrmBDS2Ni7uFfZPzEsN73uSHCt3tPe2FAkaWPu3lgBThpSgZnJ7BDgVeWo1TGnAL
V8XHIOcbOT4o8Qo1wcx3q3ZSpF+Y8TRcxOWrHfV/EI0Od/R83XVlPLB0jKFTP1GD3SHcDQUUZG1ccoBlfaKcvmaBR8NMVQBtAPVW
l5BkQsGlRq3G/wBwSh/SlCwbeBXxL4q1jeDBntBaI/YHugeYULvzZZd/lGYxjW5aRfSr8DKLR71PfqoAkndUKB2AIUPwwiY7mT0c
KxxuWgO6qsTE0SHZs7P4XGTG8O4PlYMlMLqNP16Gk3/DeAQBtD+zat4I0KMinjpOa5LGMyrDYWZk0s9oHveDAUU+1epsyKACgCby
qlnC/VRCJaA1Vvhx0ZVBa6xAZkqeClxna09DF1GXVc/Wlg2IQjWoNq6Uyhtqg03iueUomoqw9ElnfG33DLgSNlX5IgY/sp33X4jm
dImXaMbTtcGC/MW+0F5uKOpd8SgwaGCG2tUcL/aB8OrYwewQ4RXsVAeUDzFLC2+THWj6KgpBAsJQcIp5gsAgsYblLfUmShjE1zXT
jo6jbxDsKg+wfs9sGzSPDNNwOTFm950ISHLRgriXN4VS4AtWoXdXSC2BxA4RIrdIaoOLoUN4bZ2NW3f2zCpw8f3Was7ut39aLx+B
kYQlLPRXa6PGYepcFL/ZfcoWmGzUAGzZQrRrvNdRTXLvLHNHQP8AIQ8tQwSfYtKf4W0BRjQ6E/Z/HxM7+m8foT6ws27At7JHXsly
KTso9ofZwgDnUDzI5i5bJFz33yRAA6F8ogSK1Fn2EV93gjUi03OZ3mH5zM00vRs9OVqJyoD3SAAEDsM8lnmdpdKTIZKMzojwMQUc
cRM5qssdYGS4rhBRbYdVXK8szynW/XcEGrBqpPYEuNA5Dak9h2i3EUNPvEI1qYfT1rqzo3+gNq+0K6XufELyQ4tmA8ehFvgvbCwU
dQgwZF7ZSLyOrkkWrKaswu6CIpFBPlh1gcbyDegTi3MVyLsYsMQ4OHRsqhvb01rGUa1p7uBwF3shCc3QfkR1j9X7SVsQOrd6DwXo
BqjAQX4wIwamDLqqtyjcRYGY+RZlyhR6Xn4h2UBVxcotXAW/SElBTwDKrsjjR0NFSr80PRW0BGmgGhFANgAIhyQXRaTKUMdCbVAm
E8dGs+UheIhuyiz4SlCi89l9JN/Tx6X+Da16f5wGH4FXfOx3UINGDVOivWiRB3vkmqohs+4SrAaF15wgGf8AOsJso2BVxKqAVVYp
e7V+YuGWWZxYAfhcEEPq2sMi6NHmAYhvZgmukbsUHljzEobUFq23VkpV2in2y31tYvWfRdm/qvBrjfaA3COtEQa/A/8AcAYMYWf5
bmUbHXCpLtaeZaPkMbcrGy55bJ6G0pa6C0+R8Q2KPEpv0I3rox3cmRBPNkN1SWaoZX2uPzGycAhOUR9Fmrz02ltfcHWLly5jOy+6
YfEOGik4RDPAxdxWpfa4LekuCAKAGESZ1bn3Z/8AFSgKAO0oDYSYsK+ll5mqqn5bj1ByFnGkNP8AC2JOKQ2p/YIeOAK6zV1Ee/ia
ZnwpGV37EVUCJaBqvEuoWKA27IWgG6S1z230ZFJmRBBQAIglSiwEciHwyjKsR4blYO+2BX4MFiy0/jqejf8ALu4l/DQdWg9j7x+B
71+fCEXPYG/qYg7piiDyioQ4vWGsZ/HEGX3RWYwq4C1+4k5qIUTCHdC3ugwiDw/fG9LuybWelktqi/jFJdYGIiXZdofbUJlirpqq
O1AjSxrMjN0tFbfvl9EfnPI0EkZUGu0FJZvlJlNLAYsQW65iLEJGqNP+bhCcEbkp3ZBoQhVvW0s+JIXItjKlbBCiFySoJLVbhjAY
CgAMEdovQcyydxthImob1lR8pd3M15kqkrq63bxKAywFEwBwHlaHYID0QeUEXBv8XMgJByFodrCIVJclveAFk01Q/QSqDVRX4YgC
dFXuLprrhzAlfWy/eihU4+hkpt+F37CGquaUfSjkWWQFAAvcriso1xyb58Q/OgGQQDI4WZCLp5elNqu6tvo5RyVGkFYiLJk0Lalp
23D97hO5FYWBCwAvpEpf8w9oxU6+m8r1MphC4OV7GJaKs7Yz7rGNhhlOA3RXkQZQRcXOqbakbG9l3s0PvMso0rfIvqKNHslMJhCt
28I1BpUU2pzMlzmXm7ctR2ILhKs1EiegUFra0tWArw4p97z6h0Np6y9gAAjghWg5YisdBK3iAIrH9WFbyi+YMJ21C0otFoA8SoCa
FP7EDMQotodJcksnYAy+hcrLUaXtaIGipAusbailL4Z1VLvehQkMqy6GYZi+o/UTsJyg+YXeUUk1W7QXvoTozvNu4HhhKkcsokTi
JdTo4HymKy2i+fiWyY3gOgCzQXG7TvM8a4fcwlUfSomSUUHDUeTaljQDAVuektax0KbtlLGmmqCIWiD3JUpmDVDzBP8ASDS+2pMb
97f6h/xz+p/Y13YZZBwA/i+Jnu5J+o+OVkQYXf8A7J/SfvGvDt95YfZn6cNU/wCDSYRXY/TOkcmpWWYTBCBog1fo4m8xOnpm5AR7
i9qIuvEyFHSu9nzDyMHdQe8ePRaQ8TnH76Phlrq+qgSkIXCkqwE7IY2UmqbViG8pdCeI7fUh0edoKcLTI0drYcuQ5FzbBcWhlVVV
1ixXBe4wC0d8LZBbClbl8ID5l5gNNbASjxoiPshBHhqvr9kSOjcQ3VBy2+R0wYhLLhe71lsI5GrLacscc3/OUv8AJalD2JZJHVuP
dS1JtyhcQ0A9mD1af0BPg3/zg+Ecl9kmrdo/3Cfun0Me9ufqJSPlj9w5kH81rKt1j+uoGyxwfpIo0Pn6jL/94bkAZtcH7JTpP9es
NzeL+ncD+X7R/cncBBvIpIDlkvO6R0fekSxG8AWjNNAie5FBb3GOHvPrhT6J/KH5jXub/c+Xhf3GnUvvP/gSjg9oY/PAXsRKv3Dt
e1kOAbaLGsXujyxTrUu7AQAq4DlmhWjcPva3wzb1EbYAUJENZNdVNRVopnxPtGlsNLte6XA22edqIwoTM7COBOleldIA2HmBaK9F
z547+poKOT+4lJQ9L9LKx74z4is/mLVIVbjev7LA+Rz/AJU3vnU+FEXdOP8A3m4U3s+RA1M/u1h1PP7KGacOv0gRrFdST42d+1jc
oCvbfpVP7hfefM3P2xE5TuQA0A7TP4X6gGXXysvo1ZTAAMQIGU2DjQIyeRQ4Ubf3Ppv/ANcVLKfsS96DzGqwCTlsfa3kmIkyZ3A8
KPCW0XYtlYnTJiksHC1GIlBXdWk8qymXwvAv6mka/wBcSt7mftZSA/8ALVPYjD/REWd0q+WCgtrWv+o6mza/4UNMo4+1cMCg0rfN
JWE+z8XKbR5H6j5VT95LfMfyu4FQPH1ZAUtdqPpn97ZyylqHuSqcYly/+e354Ms0TB0Hwe8YCbrx53T/APCBsjSY7nHRvvxNf+20
YBItFbBl96eGUJDEgsXLgNHywGrg9datjalNW0ypAX8Gs7t06SmvK/fd0uPGty/3mj7jcahW7+dyFbJn25r8RWPIH6gAAI2NTi7x
7TCmBdy9Tc4TDKBqwLvH2YekLobI51FjlYF1zDGgHaZ6/wDfabyv+lmn4B68Pl6aw+SKevA1f5i4ZcDq5d3pofP/AC2uJNofgCtB
TgDdjXWiBtXLA1ofYQ4Au5Svk9oTaZkB7rL8TqS017/rWNOzzP6T4ZbCfZ9cIdq7fg0FLRT2eTo4mXRqzTdF1dHHDtLDCUCuj1Oj
8TPQaE+A1XfHWb//AJNvy39K6h0D50CWfPkzPpd+rntEY2n2x7Omv3ESAweC4G327/jvNozzPv8ADb0fTaL7mvpqGdbpiapcqsvT
J7EUUz+m+gjdj3r+ZfpU36fjRkagpC4MD6mp0fCRIkFBVuzafT1lnazcVem/jZ0l2w1M9sw/hv6af9M3+W0xh1STwRBfUAK+A7Fv
UmpPM4H7X3WBObCddh9nPaIkRtTavLyzf/jtN5t6b+mPTf07+nj12m/5VxNp15PbqdJtybQP19/ZLMR507rr8x8zZzP2f9IsL1j2
IMe9fl0m/wD2NPO6a77HmK6mLBe+g8XAsetWU5X9sOHDFrE76+FHWUjbUwPAYPTf13/5bw/Db03/ADxcxVzb8NvTk9K8djR8wNC2
r+V/T4jlpMq06Lk8kVGubaL11viPO2aficPvGjrrA9nSHJp/xv8AEglaOXsRlJ//ABFvvUYDH/wGXyzhn1/A3Y5oAzF2P8JVXW/Y
AY8tvpv+Hj/jv67+m86+jp6bfjfriYud/wAtWPCB2SEh/FHE7c+9y/cavyeXuRXejIff/oiZSa3fqfEVVXgp5KZdo3Cj5E+YE2U3
+rbi75j/ABj1LnKfqaa47zs3MB2JMrc9z/1HSucgPyIsIDuDwGACo6P5X6ioE7ofZR8Ry0U3/wAUOQrav4B7XHl9oHyMHgjdD1ev
n8NvTv6b/hv/AMNp4j6Yl+m//K+Py39Qbg0Sk8w0Cd8+5CgHuq/s+IUW26w+xgxZcfTDPhC/sqBYjov7mr9xzhHhgPwf+4E166H6
YLa3j9PL8S2sHy38QNOtI9iiWabtPmZ+YjadWL3fw6/jz/xJp+O//Hv+O2n5dfyrj039NTMs2PiU29iV/wCCV/4J2x616b//AJa/
HE7S+PU/E/Df06em/p19N8/8dPy8eu0x+GN/wv0v10/47zf1uYm/pfqS/wALsz6X63+Fy/S/TH/O5vLl/jf43+Fnrcv01n//2Q==
"""


def brand_logo_default_bytes():
    import base64
    return base64.b64decode("".join(BRAND_LOGO_B64.split()))


def shop_logo_bytes():
    """ไบต์ของโลโก้ที่ใช้อยู่ (โลโก้ที่แอดมินอัปโหลด ถ้าไม่มีใช้โลโก้เริ่มต้น)"""
    custom = get_setting("shop_logo", "")
    if custom:
        try:
            with open(os.path.join(UPLOAD_DIR, os.path.basename(custom)), "rb") as fh:
                return fh.read()
        except OSError:
            pass
    return brand_logo_default_bytes()


@app.route("/brand/logo.jpg")
def brand_logo():
    response = app.response_class(brand_logo_default_bytes(), mimetype="image/jpeg")
    response.headers["Cache-Control"] = "public, max-age=86400"
    return response


@app.context_processor
def inject_globals():
    custom_logo = get_setting("shop_logo", "")
    return {
        "logo_url": url_for("static", filename="uploads/" + custom_logo) if custom_logo else url_for("brand_logo"),
        "logo_default": not custom_logo,
        "owner": OWNER_LOCKED,
        "shop_contact": {
            "email": get_setting("owner_email", ""),
            "line": get_setting("owner_line_oa", ""),
            "address": get_setting("shop_address", ""),
        },
        "cart_count": sum(int(v) for v in session.get("cart", {}).values()),
        "user": session.get("uname"),
        "user_role": session.get("role", "customer"),
        "img_of": img_of,
        "grades": GRADES,
        "grade_names": GRADE_NAMES,
    }


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "uid" not in session:
            flash("กรุณาเข้าสู่ระบบก่อนชำระเงิน")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "uid" not in session:
            flash("กรุณาเข้าสู่ระบบแอดมิน")
            return redirect(url_for("login", next=request.path))
        account = get_db().execute("SELECT role FROM users WHERE id=?", (session["uid"],)).fetchone()
        if not account or account["role"] != "admin":
            abort(403)
        session["role"] = "admin"
        return view(*args, **kwargs)
    return wrapped


def safe_next(target):
    if target and target.startswith("/") and not target.startswith("//"):
        return target
    return url_for("home")


def get_cart_items():
    items = []
    for pid_text, qty_value in session.get("cart", {}).items():
        try:
            pid, qty = int(pid_text), int(qty_value)
        except (TypeError, ValueError):
            continue
        p = get_product(pid)
        if p and qty > 0:
            items.append({"p": p, "qty": qty, "sub": p["price"] * qty})
    return items


def money(value):
    return "฿{:,.2f}".format(float(value))


def tlv(tag, value):
    value = str(value)
    return f"{tag}{len(value):02d}{value}"


def crc16_ccitt(payload):
    crc = 0xFFFF
    for char in payload.encode("ascii"):
        crc ^= char << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return f"{crc:04X}"


# ------------------------------------------------------------------
# สร้าง QR code ด้วย Python ล้วน (ไม่ต้องติดตั้งไลบรารี qrcode) — โหมด byte, แก้ไขข้อผิดพลาดระดับ M, เวอร์ชัน 1-6
# ------------------------------------------------------------------
_QR_ECC_PER_BLOCK_M = {1: 10, 2: 16, 3: 26, 4: 18, 5: 24, 6: 16}
_QR_NUM_BLOCKS_M = {1: 1, 2: 1, 3: 1, 4: 2, 5: 2, 6: 4}


def _qr_raw_codewords(ver):
    result = (16 * ver + 128) * ver + 64
    if ver >= 2:
        num_align = ver // 7 + 2
        result -= (25 * num_align - 10) * num_align - 55
    return result // 8


def _qr_data_codewords(ver):
    return _qr_raw_codewords(ver) - _QR_ECC_PER_BLOCK_M[ver] * _QR_NUM_BLOCKS_M[ver]


def _gf_mul(x, y):
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree):
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            result[j] = _gf_mul(result[j], root)
            if j + 1 < degree:
                result[j] ^= result[j + 1]
        root = _gf_mul(root, 0x02)
    return result


def _rs_remainder(data, divisor):
    result = [0] * len(divisor)
    for byte in data:
        factor = byte ^ result.pop(0)
        result.append(0)
        for i, coef in enumerate(divisor):
            result[i] ^= _gf_mul(coef, factor)
    return result


def qr_modules(text):
    """สร้างเมทริกซ์ QR (list ของ list ค่า bool, True = จุดดำ) จากข้อความ"""
    data_bytes = text.encode("utf-8")
    ver = next((v for v in range(1, 7) if 4 + 8 + 8 * len(data_bytes) <= _qr_data_codewords(v) * 8), None)
    if ver is None:
        raise ValueError("ข้อความยาวเกินกว่าที่ QR ของระบบรองรับ")
    # --- bit stream: โหมด byte (0100) + จำนวนตัวอักษร 8 บิต + ข้อมูล
    bits = [0, 1, 0, 0] + [(len(data_bytes) >> i) & 1 for i in range(7, -1, -1)]
    for byte in data_bytes:
        bits += [(byte >> i) & 1 for i in range(7, -1, -1)]
    capacity = _qr_data_codewords(ver) * 8
    bits += [0] * min(4, capacity - len(bits))
    bits += [0] * (-len(bits) % 8)
    codewords = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = 0xEC
    while len(codewords) < capacity // 8:
        codewords.append(pad)
        pad ^= 0xEC ^ 0x11
    # --- Reed-Solomon + สลับบล็อก
    num_blocks, ecc_len, raw = _QR_NUM_BLOCKS_M[ver], _QR_ECC_PER_BLOCK_M[ver], _qr_raw_codewords(ver)
    short_blocks = num_blocks - raw % num_blocks
    short_len = raw // num_blocks
    divisor = _rs_divisor(ecc_len)
    blocks, k = [], 0
    for i in range(num_blocks):
        chunk = codewords[k:k + short_len - ecc_len + (0 if i < short_blocks else 1)]
        k += len(chunk)
        ecc = _rs_remainder(chunk, divisor)
        if i < short_blocks:
            chunk = chunk + [0]
        blocks.append(chunk + ecc)
    final = []
    for i in range(len(blocks[0])):
        for j, block in enumerate(blocks):
            if i != short_len - ecc_len or j >= short_blocks:
                final.append(block[i])
    # --- วาด function patterns
    size = ver * 4 + 17
    modules = [[False] * size for _ in range(size)]
    is_func = [[False] * size for _ in range(size)]

    def set_func(x, y, dark):
        modules[y][x] = dark
        is_func[y][x] = True

    for i in range(size):
        set_func(6, i, i % 2 == 0)
        set_func(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (size - 4, 3), (3, size - 4)):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                x, y = cx + dx, cy + dy
                if 0 <= x < size and 0 <= y < size:
                    set_func(x, y, max(abs(dx), abs(dy)) not in (2, 4))
    if ver >= 2:
        num_align = ver // 7 + 2
        step = (ver * 4 + num_align * 2 + 1) // (num_align * 2 - 2) * 2
        pos = sorted([size - 7 - i * step for i in range(num_align - 1)] + [6])
        for i, ax in enumerate(pos):
            for j, ay in enumerate(pos):
                if (i == 0 and j == 0) or (i == 0 and j == len(pos) - 1) or (i == len(pos) - 1 and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        set_func(ax + dx, ay + dy, max(abs(dx), abs(dy)) != 1)

    def draw_format(mask):
        data = mask  # ระดับ M = 00
        rem = data
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        fmt = ((data << 10) | rem) ^ 0x5412
        bit = lambda i: ((fmt >> i) & 1) != 0
        for i in range(6):
            set_func(8, i, bit(i))
        set_func(8, 7, bit(6))
        set_func(8, 8, bit(7))
        set_func(7, 8, bit(8))
        for i in range(9, 15):
            set_func(14 - i, 8, bit(i))
        for i in range(8):
            set_func(size - 1 - i, 8, bit(i))
        for i in range(8, 15):
            set_func(8, size - 15 + i, bit(i))
        set_func(8, size - 8, True)

    draw_format(0)
    # --- วางข้อมูลแบบซิกแซก
    i = 0
    for right in range(size - 1, 0, -2):
        if right == 6:
            right = 5
        for vert in range(size):
            for j in range(2):
                x = right - j
                y = size - 1 - vert if ((right + 1) & 2) == 0 else vert
                if not is_func[y][x] and i < len(final) * 8:
                    modules[y][x] = ((final[i >> 3] >> (7 - (i & 7))) & 1) != 0
                    i += 1

    def apply_mask(mask):
        for y in range(size):
            for x in range(size):
                if is_func[y][x]:
                    continue
                invert = (
                    (x + y) % 2 == 0, y % 2 == 0, x % 3 == 0, (x + y) % 3 == 0,
                    (x // 3 + y // 2) % 2 == 0, x * y % 2 + x * y % 3 == 0,
                    (x * y % 2 + x * y % 3) % 2 == 0, ((x + y) % 2 + x * y % 3) % 2 == 0,
                )[mask]
                if invert:
                    modules[y][x] = not modules[y][x]

    def penalty():
        score = 0
        lines = [row for row in modules] + [[modules[y][x] for y in range(size)] for x in range(size)]
        for line in lines:
            run = 1
            for a in range(1, size):
                if line[a] == line[a - 1]:
                    run += 1
                else:
                    if run >= 5:
                        score += 3 + run - 5
                    run = 1
            if run >= 5:
                score += 3 + run - 5
            text_line = "".join("1" if v else "0" for v in line)
            score += 40 * (text_line.count("10111010000") + text_line.count("00001011101"))
        for y in range(size - 1):
            for x in range(size - 1):
                if modules[y][x] == modules[y][x + 1] == modules[y + 1][x] == modules[y + 1][x + 1]:
                    score += 3
        dark = sum(v for row in modules for v in row)
        total = size * size
        score += ((abs(dark * 20 - total * 10) + total - 1) // total - 1) * 10
        return score

    best_mask, best_score = 0, None
    for mask in range(8):
        apply_mask(mask)
        draw_format(mask)
        score = penalty()
        if best_score is None or score < best_score:
            best_mask, best_score = mask, score
        apply_mask(mask)  # ย้อนกลับ (XOR ซ้ำ)
    apply_mask(best_mask)
    draw_format(best_mask)
    return modules


def qr_svg_data_uri(text, border=4):
    """คืน data URI ของรูป QR แบบ SVG (คมชัดทุกขนาด สแกนได้)"""
    modules = qr_modules(text)
    size = len(modules)
    parts = []
    for y, row in enumerate(modules):
        x = 0
        while x < size:
            if row[x]:
                start = x
                while x < size and row[x]:
                    x += 1
                parts.append(f"M{start + border},{y + border}h{x - start}v1h-{x - start}z")
            else:
                x += 1
    dim = size + border * 2
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {dim} {dim}" shape-rendering="crispEdges">'
           f'<rect width="{dim}" height="{dim}" fill="#fff"/><path d="{"".join(parts)}" fill="#000"/></svg>')
    return "data:image/svg+xml;base64," + base64.b64encode(svg.encode("utf-8")).decode("ascii")


# ข้อมูลรับเงินอ่านจาก .env/ค่าตั้งค่าในฐานข้อมูล ห้ามฝังเลข PromptPay จริงไว้ในซอร์สโค้ด
SHOP_PAYMENT = {
    "promptpay_id": os.environ.get("PJ_GUNPLA_PROMPTPAY_ID", "").strip(),
    "bank": os.environ.get("PJ_GUNPLA_BANK", "ธนาคารกสิกรไทย").strip() or "ธนาคาร",
    "bank_short": os.environ.get("PJ_GUNPLA_BANK_SHORT", "KBANK").strip() or "",
}


def promptpay_payload(promptpay_id, amount):
    """สร้างข้อความ PromptPay (EMV QR) แบบระบุยอดเงิน รองรับเบอร์มือถือและเลขบัตรประชาชน"""
    from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
    digits = re.sub(r"\D", "", promptpay_id or "")
    if len(digits) == 10 and digits.startswith("0"):
        account_tag, account_value = "01", "0066" + digits[1:]
    elif len(digits) == 13:
        account_tag, account_value = "02", digits
    else:
        raise ValueError("PromptPay ID ต้องเป็นเบอร์มือถือ 10 หลักหรือเลขบัตรประชาชน 13 หลัก")
    try:
        value = Decimal(str(amount)).quantize(Decimal("0.01"), ROUND_HALF_UP)
    except InvalidOperation:
        raise ValueError("ยอดเงินไม่ถูกต้อง")
    if value <= 0 or value >= Decimal("10000000000"):
        raise ValueError("ยอดเงินต้องมากกว่า 0")
    merchant_account = tlv("00", "A000000677010111") + tlv(account_tag, account_value)
    payload = (
        tlv("00", "01") + tlv("01", "12") + tlv("29", merchant_account)
        + tlv("58", "TH") + tlv("53", "764") + tlv("54", f"{value:.2f}")
    )
    to_crc = payload + "6304"
    return to_crc + crc16_ccitt(to_crc)


def make_qr_data_uri(promptpay_id, amount):
    """QR PromptPay ตามยอดเงิน (SVG data URI) — ไม่ต้องใช้ไลบรารีเพิ่ม"""
    if not promptpay_id:
        return None
    try:
        return qr_svg_data_uri(promptpay_payload(promptpay_id, amount))
    except ValueError:
        return None


def allowed_image(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_IMAGE_EXTS


def save_uploaded_image(file_storage):
    if not file_storage or not file_storage.filename:
        return ""
    if not allowed_image(file_storage.filename):
        raise ValueError("ไฟล์รูปต้องเป็น JPG, JPEG, PNG หรือ WEBP")
    original = secure_filename(file_storage.filename)
    ext = original.rsplit(".", 1)[1].lower()
    unique_name = f"{uuid.uuid4().hex}.{ext}"
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    file_storage.save(os.path.join(UPLOAD_DIR, unique_name))
    return unique_name


def save_payment_slip(file_storage):
    """บันทึกสลิปโอนเงิน (JPG/PNG/WEBP) ลงโฟลเดอร์ slips/ คืนค่าชื่อไฟล์ที่บันทึก"""
    if not file_storage or not file_storage.filename:
        raise ValueError("กรุณาแนบรูปสลิปโอนเงิน")
    if not allowed_image(file_storage.filename):
        raise ValueError("สลิปต้องเป็นไฟล์รูป JPG, PNG หรือ WEBP")
    head = file_storage.stream.read(12)
    file_storage.stream.seek(0)
    if head.startswith(b"\xff\xd8\xff"):
        ext = "jpg"
    elif head.startswith(b"\x89PNG"):
        ext = "png"
    elif head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        ext = "webp"
    else:
        raise ValueError("ไฟล์ที่แนบไม่ใช่รูปภาพที่ถูกต้อง")
    os.makedirs(SLIP_DIR, exist_ok=True)
    name = f"{uuid.uuid4().hex}.{ext}"
    file_storage.save(os.path.join(SLIP_DIR, name))
    return name


def remove_payment_slip(filename):
    if filename and re.fullmatch(r"[0-9a-f]{32}\.(jpg|png|webp)", filename):
        try:
            os.remove(os.path.join(SLIP_DIR, filename))
        except OSError:
            pass


def remove_uploaded_image(filename):
    if filename:
        path = os.path.join(UPLOAD_DIR, os.path.basename(filename))
        try:
            os.remove(path)
        except OSError:
            pass


# ------------------------------------------------------------------
# Storefront routes
# ------------------------------------------------------------------
@app.route("/")
def home():
    grade = request.args.get("grade", "").upper().strip()
    q = request.args.get("q", "").strip()
    sort = request.args.get("sort", "default")
    sale = request.args.get("sale") == "1"
    new = request.args.get("new") == "1"
    products = [row_dict(r) for r in get_db().execute("SELECT * FROM products")]
    if grade:
        products = [p for p in products if p["grade"] == grade]
    if sale:
        products = [p for p in products if p["old_price"] is not None]
    if new:
        products = [p for p in products if p["badge"] == "NEW"]
    if q:
        query = q.casefold()
        products = [p for p in products if query in p["name"].casefold() or query in p["grade"].casefold()
                    or query in p["scale"].casefold() or query in p["category"].casefold()]
    if sort == "price_asc":
        products.sort(key=lambda p: p["price"])
    elif sort == "price_desc":
        products.sort(key=lambda p: p["price"], reverse=True)
    elif sort == "name":
        products.sort(key=lambda p: p["name"].lower())
    grade_counts = {item: sum(1 for p in get_db().execute("SELECT grade FROM products") if p["grade"] == item) for item in GRADES}
    all_products = [row_dict(r) for r in get_db().execute("SELECT * FROM products")]
    sale_count = sum(1 for p in all_products if p["old_price"] is not None)
    new_count = sum(1 for p in all_products if p["badge"] == "NEW")
    return render_template("home.html", products=products, grade=grade, q=q, sort=sort,
        sale=sale, new=new, shown_count=len(products), all_count=len(all_products),
        sale_count=sale_count, new_count=new_count, grade_counts=grade_counts)


@app.route("/pic/<int:pid>")
def pic(pid):
    p = get_product(pid) or abort(404)
    found = find_image_file(p)
    if not found:
        abort(404)
    return send_from_directory(found[0], found[1])


@app.route("/product/<int:pid>")
def product(pid):
    p = get_product(pid) or abort(404)
    return render_template("product.html", p=p)


@app.post("/add/<int:pid>")
def add(pid):
    p = get_product(pid) or abort(404)
    qty = request.form.get("qty", 1, type=int)
    qty = max(1, qty or 1)
    cart = dict(session.get("cart", {}))
    current = int(cart.get(str(pid), 0))
    if p["stock"] <= 0:
        flash("สินค้าหมดแล้ว")
    elif current + qty > p["stock"]:
        flash(f"มีสินค้าในสต็อกเพียง {p['stock']} ชิ้น")
    else:
        cart[str(pid)] = current + qty
        session["cart"] = cart
        flash(f"เพิ่ม {p['name']} ลงตะกร้าแล้ว")
    return redirect(request.referrer or url_for("home"))


@app.post("/remove/<int:pid>")
def remove(pid):
    cart = dict(session.get("cart", {}))
    cart.pop(str(pid), None)
    session["cart"] = cart
    return redirect(url_for("cart"))


@app.route("/cart")
def cart():
    items = get_cart_items()
    total = sum(i["sub"] for i in items)
    return render_template("cart.html", items=items, total=total)


# ------------------------------------------------------------------
# ตรวจสอบข้อมูลที่อยู่จัดส่ง: เบอร์โทร, บ้านเลขที่, ตำบล/แขวง, อำเภอ/เขต, จังหวัด, รหัสไปรษณีย์
# ------------------------------------------------------------------
# ครบ 77 จังหวัด (รวมกรุงเทพมหานคร)
PROVINCES = [
    "กรุงเทพมหานคร", "กระบี่", "กาญจนบุรี", "กาฬสินธุ์", "กำแพงเพชร", "ขอนแก่น", "จันทบุรี",
    "ฉะเชิงเทรา", "ชลบุรี", "ชัยนาท", "ชัยภูมิ", "ชุมพร", "เชียงราย", "เชียงใหม่", "ตรัง", "ตราด",
    "ตาก", "นครนายก", "นครปฐม", "นครพนม", "นครราชสีมา", "นครศรีธรรมราช", "นครสวรรค์", "นนทบุรี",
    "นราธิวาส", "น่าน", "บึงกาฬ", "บุรีรัมย์", "ปทุมธานี", "ประจวบคีรีขันธ์", "ปราจีนบุรี", "ปัตตานี",
    "พระนครศรีอยุธยา", "พะเยา", "พังงา", "พัทลุง", "พิจิตร", "พิษณุโลก", "เพชรบุรี", "เพชรบูรณ์",
    "แพร่", "ภูเก็ต", "มหาสารคาม", "มุกดาหาร", "แม่ฮ่องสอน", "ยโสธร", "ยะลา", "ร้อยเอ็ด", "ระนอง",
    "ระยอง", "ราชบุรี", "ลพบุรี", "ลำปาง", "ลำพูน", "เลย", "ศรีสะเกษ", "สกลนคร", "สงขลา", "สตูล",
    "สมุทรปราการ", "สมุทรสงคราม", "สมุทรสาคร", "สระแก้ว", "สระบุรี", "สิงห์บุรี", "สุโขทัย",
    "สุพรรณบุรี", "สุราษฎร์ธานี", "สุรินทร์", "หนองคาย", "หนองบัวลำภู", "อ่างทอง", "อำนาจเจริญ",
    "อุดรธานี", "อุตรดิตถ์", "อุทัยธานี", "อุบลราชธานี",
]
assert len(PROVINCES) == 77 and len(set(PROVINCES)) == 77

PROVINCE_ALIASES = {
    "กทม": "กรุงเทพมหานคร", "กรุงเทพ": "กรุงเทพมหานคร", "กรุงเทพฯ": "กรุงเทพมหานคร",
    "อยุธยา": "พระนครศรีอยุธยา", "โคราช": "นครราชสีมา",
}

THAI = "\u0E01-\u0E3A\u0E40-\u0E4E"          # พยัญชนะ สระ วรรณยุกต์ (ไม่รวมเลขไทย)
PHONE_RE = re.compile(r"0[0-9]{8,9}")          # 9-10 หลัก ขึ้นต้นด้วย 0 เฉพาะตัวเลข
ADDR_RE = re.compile(rf"[0-9\u0E50-\u0E59A-Za-z{THAI}\s/.,\-()#]+")
PLACE_RE = re.compile(rf"[{THAI}\s.\-]+")      # ตำบล/อำเภอ: ภาษาไทยล้วน ไม่มีตัวเลข
ZIP_RE = re.compile(r"[0-9]{5}")


def _clean(value):
    return re.sub(r"\s+", " ", (value or "").strip())


EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(?:\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}")


NAME_TITLES = {"นาย", "นาง", "นางสาว", "น.ส.", "นส.", "ด.ช.", "ด.ญ.", "เด็กชาย", "เด็กหญิง", "คุณ",
               "mr", "mr.", "mrs", "mrs.", "ms", "ms.", "miss", "dr", "dr."}
NAME_ERROR = "ชื่อผู้รับต้องเป็นชื่อและนามสกุลจริง คั่นด้วยเว้นวรรค เช่น สมชาย ใจดี (ตัวอักษรไทยหรืออังกฤษเท่านั้น ไม่มีตัวเลข)"


def validate_full_name(value):
    """ตรวจชื่อ-นามสกุล: ต้องมีอย่างน้อย 2 คำ (ชื่อ + นามสกุล) เป็นตัวอักษรไทย/อังกฤษเท่านั้น
    คำนำหน้า (นาย นาง นางสาว ฯลฯ) ใส่ได้ แต่ไม่นับเป็นชื่อ  คืนค่า (ชื่อที่จัดช่องว่างแล้ว, ข้อความผิดพลาดหรือ None)"""
    name = " ".join((value or "").split())
    if not name:
        return "", "กรุณากรอกชื่อผู้รับ (ชื่อ-นามสกุล)"
    if len(name) > 120:
        return name, "ชื่อยาวเกินไป (ไม่เกิน 120 ตัวอักษร)"
    parts = name.split(" ")
    token_re = re.compile(rf"[A-Za-z{THAI}][A-Za-z{THAI}.'\-]*")
    if not all(token_re.fullmatch(t) for t in parts):
        return name, NAME_ERROR
    core = parts[1:] if parts[0].lower() in NAME_TITLES else parts
    if len(core) < 2 or len(core) > 6:
        return name, NAME_ERROR
    for token in core:
        letters = re.sub(r"[.'\-]", "", token)
        if len(letters) < 2 or len(set(letters.lower())) < 2:
            return name, NAME_ERROR
    return name, None


def validate_email(value):
    """คืนค่า (อีเมลตัวพิมพ์เล็ก, ข้อความผิดพลาดหรือ None)"""
    email = (value or "").strip().lower()
    if not email:
        return "", "กรุณากรอกอีเมล"
    if len(email) > 254 or ".." in email or not EMAIL_RE.fullmatch(email):
        return email, "รูปแบบอีเมลไม่ถูกต้อง เช่น name@example.com"
    return email, None


def validate_profile(form, is_admin, user_id):
    """ตรวจข้อมูลส่วนตัว: อีเมลบังคับ (ยกเว้นแอดมิน) ส่วนชื่อ/เบอร์/ที่อยู่ไม่บังคับ แต่ถ้ากรอกต้องถูกต้อง
    ที่อยู่ต้องกรอกครบทุกช่องหรือเว้นว่างทั้งหมด"""
    errors = {}
    addr_keys = ("addr", "subdistrict", "district", "province", "zipcode")
    has_addr = any((form.get(k) or "").strip() for k in addr_keys)
    has_phone = bool((form.get("phone") or "").strip())
    probe = {"name": "x", "phone": form.get("phone") if has_phone else "0000000000"}
    for k in addr_keys:
        probe[k] = form.get(k, "")
    if not has_addr:   # ไม่ได้กรอกที่อยู่เลย -> ใช้ค่าสมมติที่ผ่านเกณฑ์ เพื่อไม่ให้ฟ้อง error
        probe.update(addr="1", subdistrict="กข", district="กข", province="ขอนแก่น", zipcode="40000")
    clean, probe_errors = validate_shipping(probe)
    if has_phone and "phone" in probe_errors:
        errors["phone"] = probe_errors["phone"]
    if has_addr:
        errors.update({k: v for k, v in probe_errors.items() if k in addr_keys})
    out = {"phone": clean["phone"] if has_phone else ""}
    for k in addr_keys:
        out[k] = clean[k] if has_addr else ""
    full_name = _clean(form.get("full_name"))
    if full_name:
        full_name, name_error = validate_full_name(full_name)
        if name_error:
            errors["full_name"] = name_error
    out["full_name"] = full_name
    email_raw = (form.get("email") or "").strip()
    if is_admin and not email_raw:
        out["email"] = ""          # แอดมินไม่ต้องมีอีเมล
    else:
        out["email"], email_error = validate_email(email_raw)
        if email_error:
            errors["email"] = email_error
        elif email_in_use(out["email"], user_id):
            errors["email"] = "อีเมลนี้ถูกใช้โดยบัญชีอื่นแล้ว"
    return out, errors


def email_in_use(email, exclude_user_id=None):
    row = get_db().execute("SELECT id FROM users WHERE email=? AND id<>?", (email, exclude_user_id or 0)).fetchone()
    return row is not None


def _strip_prefix(value, prefixes):
    for prefix in prefixes:
        if value.startswith(prefix) and len(value) - len(prefix) >= 2:
            return value[len(prefix):].strip(" .")
    return value


def _valid_place(value):
    letters = re.sub(r"[\s.\-]", "", value)
    return bool(PLACE_RE.fullmatch(value)) and len(letters) >= 2 and len(set(letters)) >= 2


def normalize_province(value):
    value = _strip_prefix(_clean(value), ("จังหวัด", "จ."))
    return PROVINCE_ALIASES.get(value, value)


def validate_shipping(form):
    """คืนค่า (ข้อมูลที่ทำความสะอาดแล้ว, errors) — errors เป็น dict ชื่อช่อง -> ข้อความ ถ้าว่างแปลว่าผ่านทั้งหมด"""
    clean, errors = {}, {}

    name, name_error = validate_full_name(form.get("name"))
    if name_error:
        errors["name"] = name_error
    clean["name"] = name

    phone = (form.get("phone") or "").strip()
    if not phone:
        errors["phone"] = "กรุณากรอกเบอร์โทรศัพท์"
    elif not phone.isascii() or not phone.isdigit():
        errors["phone"] = "เบอร์โทรศัพท์ใส่ได้เฉพาะตัวเลข (ไม่ต้องมีขีดหรือเว้นวรรค)"
    elif not PHONE_RE.fullmatch(phone):
        errors["phone"] = "เบอร์โทรต้องขึ้นต้นด้วย 0 และมี 9-10 หลัก เช่น 0812345678"
    clean["phone"] = phone

    addr = _clean(form.get("addr"))
    if not addr:
        errors["addr"] = "กรุณากรอกบ้านเลขที่ / หมู่บ้าน / ถนน"
    elif not ADDR_RE.fullmatch(addr) or len(addr) < 2:
        errors["addr"] = "ที่อยู่มีอักขระที่ไม่ถูกต้อง ใช้ได้เฉพาะตัวอักษร ตัวเลข และ / . , - ( ) #"
    elif not re.search(r"[0-9\u0E50-\u0E59]", addr):
        errors["addr"] = "ต้องมีบ้านเลขที่ (ตัวเลข) เช่น 123/4 หมู่ 5 ถ.มิตรภาพ"
    clean["addr"] = addr

    subdistrict = _strip_prefix(_clean(form.get("subdistrict")), ("ตำบล", "แขวง", "ต.", "แขวง."))
    if not subdistrict:
        errors["subdistrict"] = "กรุณากรอกตำบล / แขวง"
    elif not _valid_place(subdistrict):
        errors["subdistrict"] = "ตำบล / แขวง ต้องเป็นตัวอักษรไทยที่ถูกต้อง และไม่มีตัวเลข"
    clean["subdistrict"] = subdistrict

    district = _strip_prefix(_clean(form.get("district")), ("อำเภอ", "เขต", "อ."))
    if not district:
        errors["district"] = "กรุณากรอกอำเภอ / เขต"
    elif not _valid_place(district):
        errors["district"] = "อำเภอ / เขต ต้องเป็นตัวอักษรไทยที่ถูกต้อง และไม่มีตัวเลข"
    clean["district"] = district

    province = normalize_province(form.get("province"))
    if not province:
        errors["province"] = "กรุณากรอกจังหวัด"
    elif province not in PROVINCES:
        errors["province"] = "ไม่พบจังหวัดนี้ กรุณาพิมพ์ชื่อจังหวัดให้ถูกต้อง (เลือกจากรายการที่แสดงได้)"
    clean["province"] = province

    zipcode = (form.get("zipcode") or "").strip()
    if not ZIP_RE.fullmatch(zipcode):
        errors["zipcode"] = "รหัสไปรษณีย์ต้องเป็นตัวเลข 5 หลัก"
    clean["zipcode"] = zipcode
    return clean, errors


@app.route("/checkout", methods=["GET", "POST"])
@login_required
def checkout():
    items = get_cart_items()
    if not items:
        flash("ตะกร้าสินค้าว่างอยู่")
        return redirect(url_for("cart"))
    total = sum(i["sub"] for i in items)
    # แอดมินไม่ต้องมีอีเมล; ลูกค้าที่ยังไม่มีอีเมลในบัญชี (สมัครก่อนเพิ่มช่องนี้) ต้องกรอกตอนสั่งซื้อ
    user_row = get_db().execute("SELECT * FROM users WHERE id=?", (session.get("uid"),)).fetchone()
    need_email = session.get("role") != "admin" and not (user_row and user_row["email"])
    if request.method == "POST":
        form = {k: request.form.get(k, "") for k in ("name", "phone", "addr", "subdistrict", "district", "province", "zipcode", "email")}
        clean, errors = validate_shipping(form)
        if need_email:
            new_email, email_error = validate_email(form["email"])
            if email_error:
                errors["email"] = email_error
            elif email_in_use(new_email, session.get("uid")):
                errors["email"] = "อีเมลนี้ถูกใช้โดยบัญชีอื่นแล้ว"
        if errors:
            flash("กรุณาแก้ไขข้อมูลที่ไม่ถูกต้องก่อนดำเนินการต่อ")
            return render_template("checkout.html", total=total, form=form, errors=errors, provinces=PROVINCES, need_email=need_email)
        recipient, phone = clean["name"], clean["phone"]
        address = " ".join(clean[f] for f in ("addr", "subdistrict", "district", "province", "zipcode"))
        db = get_db()
        try:
            db.execute("BEGIN IMMEDIATE")
            # Re-check stock inside the write transaction.
            current_items = []
            for it in items:
                row = db.execute("SELECT * FROM products WHERE id=?", (it["p"]["id"],)).fetchone()
                if row is None or row["stock"] < it["qty"]:
                    raise ValueError(f"สินค้า {it['p']['name']} มีไม่พอกับจำนวนที่สั่ง")
                current_items.append((dict(row), it["qty"]))
            exact_total = sum(p["price"] * qty for p, qty in current_items)
            created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            # Insert whichever compatible column names exist in this shop.db.
            # Older versions used customer_name/payment_ref/unit_price; newer versions use
            # recipient/order_code/price. Populate both names when present.
            order_code_seed = f"PJG-{datetime.now():%Y%m%d}-{secrets.token_hex(3).upper()}"
            order_values = {
                "user_id": session["uid"], "recipient": recipient, "customer_name": recipient,
                "phone": phone, "address": address, "total": exact_total,
                "payment_status": "pending", "created_at": created,
                "order_code": order_code_seed, "payment_ref": order_code_seed,
            }
            order_columns = {r[1] for r in db.execute("PRAGMA table_info(orders)").fetchall()}
            insert_order_cols = [c for c in order_values if c in order_columns]
            if not insert_order_cols:
                raise sqlite3.OperationalError("ตาราง orders ไม่มีคอลัมน์ที่รองรับ")
            placeholders = ",".join("?" for _ in insert_order_cols)
            sql_cols = ",".join('"' + c + '"' for c in insert_order_cols)
            cur = db.execute(
                f"INSERT INTO orders ({sql_cols}) VALUES ({placeholders})",
                tuple(order_values[c] for c in insert_order_cols),
            )
            order_id = cur.lastrowid
            order_code = f"PJG-{datetime.now():%Y%m%d}-{order_id:06d}"
            for code_col in ("order_code", "payment_ref"):
                if code_col in order_columns:
                    db.execute(f'UPDATE orders SET "{code_col}"=? WHERE id=?', (order_code, order_id))
            for p, qty in current_items:
                item_values = {
                    "order_id": order_id, "product_id": p["id"], "product_name": p["name"],
                    "grade": p["grade"], "price": p["price"], "unit_price": p["price"],
                    "quantity": qty, "subtotal": p["price"] * qty,
                }
                item_columns = {r[1] for r in db.execute("PRAGMA table_info(order_items)").fetchall()}
                insert_item_cols = [c for c in item_values if c in item_columns]
                placeholders = ",".join("?" for _ in insert_item_cols)
                sql_cols = ",".join('"' + c + '"' for c in insert_item_cols)
                db.execute(
                    f"INSERT INTO order_items ({sql_cols}) VALUES ({placeholders})",
                    tuple(item_values[c] for c in insert_item_cols),
                )
                db.execute("UPDATE products SET stock=stock-? WHERE id=?", (qty, p["id"]))
            db.commit()
        except ValueError as exc:
            db.rollback()
            flash(str(exc))
            return redirect(url_for("cart"))
        except sqlite3.Error:
            db.rollback()
            flash("บันทึกคำสั่งซื้อไม่สำเร็จ กรุณาลองอีกครั้ง")
            return redirect(url_for("cart"))
        if need_email:
            try:
                db.execute("UPDATE users SET email=? WHERE id=?", (new_email, session["uid"]))
                db.commit()
            except sqlite3.Error:
                db.rollback()
        session["cart"] = {}
        return redirect(url_for("payment", order_id=order_id))
    # เติมข้อมูลจากหน้า "ข้อมูลส่วนตัว" ให้อัตโนมัติ (ถ้าเคยบันทึกไว้)
    prefill = {}
    if user_row:
        prefill = {"name": user_row["full_name"], "phone": user_row["phone"], "addr": user_row["addr"],
                   "subdistrict": user_row["subdistrict"], "district": user_row["district"],
                   "province": user_row["province"], "zipcode": user_row["zipcode"]}
    return render_template("checkout.html", total=total, form=prefill, errors={}, provinces=PROVINCES, need_email=need_email)


@app.route("/payment/<int:order_id>")
@login_required
def payment(order_id):
    order = get_db().execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order:
        abort(404)
    if order["user_id"] != session["uid"] and session.get("role") != "admin":
        abort(403)
    if order["payment_status"] == "cancelled":
        flash("คำสั่งซื้อนี้ถูกยกเลิกแล้ว ไม่สามารถชำระเงินได้")
        return redirect(url_for("order_detail", order_id=order_id))
    order = dict(order)
    pp = (get_setting("promptpay_id", "") or SHOP_PAYMENT["promptpay_id"]).strip()
    qr = make_qr_data_uri(pp, order["total"])
    qr_is_static = False
    display_pp = f"{pp[:3]}-{pp[3:6]}-{pp[6:]}" if pp else "ยังไม่ได้ตั้งค่า"
    pay = {"bank": SHOP_PAYMENT["bank"], "bank_short": SHOP_PAYMENT["bank_short"],
           "promptpay_display": display_pp}
    return render_template("payment.html", order=order, qr_data_uri=qr, qr_is_static=qr_is_static, pay=pay,
                           payment_label=order_status_info(order)["label"])


@app.post("/payment/<int:order_id>/report")
@login_required
def report_payment(order_id):
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order:
        abort(404)
    if order["user_id"] != session["uid"]:
        abort(403)
    if order["payment_status"] == "pending":
        try:
            slip_name = save_payment_slip(request.files.get("slip"))
        except ValueError as exc:
            flash(str(exc))
            return redirect(url_for("payment", order_id=order_id))
        db.execute("UPDATE orders SET payment_status='reported', slip_path=? WHERE id=?", (slip_name, order_id))
        db.commit()
        flash("ส่งสลิปและแจ้งชำระเงินแล้ว กรุณารอร้านตรวจสอบยอดเงินจริง")
    return redirect(url_for("order_detail", order_id=order_id))


@app.route("/orders/<int:order_id>/slip")
@login_required
def order_slip(order_id):
    """แสดงรูปสลิป เฉพาะเจ้าของคำสั่งซื้อหรือแอดมิน"""
    order = get_db().execute("SELECT user_id, slip_path FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order or not order["slip_path"]:
        abort(404)
    if order["user_id"] != session["uid"] and session.get("role") != "admin":
        abort(403)
    if not re.fullmatch(r"[0-9a-f]{32}\.(jpg|png|webp)", order["slip_path"]):
        abort(404)
    response = send_from_directory(SLIP_DIR, order["slip_path"])
    response.headers["Cache-Control"] = "private, no-store"
    return response


# ข้อมูลเจ้าของร้านที่ "ล็อก" ไว้ — แสดงในหน้าข้อมูลส่วนตัวของแอดมิน แก้ผ่านหน้าเว็บไม่ได้
OWNER_LOCKED = {
    "role_title": "เจ้าของร้าน",
    "full_name": os.environ.get("PJ_OWNER_NAME", "").strip() or "เจ้าของร้าน PJGUNPLA",
    "position": "ผู้ก่อตั้งและผู้ดูแลร้าน PJGUNPLA",
    "bio": "ผมสร้างร้าน PJGUNPLA ขึ้นเพื่อเป็นพื้นที่สำหรับผู้ที่ชื่นชอบ Gundam และ Gunpla "
           "ได้เลือกชมสินค้า ค้นหาโมเดลที่สนใจ และสนุกกับงานอดิเรกที่ตัวเองรัก",
    "phone": os.environ.get("PJ_OWNER_PHONE", "").strip(),
    "facebook": os.environ.get("PJ_OWNER_FACEBOOK", "").strip(),
    "shop_name": "PJGUNPLA",
    "business_type": "จำหน่ายโมเดล Gundam และ Gunpla",
}
# ข้อมูลที่ยังไม่ได้ระบุ แอดมินกรอก/แก้ไขเองได้ (เก็บในตาราง settings)
OWNER_EDITABLE_TEXT = {"owner_nickname": 40, "owner_email": 254, "owner_line_oa": 100, "shop_address": 300}
OWNER_EDITABLE_FILES = ("owner_photo",)
# ข้อมูลเกี่ยวกับร้าน (จัดการที่หน้า "ตั้งค่าร้าน")
SHOP_INFO_TEXT = {"shop_products_services": 2000, "shop_shipping_policy": 2000, "shop_return_policy": 2000}


def set_setting(key, value):
    db = get_db()
    db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))


def looks_like_image(file_storage):
    """เช็กว่าไฟล์เป็นรูป JPG/PNG/WEBP จริง (ดูจากหัวไฟล์ ไม่ใช่แค่นามสกุล)"""
    head = file_storage.stream.read(12)
    file_storage.stream.seek(0)
    return head.startswith(b"\xff\xd8\xff") or head.startswith(b"\x89PNG") or (head[:4] == b"RIFF" and head[8:12] == b"WEBP")


def owner_profile_page(row):
    """หน้าข้อมูลส่วนตัวของแอดมิน: ข้อมูลเจ้าของร้านที่ล็อกไว้ + ช่องที่แก้ไขได้ (เปลี่ยนรหัสผ่านอยู่ที่ ตั้งค่าร้าน)"""
    db = get_db()
    keys = list(OWNER_EDITABLE_TEXT) + list(OWNER_EDITABLE_FILES)
    vals = {k: get_setting(k, "") for k in keys}
    errors = {}
    if request.method == "POST":
        # บันทึกเฉพาะช่องที่แก้ไขได้ — ช่องที่ล็อกจะไม่ถูกอ่านจากฟอร์มเลย
        new_vals = dict(vals)
        for key, limit in OWNER_EDITABLE_TEXT.items():
            new_vals[key] = " ".join((request.form.get(key) or "").split())
            if len(new_vals[key]) > limit:
                errors[key] = f"ยาวเกินไป (ไม่เกิน {limit} ตัวอักษร)"
        if new_vals["owner_email"] and "owner_email" not in errors:
            new_vals["owner_email"], email_error = validate_email(new_vals["owner_email"])
            if email_error:
                errors["owner_email"] = email_error
        uploads = {}
        for key in OWNER_EDITABLE_FILES:
            f = request.files.get(key)
            if f and f.filename:
                if not allowed_image(f.filename) or not looks_like_image(f):
                    errors[key] = "ไฟล์ต้องเป็นรูป JPG, PNG หรือ WEBP"
                else:
                    uploads[key] = f
        if errors:
            flash("กรุณาแก้ไขข้อมูลที่ไม่ถูกต้อง")
            vals = {**new_vals, **{k: vals[k] for k in OWNER_EDITABLE_FILES}}
        else:
            for key in OWNER_EDITABLE_FILES:
                old_name = vals[key]
                if key in uploads:
                    new_vals[key] = save_uploaded_image(uploads[key])
                    remove_uploaded_image(old_name)
                elif request.form.get("remove_" + key):
                    new_vals[key] = ""
                    remove_uploaded_image(old_name)
                else:
                    new_vals[key] = old_name
            for key, value in new_vals.items():
                set_setting(key, value)
            db.commit()
            flash("บันทึกข้อมูลเรียบร้อยแล้ว")
            return redirect(url_for("profile"))
    return render_template("admin_profile.html", owner=OWNER_LOCKED, vals=vals, errors=errors, account=row)


THAI_MONTHS = ["มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน",
               "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"]


def thai_date(iso):
    """'2025-01-15' -> '15 มกราคม 2568' (ถ้าแปลงไม่ได้คืนค่าเดิม)"""
    try:
        d = datetime.strptime(iso, "%Y-%m-%d")
        return f"{d.day} {THAI_MONTHS[d.month - 1]} {d.year + 543}"
    except (ValueError, TypeError):
        return iso or ""


@app.route("/owner")
def owner_page():
    """หน้าข้อมูลเจ้าของร้าน (สาธารณะ — ลูกค้าดูได้ ไม่ต้องล็อกอิน) กดจากฟุตเตอร์"""
    keys = ["owner_nickname", "owner_photo", "owner_email", "owner_line_oa", "shop_address", "shop_opened_date",
            "shop_products_services", "shop_shipping_policy", "shop_return_policy"]
    vals = {k: get_setting(k, "") for k in keys}
    return render_template("owner.html", owner=OWNER_LOCKED, vals=vals, opened_th=thai_date(vals["shop_opened_date"]))


PROFILE_COLUMNS = ("email", "full_name", "phone", "addr", "subdistrict", "district", "province", "zipcode")


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    """ข้อมูลส่วนตัวของผู้ใช้ที่ล็อกอินอยู่: อีเมล ชื่อ เบอร์โทร ที่อยู่เริ่มต้น และเปลี่ยนรหัสผ่าน"""
    db = get_db()
    row = db.execute("SELECT * FROM users WHERE id=?", (session["uid"],)).fetchone()
    if not row:
        session.clear()
        return redirect(url_for("login"))
    is_admin = row["role"] == "admin"
    if is_admin:
        return owner_profile_page(row)
    form = {k: row[k] for k in PROFILE_COLUMNS}
    errors = {}
    if request.method == "POST":
        if request.form.get("action") == "password":
            current = request.form.get("current_password", "")
            new_password = request.form.get("new_password", "")
            if not check_password_hash(row["password_hash"], current):
                flash("รหัสผ่านปัจจุบันไม่ถูกต้อง")
            elif len(new_password) < 6:
                flash("รหัสผ่านใหม่ต้องยาวอย่างน้อย 6 ตัวอักษร")
            elif new_password != request.form.get("confirm_password", ""):
                flash("รหัสผ่านใหม่ทั้งสองช่องไม่ตรงกัน")
            elif new_password == current:
                flash("รหัสผ่านใหม่ต้องไม่ซ้ำกับรหัสผ่านเดิม")
            else:
                db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_password), row["id"]))
                db.commit()
                flash("เปลี่ยนรหัสผ่านเรียบร้อยแล้ว")
            return redirect(url_for("profile"))
        form = {k: request.form.get(k, "") for k in PROFILE_COLUMNS}
        clean, errors = validate_profile(form, is_admin, row["id"])
        if errors:
            flash("กรุณาแก้ไขข้อมูลที่ไม่ถูกต้อง")
        else:
            try:
                db.execute(
                    "UPDATE users SET email=?, full_name=?, phone=?, addr=?, subdistrict=?, district=?, province=?, zipcode=? WHERE id=?",
                    (clean["email"], clean["full_name"], clean["phone"], clean["addr"], clean["subdistrict"],
                     clean["district"], clean["province"], clean["zipcode"], row["id"]),
                )
                db.commit()
            except sqlite3.IntegrityError:
                db.rollback()
                errors["email"] = "อีเมลนี้ถูกใช้โดยบัญชีอื่นแล้ว"
                flash("กรุณาแก้ไขข้อมูลที่ไม่ถูกต้อง")
            else:
                flash("บันทึกข้อมูลส่วนตัวเรียบร้อยแล้ว")
                return redirect(url_for("profile"))
    return render_template("profile.html", account=row, is_admin=is_admin, form=form, errors=errors, provinces=PROVINCES)


@app.route("/my-orders")
@login_required
def my_orders():
    orders = [dict(r) for r in get_db().execute(
        "SELECT * FROM orders WHERE user_id=? ORDER BY id DESC", (session["uid"],)
    )]
    return render_template("my_orders.html", orders=orders, status_labels=PAYMENT_LABELS)


@app.route("/orders/<int:order_id>")
@login_required
def order_detail(order_id):
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order:
        abort(404)
    if order["user_id"] != session["uid"] and session.get("role") != "admin":
        abort(403)
    items = [dict(r) for r in db.execute("SELECT * FROM order_items WHERE order_id=? ORDER BY id", (order_id,))]
    order = dict(order)
    return render_template("order_detail.html", order=order, items=items,
                           payment_label=order_status_info(order)["label"])


def cancel_order(order_id, allowed_statuses):
    """ยกเลิกคำสั่งซื้อและคืนสต็อกสินค้า ทำในทรานแซกชันเดียว คืนค่า True ถ้ายกเลิกสำเร็จ
    (อัปเดตเฉพาะเมื่อสถานะยังอยู่ในรายการที่อนุญาต จึงกดซ้ำแล้วไม่คืนสต็อกซ้ำ)"""
    db = get_db()
    try:
        db.execute("BEGIN IMMEDIATE")
        marks = ",".join("?" for _ in allowed_statuses)
        cur = db.execute(f"UPDATE orders SET payment_status='cancelled' WHERE id=? AND payment_status IN ({marks})",
                         (order_id, *allowed_statuses))
        if cur.rowcount != 1:
            db.rollback()
            return False
        for row in db.execute("SELECT product_id, quantity FROM order_items WHERE order_id=?", (order_id,)).fetchall():
            if row["product_id"]:
                db.execute("UPDATE products SET stock=stock+? WHERE id=?", (int(row["quantity"] or 0), row["product_id"]))
        db.commit()
        return True
    except sqlite3.Error:
        db.rollback()
        return False


@app.post("/orders/<int:order_id>/cancel")
@login_required
def cancel_my_order(order_id):
    """ลูกค้ายกเลิกคำสั่งซื้อของตัวเอง — ได้เฉพาะที่ยังไม่ถูกยืนยันรับเงิน (รอชำระเงิน / แจ้งชำระแล้ว)"""
    order = get_db().execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order:
        abort(404)
    if order["user_id"] != session["uid"]:
        abort(403)
    status = order["payment_status"]
    if status == "cancelled":
        flash("คำสั่งซื้อนี้ถูกยกเลิกไปแล้ว")
    elif status == "paid":
        flash("คำสั่งซื้อที่ร้านยืนยันรับเงินแล้วยกเลิกเองไม่ได้ กรุณาติดต่อร้านค้า")
    elif cancel_order(order_id, ("pending", "reported")):
        if status == "reported":
            flash(f"ยกเลิกคำสั่งซื้อ {order['order_code']} แล้ว หากโอนเงินไปแล้ว กรุณาติดต่อร้านเพื่อขอคืนเงิน")
        else:
            flash(f"ยกเลิกคำสั่งซื้อ {order['order_code']} เรียบร้อยแล้ว")
    else:
        flash("ยกเลิกคำสั่งซื้อไม่สำเร็จ กรุณาลองอีกครั้ง")
    return redirect(url_for("my_orders"))


def vat_breakdown(total, rate="0.07"):
    """แยก VAT ออกจากยอดรวมที่รวม VAT แล้ว (ราคาสินค้าเท่าเดิม) คืนค่า (ราคาก่อน VAT, VAT)
    ปัดเศษ 2 ตำแหน่ง โดยให้ ก่อน VAT + VAT = ยอดรวมเสมอ"""
    from decimal import Decimal, ROUND_HALF_UP
    gross = Decimal(str(total)).quantize(Decimal("0.01"), ROUND_HALF_UP)
    net = (gross / (1 + Decimal(rate))).quantize(Decimal("0.01"), ROUND_HALF_UP)
    return float(net), float(gross - net)


def create_receipt_pdf(order, items):
    try:
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    except ImportError as exc:
        raise RuntimeError("ยังไม่ได้ติดตั้ง reportlab กรุณารัน pip install -r requirements.txt") from exc

    font_regular = "Helvetica"
    font_bold = "Helvetica-Bold"
    font_candidates = [
        os.path.join(BASE_DIR, "fonts", "THSarabunNew.ttf"),
        r"C:\Windows\Fonts\THSarabunNew.ttf",
        r"C:\Windows\Fonts\tahoma.ttf",
        r"C:\Windows\Fonts\LeelawUI.ttf",
        "/usr/share/fonts/truetype/tlwg/Garuda.ttf",
        "/usr/share/fonts/truetype/tlwg/Laksaman.ttf",
    ]
    bold_candidates = [
        os.path.join(BASE_DIR, "fonts", "THSarabunNew Bold.ttf"),
        r"C:\Windows\Fonts\THSarabunNew Bold.ttf",
        r"C:\Windows\Fonts\tahomabd.ttf",
        "/usr/share/fonts/truetype/tlwg/Garuda-Bold.ttf",
        "/usr/share/fonts/truetype/tlwg/Laksaman-Bold.ttf",
    ]
    found_font = next((p for p in font_candidates if os.path.isfile(p)), None)
    if found_font:
        try:
            pdfmetrics.registerFont(TTFont("PJThai", found_font))
            font_regular = "PJThai"
            found_bold = next((p for p in bold_candidates if os.path.isfile(p)), found_font)
            pdfmetrics.registerFont(TTFont("PJThaiBold", found_bold))
            font_bold = "PJThaiBold"
        except Exception:
            font_regular, font_bold = "Helvetica", "Helvetica-Bold"

    status = PAYMENT_LABELS.get(order["payment_status"], order["payment_status"])
    if order["payment_status"] == "paid":
        title = "ใบเสร็จรับเงิน"
        note = "สถานะการชำระเงิน: ตรวจสอบและยืนยันรับเงินแล้ว"
    elif order["payment_status"] == "reported":
        title = "ใบสั่งซื้อ / ใบแจ้งชำระเงิน"
        note = "เอกสารนี้ยังไม่ใช่หลักฐานยืนยันว่าได้รับเงินจริง — รอร้านตรวจสอบยอดโอน"
    else:
        title = "ใบแจ้งชำระเงิน"
        note = "สถานะการชำระเงิน: ยังไม่แจ้งชำระเงิน — เอกสารนี้ไม่ใช่ใบเสร็จรับเงิน"

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=18*mm, leftMargin=18*mm,
                            topMargin=16*mm, bottomMargin=18*mm, title=f"{title} {order['order_code']}")
    styles = getSampleStyleSheet()
    normal = ParagraphStyle("PJNormal", parent=styles["Normal"], fontName=font_regular, fontSize=10, leading=15)
    small = ParagraphStyle("PJSmall", parent=normal, fontSize=8, leading=12)
    header = ParagraphStyle("PJHeader", parent=styles["Title"], fontName=font_bold, fontSize=20,
                            leading=25, alignment=TA_CENTER, spaceAfter=8)
    center = ParagraphStyle("PJCenter", parent=normal, alignment=TA_CENTER)
    story = [Paragraph(escape(get_setting("shop_name", "PJ GUNPLA")), header),
             Paragraph(title, ParagraphStyle("PJTitle2", parent=header, fontSize=16, leading=20)),
             Paragraph(escape(get_setting("shop_address", "")), center), Spacer(1, 7*mm)]
    info = [
        [Paragraph(f"<b>เลขที่เอกสาร:</b> {escape(str(order['order_code']))}", normal),
         Paragraph(f"<b>วันที่:</b> {escape(str(order['created_at']))}", normal)],
        [Paragraph(f"<b>ผู้รับ:</b> {escape(str(order['recipient']))}", normal),
         Paragraph(f"<b>โทร:</b> {escape(str(order['phone']))}", normal)],
        [Paragraph(f"<b>ที่อยู่จัดส่ง:</b> {escape(str(order['address']))}", normal),
         Paragraph(f"<b>สถานะ:</b> {escape(status)}", normal)],
    ]
    inf = Table(info, colWidths=[88*mm, 88*mm])
    inf.setStyle(TableStyle([("VALIGN", (0,0),(-1,-1),"TOP"),("BOTTOMPADDING",(0,0),(-1,-1),5)]))
    story += [inf, Spacer(1, 6*mm)]
    data = [["สินค้า", "ราคา/ชิ้น", "จำนวน", "รวม"]]
    for item in items:
        data.append([
            Paragraph(escape(str(item["product_name"])), normal),
            f"฿{int(item['price']):,}", str(item["quantity"]), f"฿{int(item['subtotal']):,}",
        ])
    data.append(["", "", "ยอดรวม", f"฿{float(order['total']):,.2f}"])
    table = Table(data, colWidths=[86*mm, 30*mm, 22*mm, 36*mm], repeatRows=1, hAlign="LEFT")
    table.setStyle(TableStyle([
        ("FONTNAME", (0,0),(-1,-1),font_regular), ("FONTNAME",(0,0),(-1,0),font_bold),
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#eaf1fb")),
        ("GRID",(0,0),(-1,-2),0.4,colors.HexColor("#cbd5e1")),
        ("ALIGN",(1,1),(-1,-1),"RIGHT"), ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("TOPPADDING",(0,0),(-1,-1),7), ("BOTTOMPADDING",(0,0),(-1,-1),7),
        ("SPAN",(0,-1),(1,-1)), ("FONTNAME",(0,-1),(-1,-1),font_bold),
        ("LINEABOVE",(2,-1),(-1,-1),1,colors.HexColor("#334155")),
    ]))
    story += [table, Spacer(1, 7*mm), Paragraph(f"<b>{escape(note)}</b>", normal),
              Spacer(1, 13*mm), Paragraph("ขอบคุณที่อุดหนุน PJ GUNPLA", center)]
    doc.build(story)
    buffer.seek(0)
    return buffer


@app.route("/orders/<int:order_id>/receipt.pdf")
@login_required
def receipt_pdf(order_id):
    """สร้างและส่งไฟล์ PDF เป็นไฟล์ดาวน์โหลด พร้อมข้อความแจ้งเมื่อสร้างไม่สำเร็จ."""
    db = get_db()
    order_row = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order_row:
        abort(404)

    order = dict(order_row)
    if order.get("user_id") != session.get("uid") and session.get("role") != "admin":
        abort(403)

    # รองรับข้อมูลคำสั่งซื้อจากฐานข้อมูลรุ่นเก่าด้วย
    order["recipient"] = (order.get("recipient") or order.get("customer_name") or "-")
    order["order_code"] = (order.get("order_code") or order.get("payment_ref") or f"PJG-ORDER-{order_id:06d}")
    order["phone"] = order.get("phone") or "-"
    order["address"] = order.get("address") or "-"
    order["created_at"] = order.get("created_at") or "-"
    order["payment_status"] = order.get("payment_status") or "pending"

    rows = db.execute("SELECT * FROM order_items WHERE order_id=? ORDER BY id", (order_id,)).fetchall()
    items = []
    for row in rows:
        item = dict(row)
        # schema เก่าบางชุดใช้ unit_price แทน price
        price = item.get("price")
        if price in (None, "", 0, "0"):
            price = item.get("unit_price") or 0
        try:
            price = int(float(price or 0))
        except (TypeError, ValueError):
            price = 0
        try:
            quantity = max(0, int(float(item.get("quantity") or 0)))
        except (TypeError, ValueError):
            quantity = 0
        subtotal = item.get("subtotal")
        try:
            subtotal = int(float(subtotal)) if subtotal not in (None, "") else price * quantity
        except (TypeError, ValueError):
            subtotal = price * quantity
        item["product_name"] = item.get("product_name") or "สินค้า"
        item["price"] = price
        item["quantity"] = quantity
        item["subtotal"] = subtotal
        items.append(item)

    try:
        pdf = create_receipt_pdf(order, items)
        pdf_bytes = pdf.getvalue()
        if not pdf_bytes.startswith(b"%PDF-"):
            raise RuntimeError("ระบบสร้างไฟล์ PDF ไม่สมบูรณ์ กรุณาลองใหม่อีกครั้ง")
    except Exception as exc:
        app.logger.exception("สร้าง PDF ไม่สำเร็จสำหรับ order_id=%s", order_id)
        if isinstance(exc, RuntimeError):
            message = str(exc)
        elif isinstance(exc, ImportError):
            message = "ยังไม่ได้ติดตั้งไลบรารี PDF กรุณารันคำสั่ง py -m pip install reportlab แล้วเปิดโปรแกรมใหม่"
        else:
            message = f"สร้าง PDF ไม่สำเร็จ ({type(exc).__name__}) กรุณาตรวจข้อความ error ในหน้าต่าง Command Prompt"
        flash(message)
        return redirect(url_for("order_detail", order_id=order_id))

    filename = secure_filename(str(order["order_code"])) or f"order-{order_id}"
    # ส่ง bytes ตรง ๆ ใน response เพื่อให้เบราว์เซอร์ดาวน์โหลดได้แน่นอน
    response = app.response_class(pdf_bytes, mimetype="application/pdf", status=200)
    response.headers["Content-Disposition"] = f'attachment; filename="{filename}.pdf"'
    response.headers["Content-Length"] = str(len(pdf_bytes))
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


# ------------------------------------------------------------------
# ใบเสร็จชำระเงิน (PDF) — ออกได้เฉพาะคำสั่งซื้อที่แอดมินยืนยันรับเงินแล้ว
# (แยกจากเอกสาร PDF เดิม receipt_pdf ซึ่งไม่ถูกแก้ไข)
# ------------------------------------------------------------------
def thai_baht_text(amount):
    """แปลงจำนวนเงินเป็นตัวอักษรไทย เช่น 1250.50 -> หนึ่งพันสองร้อยห้าสิบบาทห้าสิบสตางค์"""
    digits = ["ศูนย์", "หนึ่ง", "สอง", "สาม", "สี่", "ห้า", "หก", "เจ็ด", "แปด", "เก้า"]
    places = ["", "สิบ", "ร้อย", "พัน", "หมื่น", "แสน"]

    def read_group(n):
        text = ""
        s = str(n)
        for i, ch in enumerate(s):
            d = int(ch)
            pos = len(s) - i - 1
            if d == 0:
                continue
            if pos == 0 and d == 1 and len(s) > 1:
                text += "เอ็ด"
            elif pos == 1 and d == 2:
                text += "ยี่สิบ"
            elif pos == 1 and d == 1:
                text += "สิบ"
            else:
                text += digits[d] + places[pos]
        return text

    def read_int(n):
        if n == 0:
            return digits[0]
        parts = []
        while n > 0:
            parts.append(n % 1000000)
            n //= 1000000
        out = ""
        for idx in range(len(parts) - 1, -1, -1):
            if parts[idx]:
                out += read_group(parts[idx]) + ("ล้าน" * idx)
        return out

    satang_total = int(round(float(amount) * 100))
    baht, satang = divmod(satang_total, 100)
    text = read_int(baht) + "บาท"
    text += (read_int(satang) + "สตางค์") if satang else "ถ้วน"
    return text


def _register_pdf_fonts():
    """ลงทะเบียนฟอนต์ไทยสำหรับ PDF คืนค่า (ชื่อฟอนต์ปกติ, ชื่อฟอนต์หนา, ตัวคูณขนาดตัวอักษร)"""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    font_candidates = [
        os.path.join(BASE_DIR, "fonts", "THSarabunNew.ttf"),
        r"C:\Windows\Fonts\THSarabunNew.ttf",
        r"C:\Windows\Fonts\tahoma.ttf",
        r"C:\Windows\Fonts\LeelawUI.ttf",
        "/usr/share/fonts/truetype/tlwg/Garuda.ttf",
        "/usr/share/fonts/truetype/tlwg/Laksaman.ttf",
    ]
    bold_candidates = [
        os.path.join(BASE_DIR, "fonts", "THSarabunNew Bold.ttf"),
        r"C:\Windows\Fonts\THSarabunNew Bold.ttf",
        r"C:\Windows\Fonts\tahomabd.ttf",
        "/usr/share/fonts/truetype/tlwg/Garuda-Bold.ttf",
        "/usr/share/fonts/truetype/tlwg/Laksaman-Bold.ttf",
    ]
    found = next((p for p in font_candidates if os.path.isfile(p)), None)
    if not found:
        return "Helvetica", "Helvetica-Bold", 1.0
    try:
        pdfmetrics.registerFont(TTFont("PJThai", found))
        found_bold = next((p for p in bold_candidates if os.path.isfile(p)), found)
        pdfmetrics.registerFont(TTFont("PJThaiBold", found_bold))
    except Exception:
        return "Helvetica", "Helvetica-Bold", 1.0
    # TH Sarabun New มีตัวเล็กกว่าฟอนต์อื่น จึงขยายขนาดให้อ่านง่าย
    scale = 1.3 if "sarabun" in os.path.basename(found).lower() else 1.0
    return "PJThai", "PJThaiBold", scale


def create_payment_receipt_pdf(order, items):
    """สร้าง PDF ใบเสร็จชำระเงิน (A4) คืนค่าเป็น BytesIO"""
    try:
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_CENTER, TA_RIGHT
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    except ImportError as exc:
        raise RuntimeError("ยังไม่ได้ติดตั้ง reportlab กรุณารัน pip install -r requirements.txt") from exc

    font_regular, font_bold, k = _register_pdf_fonts()
    ink = colors.HexColor("#1f2937")
    line = colors.HexColor("#cbd5e1")
    head_bg = colors.HexColor("#eaf1fb")
    green = colors.HexColor("#15803d")

    receipt_no = f"RC-{order['order_code']}"
    is_paid = order["payment_status"] == "paid"
    amber = colors.HexColor("#b45309")
    stamp_color = green if is_paid else amber
    stamp_text = "ชำระเงินแล้ว" if is_paid else "รอตรวจสอบ"
    doc_title = "ใบเสร็จรับเงิน / RECEIPT" if is_paid else "ใบเสร็จชำระเงิน"
    shop_name = get_setting("shop_name", "PJ GUNPLA")
    shop_address = get_setting("shop_address", "")
    printed_at = datetime.now().strftime("%Y-%m-%d %H:%M")

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=18*mm, leftMargin=18*mm,
                            topMargin=16*mm, bottomMargin=18*mm,
                            title=f"{doc_title} {receipt_no}", author=shop_name)
    styles = getSampleStyleSheet()
    normal = ParagraphStyle("RcNormal", parent=styles["Normal"], fontName=font_regular,
                            fontSize=10*k, leading=15*k, textColor=ink)
    small = ParagraphStyle("RcSmall", parent=normal, fontSize=8.5*k, leading=12*k,
                           textColor=colors.HexColor("#64748b"))
    center = ParagraphStyle("RcCenter", parent=normal, alignment=TA_CENTER)
    right = ParagraphStyle("RcRight", parent=normal, alignment=TA_RIGHT)
    shop_style = ParagraphStyle("RcShop", parent=normal, fontName=font_bold, fontSize=20*k,
                                leading=25*k, alignment=TA_CENTER)
    title_style = ParagraphStyle("RcTitle", parent=normal, fontName=font_bold, fontSize=16*k,
                                 leading=21*k, alignment=TA_CENTER, textColor=colors.HexColor("#1d4ed8"))
    bold = ParagraphStyle("RcBold", parent=normal, fontName=font_bold)

    story = []
    try:  # โลโก้ร้านบนหัวใบเสร็จ (ถ้าอ่านรูปไม่ได้ ข้ามไป)
        from reportlab.lib.utils import ImageReader
        from reportlab.platypus import Image as RLImage
        logo_bytes = shop_logo_bytes()
        iw, ih = ImageReader(io.BytesIO(logo_bytes)).getSize()
        logo_h = 24 * mm
        logo_w = min(logo_h * iw / ih, 70 * mm)
        logo_img = RLImage(io.BytesIO(logo_bytes), width=logo_w, height=logo_w * ih / iw)
        logo_img.hAlign = "CENTER"
        story += [logo_img, Spacer(1, 2 * mm)]
    except Exception:
        pass
    story.append(Paragraph(escape(shop_name), shop_style))
    if shop_address:
        story.append(Paragraph(escape(shop_address), center))
    story += [Spacer(1, 3*mm), Paragraph(escape(doc_title), title_style), Spacer(1, 5*mm)]

    # เลขที่เอกสาร + ตราประทับสถานะ
    stamp = Table([[Paragraph(stamp_text, ParagraphStyle(
        "RcStamp", parent=normal, fontName=font_bold, fontSize=13*k, leading=17*k,
        alignment=TA_CENTER, textColor=stamp_color))]], colWidths=[38*mm])
    stamp.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 1.4, stamp_color),
                               ("TOPPADDING", (0, 0), (-1, -1), 4),
                               ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    meta = Table([
        [Paragraph(f"<b>เลขที่ใบเสร็จ:</b> {escape(receipt_no)}", normal), ""],
        [Paragraph(f"<b>อ้างอิงคำสั่งซื้อ:</b> {escape(str(order['order_code']))}", normal), stamp if is_paid else ""],
        [Paragraph(f"<b>วันที่สั่งซื้อ:</b> {escape(str(order['created_at']))}", normal), ""],
        [Paragraph(f"<b>ช่องทางชำระเงิน:</b> PromptPay QR — ธนาคารกสิกรไทย", normal), ""],
    ], colWidths=[128*mm, 48*mm])
    meta.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("SPAN", (1, 1), (1, 3)),
                              ("VALIGN", (1, 1), (1, 3), "MIDDLE"), ("ALIGN", (1, 1), (1, 3), "RIGHT"),
                              ("BOTTOMPADDING", (0, 0), (-1, -1), 2), ("TOPPADDING", (0, 0), (-1, -1), 2)]))
    story += [meta, Spacer(1, 4*mm)]

    cust = Table([[Paragraph("<b>ข้อมูลลูกค้า</b>", normal)],
                  [Paragraph(f"{escape(str(order['recipient']))} &nbsp;|&nbsp; โทร. {escape(str(order['phone']))}", normal)],
                  [Paragraph(escape(str(order['address'])), normal)]], colWidths=[176*mm])
    cust.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.5, line), ("BACKGROUND", (0, 0), (-1, 0), head_bg),
                              ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    story += [cust, Spacer(1, 5*mm)]

    data = [["#", "รายการสินค้า", "ราคา/ชิ้น", "จำนวน", "รวม"]]
    for i, item in enumerate(items, 1):
        data.append([str(i), Paragraph(escape(str(item["product_name"])), normal),
                     f"฿{int(item['price']):,.2f}", str(item["quantity"]), f"฿{int(item['subtotal']):,.2f}"])
    n_items = len(items)
    total = float(order["total"])
    net, vat = vat_breakdown(total)
    data.append(["ราคาสินค้า (ก่อนภาษีมูลค่าเพิ่ม)", "", "", "", f"฿{net:,.2f}"])
    data.append(["ภาษีมูลค่าเพิ่ม (VAT) 7%", "", "", "", f"฿{vat:,.2f}"])
    data.append(["ยอดรวมทั้งสิ้น", "", "", "", f"฿{total:,.2f}"])
    table = Table(data, colWidths=[10*mm, 78*mm, 30*mm, 28*mm, 30*mm], repeatRows=1, hAlign="LEFT")
    table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), font_regular), ("FONTSIZE", (0, 0), (-1, -1), 10*k),
        ("FONTNAME", (0, 0), (-1, 0), font_bold), ("BACKGROUND", (0, 0), (-1, 0), head_bg),
        ("GRID", (0, 0), (-1, n_items), 0.4, line),
        ("ALIGN", (2, 0), (-1, -1), "RIGHT"), ("ALIGN", (0, 0), (0, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("SPAN", (0, n_items + 1), (3, n_items + 1)), ("SPAN", (0, n_items + 2), (3, n_items + 2)),
        ("SPAN", (0, n_items + 3), (3, n_items + 3)),
        ("ALIGN", (0, n_items + 1), (3, -1), "RIGHT"),
        ("TOPPADDING", (0, n_items + 1), (-1, n_items + 2), 3), ("BOTTOMPADDING", (0, n_items + 1), (-1, n_items + 2), 3),
        ("FONTNAME", (0, -1), (-1, -1), font_bold),
        ("LINEABOVE", (0, -1), (-1, -1), 1, colors.HexColor("#334155")),
    ]))
    story += [table, Spacer(1, 1.5*mm),
              Paragraph("ราคาสินค้าข้างต้นรวมภาษีมูลค่าเพิ่ม 7% แล้ว", ParagraphStyle("RcVat", parent=small, alignment=TA_RIGHT)),
              Spacer(1, 2*mm),
              Paragraph(f"<b>จำนวนเงินตัวอักษร:</b> ({escape(thai_baht_text(total))})", normal),
              Spacer(1, 10*mm),
              Paragraph(("ได้รับชำระเงินตามรายการข้างต้นเรียบร้อยแล้ว ขอบคุณที่อุดหนุน " + escape(shop_name)) if is_paid
                        else "ลูกค้าแจ้งชำระเงินแล้ว ร้านอยู่ระหว่างตรวจสอบยอดเงิน — เอกสารนี้ยังไม่ใช่หลักฐานการรับเงินจนกว่าร้านจะยืนยัน", center),
              Spacer(1, 6*mm),
              Paragraph(f"พิมพ์เอกสารเมื่อ {printed_at} · เอกสารนี้ออกโดยระบบอัตโนมัติ", ParagraphStyle(
                  "RcFoot", parent=small, alignment=TA_CENTER))]
    doc.build(story)
    buffer.seek(0)
    return buffer


def _load_order_for_pdf(order_id):
    """โหลดคำสั่งซื้อ + รายการสินค้า พร้อมตรวจสิทธิ์ และรองรับฐานข้อมูลรุ่นเก่า"""
    db = get_db()
    order_row = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order_row:
        abort(404)
    order = dict(order_row)
    if order.get("user_id") != session.get("uid") and session.get("role") != "admin":
        abort(403)
    order["recipient"] = order.get("recipient") or order.get("customer_name") or "-"
    order["order_code"] = order.get("order_code") or order.get("payment_ref") or f"PJG-ORDER-{order_id:06d}"
    order["phone"] = order.get("phone") or "-"
    order["address"] = order.get("address") or "-"
    order["created_at"] = order.get("created_at") or "-"
    order["payment_status"] = order.get("payment_status") or "pending"

    items = []
    for row in db.execute("SELECT * FROM order_items WHERE order_id=? ORDER BY id", (order_id,)).fetchall():
        item = dict(row)
        price = item.get("price")
        if price in (None, "", 0, "0"):
            price = item.get("unit_price") or 0
        try:
            price = int(float(price or 0))
        except (TypeError, ValueError):
            price = 0
        try:
            quantity = max(0, int(float(item.get("quantity") or 0)))
        except (TypeError, ValueError):
            quantity = 0
        try:
            subtotal = int(float(item["subtotal"])) if item.get("subtotal") not in (None, "") else price * quantity
        except (TypeError, ValueError):
            subtotal = price * quantity
        item.update(product_name=item.get("product_name") or "สินค้า", price=price,
                    quantity=quantity, subtotal=subtotal)
        items.append(item)
    return order, items


@app.route("/orders/<int:order_id>/payment-receipt")
@login_required
def payment_receipt_print(order_id):
    """หน้าใบเสร็จชำระเงินสำหรับสั่งพิมพ์ (หรือบันทึกเป็น PDF จากหน้าต่างพิมพ์ของเบราว์เซอร์) — ไม่ต้องติดตั้งไลบรารีเพิ่ม"""
    order, items = _load_order_for_pdf(order_id)
    if order["payment_status"] not in ("reported", "paid"):
        flash("กรุณากดแจ้งชำระเงินพร้อมแนบสลิปก่อน จึงจะดาวน์โหลดใบเสร็จชำระเงินได้")
        return redirect(url_for("order_detail", order_id=order_id))
    is_paid = order["payment_status"] == "paid"
    total = float(order["total"])
    net, vat = vat_breakdown(total)
    response = app.make_response(render_template(
        "print_receipt.html", order=order, items=items, total=total, is_paid=is_paid, net=net, vat=vat,
        receipt_no=f"RC-{order['order_code']}",
        doc_title="ใบเสร็จรับเงิน / RECEIPT" if is_paid else "ใบเสร็จชำระเงิน",
        shop_name=get_setting("shop_name", "PJ GUNPLA"), shop_address=get_setting("shop_address", ""),
        baht_text=thai_baht_text(total), printed_at=datetime.now().strftime("%Y-%m-%d %H:%M"),
    ))
    response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/orders/<int:order_id>/payment-receipt.pdf")
@login_required
def payment_receipt_pdf(order_id):
    """ดาวน์โหลดใบเสร็จชำระเงิน (PDF) — ออกได้หลังลูกค้าแจ้งชำระเงิน (ระบุ "รอตรวจสอบ" จนกว่าแอดมินยืนยัน)"""
    order, items = _load_order_for_pdf(order_id)
    if order["payment_status"] not in ("reported", "paid"):
        flash("กรุณากดแจ้งชำระเงินก่อน จึงจะดาวน์โหลดใบเสร็จชำระเงินได้")
        return redirect(url_for("order_detail", order_id=order_id))
    try:
        pdf_bytes = create_payment_receipt_pdf(order, items).getvalue()
        if not pdf_bytes.startswith(b"%PDF-"):
            raise RuntimeError("ระบบสร้างไฟล์ PDF ไม่สมบูรณ์ กรุณาลองใหม่อีกครั้ง")
    except Exception as exc:
        app.logger.exception("สร้างใบเสร็จชำระเงินไม่สำเร็จ order_id=%s", order_id)
        flash(str(exc) if isinstance(exc, RuntimeError)
              else f"สร้างใบเสร็จไม่สำเร็จ ({type(exc).__name__}) กรุณาตรวจข้อความ error ในหน้าต่าง Command Prompt")
        return redirect(url_for("order_detail", order_id=order_id))

    filename = secure_filename(f"receipt-{order['order_code']}") or f"receipt-{order_id}"
    response = app.response_class(pdf_bytes, mimetype="application/pdf", status=200)
    response.headers["Content-Disposition"] = f'attachment; filename="{filename}.pdf"'
    response.headers["Content-Length"] = str(len(pdf_bytes))
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


# ------------------------------------------------------------------
# Admin routes
# ------------------------------------------------------------------
@app.route("/admin")
@admin_required
def admin_dashboard():
    products = [row_dict(r) for r in get_db().execute("SELECT * FROM products ORDER BY id DESC")]
    return render_template("admin_dashboard.html", products=products)


def product_form_values():
    name = request.form.get("name", "").strip()
    grade = request.form.get("grade", "HG").upper().strip()
    scale = request.form.get("scale", "1/144").strip()
    category = request.form.get("category", "GUNDAM GUNPLA").strip()
    badge = request.form.get("badge", "").strip().upper()
    description = request.form.get("description", "").strip()
    try:
        price = int(request.form.get("price", "0"))
        stock = int(request.form.get("stock", "0"))
        old_text = request.form.get("old_price", "").strip()
        old_price = int(old_text) if old_text else None
    except ValueError:
        raise ValueError("ราคา สต็อก และราคาเดิมต้องเป็นตัวเลขจำนวนเต็ม")
    if not name or not scale or not category:
        raise ValueError("กรุณากรอกชื่อสินค้า Scale และหมวดสินค้าให้ครบ")
    if grade not in GRADES:
        raise ValueError("กรุณาเลือกเกรดสินค้าที่ถูกต้อง")
    if price < 0 or stock < 0 or (old_price is not None and old_price < 0):
        raise ValueError("ราคาและสต็อกต้องไม่ติดลบ")
    if badge not in ("", "NEW", "SALE", "HOT", "SOLD OUT"):
        raise ValueError("ป้ายสินค้าไม่ถูกต้อง")
    return {"name": name, "grade": grade, "scale": scale, "price": price,
            "old_price": old_price, "stock": stock, "category": category,
            "badge": badge, "description": description}


@app.route("/admin/products/new", methods=["GET", "POST"])
@admin_required
def admin_product_new():
    if request.method == "POST":
        try:
            values = product_form_values()
            filename = save_uploaded_image(request.files.get("image"))
            values["image_filename"] = filename
            cur = get_db().execute("""INSERT INTO products
                (name,grade,scale,price,old_price,stock,category,badge,description,image_filename)
                VALUES(:name,:grade,:scale,:price,:old_price,:stock,:category,:badge,:description,:image_filename)""", values)
            get_db().commit()
            flash("เพิ่มสินค้าแล้ว")
            return redirect(url_for("admin_product_edit", pid=cur.lastrowid))
        except ValueError as exc:
            flash(str(exc))
        except Exception:
            flash("เพิ่มสินค้าไม่สำเร็จ กรุณาตรวจสอบข้อมูลและไฟล์รูป")
    return render_template("admin_product_form.html", p=None)


@app.route("/admin/products/<int:pid>/edit", methods=["GET", "POST"])
@admin_required
def admin_product_edit(pid):
    p = get_product(pid) or abort(404)
    if request.method == "POST":
        try:
            values = product_form_values()
            image_file = request.files.get("image")
            new_filename = save_uploaded_image(image_file) if image_file and image_file.filename else p.get("image_filename", "")
            values.update({"image_filename": new_filename, "id": pid})
            get_db().execute("""UPDATE products SET name=:name,grade=:grade,scale=:scale,price=:price,
                old_price=:old_price,stock=:stock,category=:category,badge=:badge,description=:description,
                image_filename=:image_filename WHERE id=:id""", values)
            get_db().commit()
            if new_filename != p.get("image_filename"):
                remove_uploaded_image(p.get("image_filename"))
            flash("บันทึกการแก้ไขสินค้าแล้ว")
            return redirect(url_for("admin_dashboard"))
        except ValueError as exc:
            flash(str(exc))
        except Exception:
            flash("แก้ไขสินค้าไม่สำเร็จ กรุณาตรวจสอบข้อมูลและไฟล์รูป")
        p = get_product(pid)
    return render_template("admin_product_form.html", p=p)


@app.post("/admin/products/<int:pid>/delete")
@admin_required
def admin_product_delete(pid):
    p = get_product(pid) or abort(404)
    # Retain order history; product_id in past order items is intentionally not a foreign key.
    get_db().execute("DELETE FROM products WHERE id=?", (pid,))
    get_db().commit()
    remove_uploaded_image(p.get("image_filename"))
    cart = dict(session.get("cart", {}))
    cart.pop(str(pid), None)
    session["cart"] = cart
    flash(f"ลบสินค้า {p['name']} แล้ว")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/orders")
@admin_required
def admin_orders():
    """หน้ารวมคำสั่งซื้อสำหรับแอดมิน พร้อมค้นหาชื่อลูกค้า เบอร์โทร ที่อยู่ และสินค้า"""
    db = get_db()
    q = request.args.get("q", "").strip()[:120]
    selected_status = request.args.get("status", "").strip()
    if selected_status not in ORDER_STATUS_SQL:
        selected_status = ""

    # สรุปสถานะทั้งหมด ไม่ขึ้นกับตัวกรองหน้าจอ
    counts = {key: 0 for key in ORDER_STATUS_LABELS}
    for row in db.execute(
        "SELECT payment_status, COALESCE(fulfillment_status, 'waiting') AS fs, COUNT(*) AS n FROM orders GROUP BY 1, 2"
    ).fetchall():
        counts[order_status_key(row["payment_status"], row["fs"])] += row["n"]
    stats = {"total": sum(counts.values()), **counts}

    clauses = []
    params = []
    if selected_status:
        clauses.append(ORDER_STATUS_SQL[selected_status])
    if q:
        like = f"%{q}%"
        clauses.append("""(
            COALESCE(o.order_code, '') LIKE ? OR
            COALESCE(o.recipient, '') LIKE ? OR
            COALESCE(o.customer_name, '') LIKE ? OR
            COALESCE(o.phone, '') LIKE ? OR
            COALESCE(o.address, '') LIKE ? OR
            COALESCE(u.username, '') LIKE ? OR
            COALESCE(u.email, '') LIKE ? OR
            EXISTS (SELECT 1 FROM order_items oi WHERE oi.order_id=o.id AND oi.product_name LIKE ?)
        )""")
        params.extend([like] * 8)
    where_sql = (" WHERE " + " AND ".join(clauses)) if clauses else ""
    rows = db.execute(
        """SELECT o.*, u.username AS customer_username, u.email AS customer_email
           FROM orders o LEFT JOIN users u ON u.id=o.user_id""" +
        where_sql + " ORDER BY o.id DESC LIMIT 500",
        params,
    ).fetchall()
    orders = [dict(row) for row in rows]

    # โหลดรายละเอียดสินค้าของคำสั่งซื้อที่แสดงอยู่ เพื่อให้แอดมินดูได้จากหน้าเดียว
    items_by_order = {}
    if orders:
        ids = [int(order["id"]) for order in orders]
        placeholders = ",".join("?" for _ in ids)
        item_rows = db.execute(
            f"""SELECT order_id, product_name, grade,
                       COALESCE(NULLIF(price, 0), unit_price, 0) AS display_price,
                       quantity,
                       COALESCE(NULLIF(subtotal, 0), COALESCE(NULLIF(price, 0), unit_price, 0) * quantity) AS display_subtotal
                FROM order_items WHERE order_id IN ({placeholders}) ORDER BY order_id DESC, id""",
            ids,
        ).fetchall()
        for row in item_rows:
            items_by_order.setdefault(int(row["order_id"]), []).append(dict(row))

    return render_template(
        "admin_orders.html", orders=orders, items_by_order=items_by_order,
        stats=stats, q=q, selected_status=selected_status,
        status_labels=ORDER_STATUS_LABELS, step_options=ORDER_STEP_OPTIONS,
        cancelled_count=counts.get("cancelled", 0),
    )



@app.post("/admin/orders/<int:order_id>/mark-paid")
@admin_required
def admin_mark_paid(order_id):
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order:
        abort(404)
    if order["payment_status"] == "cancelled":
        flash("คำสั่งซื้อนี้ถูกยกเลิกแล้ว ยืนยันรับเงินไม่ได้")
        return redirect(url_for("admin_orders"))
    db.execute("UPDATE orders SET payment_status='paid', fulfillment_status='waiting' WHERE id=?", (order_id,))
    db.commit()
    flash(f"ยืนยันรับชำระคำสั่งซื้อ {order['order_code']} แล้ว — โปรดใช้ปุ่มนี้หลังตรวจสอบยอดเงินจริงเท่านั้น")
    return redirect(url_for("admin_orders"))


@app.post("/admin/orders/<int:order_id>/reset-status")
@admin_required
def admin_reset_status(order_id):
    """ล้างสถานะการชำระเงินของคำสั่งซื้อกลับเป็น 'รอชำระเงิน' (ใบเสร็จชำระเงินจะหยุดออกได้จนกว่าจะยืนยันใหม่)"""
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order:
        abort(404)
    if order["payment_status"] == "cancelled":
        flash("คำสั่งซื้อที่ยกเลิกแล้วล้างสถานะไม่ได้ (สต็อกถูกคืนไปแล้ว) หากต้องการ ให้ลูกค้าสั่งซื้อใหม่")
        return redirect(request.referrer or url_for("admin_orders"))
    remove_payment_slip(order["slip_path"] if "slip_path" in order.keys() else "")
    db.execute("UPDATE orders SET payment_status='pending', fulfillment_status='waiting', slip_path='' WHERE id=?", (order_id,))
    db.commit()
    flash(f"ล้างสถานะคำสั่งซื้อ {order['order_code']} กลับเป็นรอชำระเงินแล้ว")
    return redirect(request.referrer or url_for("admin_orders"))


@app.post("/admin/orders/<int:order_id>/set-status")
@admin_required
def admin_set_order_status(order_id):
    """เปลี่ยนสถานะคำสั่งซื้อจาก dropdown: รอดำเนินการ / กำลังเตรียมพัสดุ / กำลังจัดส่ง / จัดส่งสำเร็จ / ยกเลิกแล้ว
    (เตรียมพัสดุขึ้นไปต้องยืนยันรับเงินก่อน, ยกเลิกแล้วเปลี่ยนกลับไม่ได้, ยกเลิกจะคืนสต็อก)"""
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order:
        abort(404)
    labels = dict(ORDER_STEP_OPTIONS)
    new = request.form.get("status", "")
    code = order["order_code"]
    if new not in labels:
        flash("สถานะที่เลือกไม่ถูกต้อง")
    elif order["payment_status"] == "cancelled":
        flash("คำสั่งซื้อที่ยกเลิกแล้วเปลี่ยนสถานะไม่ได้ (สต็อกถูกคืนไปแล้ว)")
    elif new == "cancelled":
        if cancel_order(order_id, ("pending", "reported", "paid")):
            extra = " (ลูกค้าโอนเงินแล้ว อย่าลืมคืนเงินให้ลูกค้า)" if order["payment_status"] in ("reported", "paid") else ""
            flash(f"ยกเลิกคำสั่งซื้อ {code} และคืนสต็อกแล้ว{extra}")
        else:
            flash("ยกเลิกคำสั่งซื้อไม่สำเร็จ กรุณาลองอีกครั้ง")
    elif order["payment_status"] != "paid":
        if new == "waiting":
            flash(f"คำสั่งซื้อ {code} ยังเป็น “รอดำเนินการ” อยู่แล้ว")
        else:
            flash(f"ต้องกด “ยืนยันรับเงิน” ก่อน จึงจะเปลี่ยนเป็น “{labels[new]}” ได้")
    else:
        db.execute("UPDATE orders SET fulfillment_status=? WHERE id=?", (new, order_id))
        db.commit()
        flash(f"อัปเดตสถานะคำสั่งซื้อ {code} เป็น “{labels[new]}” แล้ว")
    return redirect(request.referrer or url_for("admin_orders"))


@app.post("/admin/orders/<int:order_id>/cancel")
@admin_required
def admin_cancel_order(order_id):
    """แอดมินยกเลิกคำสั่งซื้อ (ได้ทุกสถานะที่ยังไม่ถูกยกเลิก) และคืนสต็อก — ถ้าลูกค้าโอนแล้วต้องคืนเงินเอง"""
    order = get_db().execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order:
        abort(404)
    if order["payment_status"] == "cancelled":
        flash("คำสั่งซื้อนี้ถูกยกเลิกไปแล้ว")
    elif cancel_order(order_id, ("pending", "reported", "paid")):
        extra = " (ลูกค้าโอนเงินแล้ว อย่าลืมคืนเงินให้ลูกค้า)" if order["payment_status"] in ("reported", "paid") else ""
        flash(f"ยกเลิกคำสั่งซื้อ {order['order_code']} และคืนสต็อกแล้ว{extra}")
    else:
        flash("ยกเลิกคำสั่งซื้อไม่สำเร็จ กรุณาลองอีกครั้ง")
    return redirect(request.referrer or url_for("admin_orders"))


def delete_orders(order_ids):
    """ลบคำสั่งซื้อ (เฉพาะที่ยกเลิกแล้ว) พร้อมรายการสินค้าและไฟล์สลิป คืนค่าจำนวนที่ลบได้"""
    db = get_db()
    deleted = 0
    try:
        db.execute("BEGIN IMMEDIATE")
        for oid in order_ids:
            row = db.execute("SELECT slip_path FROM orders WHERE id=? AND payment_status='cancelled'", (oid,)).fetchone()
            if not row:
                continue
            db.execute("DELETE FROM order_items WHERE order_id=?", (oid,))
            db.execute("DELETE FROM orders WHERE id=? AND payment_status='cancelled'", (oid,))
            deleted += 1
            remove_payment_slip(row["slip_path"] or "")
        db.commit()
    except sqlite3.Error:
        db.rollback()
        return 0
    return deleted


@app.post("/admin/orders/<int:order_id>/delete")
@admin_required
def admin_delete_order(order_id):
    """ลบรายการคำสั่งซื้อที่ยกเลิกแล้วออกจากระบบ (ลบถาวร) — สถานะอื่นต้องยกเลิกก่อน เพื่อให้สต็อกถูกคืน"""
    order = get_db().execute("SELECT order_code, payment_status FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order:
        abort(404)
    if order["payment_status"] != "cancelled":
        flash("ลบได้เฉพาะคำสั่งซื้อที่ยกเลิกแล้ว กรุณายกเลิกคำสั่งซื้อก่อน")
    elif delete_orders([order_id]):
        flash(f"ลบคำสั่งซื้อ {order['order_code']} ออกจากระบบแล้ว")
    else:
        flash("ลบคำสั่งซื้อไม่สำเร็จ กรุณาลองอีกครั้ง")
    return redirect(request.referrer or url_for("admin_orders"))


@app.post("/admin/orders/delete-cancelled")
@admin_required
def admin_delete_cancelled_orders():
    """ลบคำสั่งซื้อที่ยกเลิกแล้วทั้งหมดในครั้งเดียว"""
    ids = [r["id"] for r in get_db().execute("SELECT id FROM orders WHERE payment_status='cancelled'").fetchall()]
    count = delete_orders(ids) if ids else 0
    flash(f"ลบคำสั่งซื้อที่ยกเลิกแล้วทั้งหมด {count} รายการ" if count else "ไม่มีคำสั่งซื้อที่ยกเลิกให้ลบ")
    return redirect(url_for("admin_orders"))


@app.route("/admin/settings", methods=["GET", "POST"])
@admin_required
def admin_settings():
    db = get_db()
    settings = all_settings()
    info = {k: get_setting(k, "") for k in (*SHOP_INFO_TEXT, "shop_opened_date", "shop_logo")}
    errors = {}
    if request.method == "POST":
        shop_name = request.form.get("shop_name", "PJ GUNPLA").strip()[:100] or "PJ GUNPLA"
        shop_address = request.form.get("shop_address", "").strip()[:300]
        current_password = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        confirm_password = request.form.get("confirm_password", "")
        error = None
        new_info = dict(info)
        for key, limit in SHOP_INFO_TEXT.items():
            new_info[key] = (request.form.get(key) or "").strip().replace("\r\n", "\n")
            if len(new_info[key]) > limit:
                errors[key] = f"ยาวเกินไป (ไม่เกิน {limit} ตัวอักษร)"
        opened = (request.form.get("shop_opened_date") or "").strip()
        if opened:
            try:
                datetime.strptime(opened, "%Y-%m-%d")
            except ValueError:
                errors["shop_opened_date"] = "วันที่ไม่ถูกต้อง"
        new_info["shop_opened_date"] = opened
        logo_file = request.files.get("shop_logo")
        if logo_file and logo_file.filename and (not allowed_image(logo_file.filename) or not looks_like_image(logo_file)):
            errors["shop_logo"] = "ไฟล์ต้องเป็นรูป JPG, PNG หรือ WEBP"
            logo_file = None
        if new_password or current_password or confirm_password:
            account = db.execute("SELECT password_hash FROM users WHERE id=?", (session["uid"],)).fetchone()
            if not account or not check_password_hash(account["password_hash"], current_password):
                error = "รหัสผ่านปัจจุบันไม่ถูกต้อง จึงไม่สามารถเปลี่ยนรหัสผ่านได้"
            elif len(new_password) < 8:
                error = "รหัสผ่านใหม่ต้องมีอย่างน้อย 8 ตัวอักษร"
            elif new_password != confirm_password:
                error = "รหัสผ่านใหม่และช่องยืนยันไม่ตรงกัน"
        if error or errors:
            flash(error or "กรุณาแก้ไขข้อมูลที่ไม่ถูกต้อง")
            settings = {**settings, "shop_name": shop_name, "shop_address": shop_address}
            info = {**new_info, "shop_logo": info["shop_logo"]}
        else:
            old_logo = info["shop_logo"]
            if logo_file and logo_file.filename:
                new_info["shop_logo"] = save_uploaded_image(logo_file)
                remove_uploaded_image(old_logo)
            elif request.form.get("remove_shop_logo"):
                new_info["shop_logo"] = ""
                remove_uploaded_image(old_logo)
            for key, value in (("shop_name", shop_name), ("shop_address", shop_address), *new_info.items()):
                set_setting(key, value)
            if new_password:
                db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_password), session["uid"]))
            db.commit()
            flash("บันทึกการตั้งค่าร้านแล้ว" if not new_password else "บันทึกการตั้งค่าร้านและเปลี่ยนรหัสผ่านแล้ว")
            return redirect(url_for("admin_settings"))
    return render_template("admin_settings.html", settings=settings, info=info, errors=errors, owner=OWNER_LOCKED)


# ------------------------------------------------------------------
# Customer account routes
# ------------------------------------------------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        email, email_error = validate_email(request.form.get("email"))
        if len(username) < 3:
            flash("ชื่อผู้ใช้ต้องยาวอย่างน้อย 3 ตัวอักษร")
        elif email_error:
            flash(email_error)
        elif email_in_use(email):
            flash("อีเมลนี้ถูกใช้สมัครแล้ว")
        elif len(password) < 6:
            flash("รหัสผ่านต้องยาวอย่างน้อย 6 ตัวอักษร")
        elif password != confirm:
            flash("รหัสผ่านทั้งสองช่องไม่ตรงกัน")
        else:
            try:
                cur = get_db().execute("INSERT INTO users(username,password_hash,role,email) VALUES(?,?, 'customer', ?)",
                                       (username, generate_password_hash(password), email))
                get_db().commit()
            except sqlite3.IntegrityError:
                flash("ชื่อผู้ใช้หรืออีเมลนี้ถูกใช้แล้ว")
            else:
                session["uid"] = cur.lastrowid
                session["uname"] = username
                session["role"] = "customer"
                flash("สมัครสมาชิกสำเร็จ ยินดีต้อนรับสู่ PJ GUNPLA")
                return redirect(url_for("home"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    nxt = request.values.get("next", "")
    if request.method == "POST":
        row = get_db().execute("SELECT * FROM users WHERE username=?", (request.form.get("username", "").strip(),)).fetchone()
        if row and check_password_hash(row["password_hash"], request.form.get("password", "")):
            wants_admin = bool(request.form.get("admin_login"))
            if wants_admin and row["role"] != "admin":
                flash("บัญชีนี้ไม่ใช่แอดมิน")
                return render_template("login.html", next=nxt)
            session["uid"] = row["id"]
            session["uname"] = row["username"]
            session["role"] = row["role"]
            if wants_admin:
                return redirect(url_for("admin_dashboard"))
            return redirect(safe_next(nxt))
        flash("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง")
    return render_template("login.html", next=nxt)


@app.route("/logout")
def logout():
    session.clear()
    flash("ออกจากระบบแล้ว")
    return redirect(url_for("home"))


@app.errorhandler(413)
def file_too_large(_error):
    flash("ไฟล์มีขนาดใหญ่เกิน 8 MB")
    return redirect(request.referrer or url_for("admin_dashboard"))


@app.errorhandler(403)
def forbidden(_error):
    return "ไม่มีสิทธิ์เข้าถึงหน้านี้ (403)", 403


def find_free_port(start=5000, tries=20):
    for port in range(start, start + tries):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("ไม่พบพอร์ตที่ว่าง กรุณาปิดโปรแกรมอื่นที่ใช้พอร์ต 5000-5019")


if __name__ == "__main__":
    init_db()
    port = find_free_port(5000)
    app_url = f"http://127.0.0.1:{port}"
    print("=" * 54)
    print(" PJ GUNPLA พร้อมใช้งานแล้ว")
    print(f" เปิดเว็บ: {app_url}")
    if DEFAULT_ADMIN_PASSWORD:
        print(f" บัญชีแอดมิน: {DEFAULT_ADMIN_USERNAME} (รหัสผ่านกำหนดไว้ใน .env)")
    else:
        print(" ยังไม่ได้กำหนดรหัสผ่านแอดมิน: ตั้งค่า PJ_ADMIN_PASSWORD ใน .env แล้วเปิดโปรแกรมใหม่")
    print(" กด Ctrl+C เพื่อหยุดโปรแกรม")
    print("=" * 54)
    threading.Timer(1.0, lambda: webbrowser.open(app_url)).start()
    app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)
